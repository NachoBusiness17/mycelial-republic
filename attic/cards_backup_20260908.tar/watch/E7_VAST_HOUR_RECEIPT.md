# E7 VAST HOUR — RECEIPT (attempt 4, parent-side)

```
{
  "INSTANCE": {
    "ask_id": 48762161,
    "gpu": "RTX 5090"
  },
  "BOOT": null,
  "JOB1": null,
  "JOB2": null,
  "JOB3": null,
  "JOB4": null,
  "TOTAL_SPEND": {
    "cap_us": 1.5,
    "minutes": 20.1,
    "est_usd": 0.27
  },
  "DESTROY_PROOF": {
    "instances_after": 0
  },
  "FAILURES": [
    "endpoint never came live in 15min"
  ]
}
```
