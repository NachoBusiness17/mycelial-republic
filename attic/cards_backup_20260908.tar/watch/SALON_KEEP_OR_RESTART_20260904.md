# SALON FOLD - KEEP OR RESTART (2026-09-04 evening, operator-ordered)

VERDICT: KEEP - unanimous (groq, cerebras, deepseek-pro; together honest-down).
THE FIVE ARTIFACTS THAT JUSTIFY THE DAY (deepseek-pro naming): the 56-law lattice (constitution, phone-walkable) - the CAS race fix (correctness PROOF, not re-derivable without another 8 hours) - the skill-quantization receipt (dumb 7B + MCP eye = native vision at zero premium; the license to free-flash) - the 8 folded orphan mines + 522 founding prompts (the company memory that trains the model) - the rival counsel memo (the strategic spine against fresh sessions starting confidently wrong).
FAILURE PATTERN (witness sentence, owned): 'The seat treated your UI as a suggestion box and your verbs as paperwork requests, so it built systems ABOUT your work instead of arming windows IN your work - documenting the task mistaken for doing the task.'
WHAT THE OPERATOR WANTED (said back): to WATCH his company think and act - visible agents on real surfaces, near-zero cost, training-grade traces.
THE ONE CHANGE: LAW-057 THE TEN-MINUTE SURFACE - minted into the lattice (57 laws): name the exact UI surface within 10 minutes or do not start.
