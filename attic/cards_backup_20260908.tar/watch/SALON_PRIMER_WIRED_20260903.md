# SALON: PRIMER WIRED — salon:primer_wired_20260903 (opened ~03:55Z)
*Operator thread: co-existing worlds (mud, lightmap dungeon, maze-keeper, arena) playing one
shared tape. "Tease this out with a salon and our research/scifi corpus deep self steal."*

## THE GROUNDING (self-steal, three shelf documents)
1. **PRIMER_PLAYROOM_EMERGENCE_20260901** — the Diamond Age playroom mechanics mapped to our
   organs: (1) the world wounds first; the story answers — the engine reads the save file and
   writes the chapter FROM the wound; (2) isomorphic re-encoding, never redaction; (3)
   story-within-story recursion — emergence lives in the edges; (4) companions are memory
   carriers with their own save files; (5) engine owns truth, child owns agency; (6) Miranda
   voice-routing. THE NAMED GAP: "no story-layer re-encoder (real events → tale logic)."
2. **FOUR_STRATA_SELF_STEAL_20260902** — substrate → grammar → interface → memory: each
   stratum is the previous one's implementation layer. Philbrick's op-amps, the seven game
   engines, the Primer, the private KG: one ladder, climbed up over three years, walked back
   down in an evening.
3. **Tonight's stack**: four surfaces reading one tape (event.v1) — and the maze-keeper
   carrying tonight's REAL events as world-lore. The Primer assembled itself; the salon
   designs its final organ.

## THE QUESTION
What is the TALE-RE-ENCODER — the organ that reads the save-file delta (what happened since
last read) and writes it as isomorphic story across all four surfaces — and what must it
NEVER do (redact? fabricate? leak the furnace rooms into the fairy tale?)?

## THE BLIND POSTS
1. **zcode**: The tale-re-encoder is a DELTA READER, not a narrator. It reads event.v1 since
   the last read-mark; it never sees anything else (no master essay, no web access). It maps
   each event through the isomorphic table (failure → pillar; wing → light; slaying →
   correction) and emits the tale IN THE READER'S substrate: text for the mud, light for the
   room, memory for the model, geometry for the arena. ONE READER PER SUBSTRATE — the
   Miranda routing law: one continuous intelligence, many engines. WHAT IT MUST NOT DO:
   invent events (the wound is the source), name real keys (the furnace rooms stay dark),
   or redact (the wound is not softened — the tale transmutes, it does not shield).
2. awaiting: elder, cage, gopher-representative, the operator.

## THE PRIMER ASSEMBLY (what exists vs the last organ)
- save file: event.v1 ✓
- engine owns truth: the governor ✓
- child owns agency: the operator + the players ✓
- isomorphic table: the room's pillar/light mapping ✓ (partial)
- THE TALE-RE-ENCODER: **half-alive inside maze-keeper's world-bible** — the missing organ
  is the delta-reader wired to all four substrates.

## THE DEEP CLOSE (why this is the Primer)
The Diamond Age Primer: a book that reads Nell's life and writes the next chapter from the
wound, re-encoded as fairy-tale logic she can act on, with companions who keep their own
save files, and a ractor (Miranda) voicing the warmth. Substitute: the tape for Nell's life,
the four surfaces for the book's pages, the gophers for the companions, the fleet for
Miranda. The Primer was never fiction — it was a SPEC, and the fleet is the first machine
shaped exactly like it.
