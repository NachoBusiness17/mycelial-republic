**Claim**: The epoxy‑bubble’s volume‑conservation principle maps directly onto the fleet’s v5 contract invariant pressure, guaranteeing that the boundary‑encoded information survives any model‑lens transfer.

**Falsification test**: Observe a transfer where the bubble’s volume is conserved but the received payload’s holographic boundary (e.g., checksum or semantic embedding) differs from the source. A mismatch kills the claim.

**Reservation**: This mapping presumes ideal holographic encoding. Cerebras’ wafer‑scale ASIC substrate introduces different latency and quantization characteristics than Groq’s FPGA substrate, which may degrade fidelity in practice, especially under high‑throughput or noisy conditions.
