# CAPTURE INBOX — the bubble net
Paste anything, any time, any format. DeepSeek dumps, links, half-thoughts, asks, noise.
The processor lane sweeps every 30 min: dedupes, strips the meat, files the keepers, drops the junk.
Nothing here burns 5.3. Nothing here reaches main until it's distilled to a digest line.
Just type below the line. — the net
────────────────────────────────────────
<!-- cursor -->
