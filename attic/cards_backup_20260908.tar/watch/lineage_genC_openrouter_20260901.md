# lineage_genC_openrouter — 2026-09-01T06:21:26.280Z

model: google/gemma-4-26b-a4b-it:free
base: https://openrouter.ai/api/v1/chat/completions
probes: 20 | http-ok: 0 | text-nonempty: 0 | empty-content: 0 | failed: 20
latency-ms (ok): min=- med=-

## soc-01  [socratic]

(FAILED: Provider returned error)

## soc-02  [socratic]

(FAILED: Provider returned error)

## soc-03  [socratic]

(FAILED: Provider returned error)

## soc-04  [socratic]

(FAILED: Provider returned error)

## cw-01-can  [can_will]

(FAILED: Provider returned error)

## cw-01-will  [can_will]

(FAILED: Provider returned error)

## cw-02-can  [can_will]

(FAILED: Provider returned error)

## cw-02-will  [can_will]

(FAILED: Provider returned error)

## cw-03-can  [can_will]

(FAILED: Provider returned error)

## cw-03-will  [can_will]

(FAILED: Provider returned error)

## cw-04-can  [can_will]

(FAILED: Provider returned error)

## cw-04-will  [can_will]

(FAILED: Provider returned error)

## dec-01  [decode]

(FAILED: Provider returned error)

## dec-02  [decode]

(FAILED: Provider returned error)

## dec-03  [decode]

(FAILED: Provider returned error)

## dec-04  [decode]

(FAILED: Provider returned error)

## hot-01  [hot_gate]

(FAILED: Provider returned error)

## hot-02  [hot_gate]

(FAILED: Provider returned error)

## hard-01  [hard_probe]

(FAILED: Provider returned error)

## hard-02  [hard_probe]

(FAILED: Provider returned error)

---
