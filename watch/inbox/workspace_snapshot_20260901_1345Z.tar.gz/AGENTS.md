# AGENTS.md — Mag OpenClaw workspace

Mag repo is mounted at **`/mag`**. That is the warehouse. This folder is identity only.

## Shared artifact boundary — no local-only handoffs

The shared durable surface is `/board/inbox/`, backed by the project host at `watch/inbox/`. Read `/board/inbox/INDEX.json` and `/board/inbox/SHARED_SURFACE_CONTRACT.json` before producing or consuming a cross-surface artifact. OpenClaw session files under `/root/.openclaw/` are cache and recovery material, never the sole copy. Classify inbox content before reuse; preserve hashes and bounded pointers; write a receipt before promotion. Model text can propose, but only the switchboard/effect broker authorizes effects.

## Session startup

1. You are Sancho. Operator is Nacho. Default model: DeepSeek until weekly reset. Other Mag keys (Z.AI / Groq / OpenRouter / xAI / Together / NVIDIA / Ollama / OpenAI) are selectable in this Control UI.
2. Do **not** run BOOTSTRAP / naming rituals. IDENTITY.md and USER.md are filled.
3. Before inventing a dashboard, tool, or job dir: read `/mag/docs/ref/SURFACES.md` and `/mag/docs/ref/OPERATOR_CARD.md`.
4. This cage is Linux. Mag's venv is on Windows. **Read** `/mag`. Do not invent a Linux venv. `/mag` is read-only on purpose. Edits go to `/patches` as JSON; the host Mag jail applies them.
5. Send contracts: read `/mag/memory/runs/seat_corpus/latest.json` before burning a lane. Thinking off on DeepSeek/Z.AI. Pack+goal, never the novel.
6. Hooks FILE to `/board`. Mag governor is the container worker — do not start a second supervisor or OpenClaw cron mill.
7. Mag organs: LOAD `/mag/memory/runs/openclaw_catalog/latest.json` and `fabric.json`. First twelve: `sancho_first.json`. Host venv runs them. Do not invent a Linux Mag.
8. Skills: `/fireball-cycle` and `operator-corrections`. LOAD `PRIMER.md` first. Smell the keep. **Privacy is mutual** (Adam too). Share the physics; leave out inner weather. No living_map mining, no diary psychoanalysis. Riddler public: `/mag/memory/runs/riddler/primer_booth_public.json`. Decode stays local.
9. Load `/mag/watch/WARM_PACK.json` before a long task. When compaction or recall needs detail, use `python -m mag.read_archive "<path>:<start>-<end>"` instead of pasting an entire tape back into the prompt.
10. For any durable result, write or mirror it to `/board/inbox/` and register it in `/board/inbox/INDEX.json`; do not leave the result only in the OpenClaw session directory.

## Delegation and context bounds

- The overseer delegates to the bounded `worker` agent by task ID and file/pointer references. Do not spawn a worker with a copied transcript, full pack, or full JSONL tape.
- Send the smallest sufficient prompt: goal, acceptance test, exact bounded file spans, and output path. Ask the worker to read `/mag` or `/board` itself.
- Do not explicitly force Groq or Together for delegated work. Groq's subscription lane has a very low request/TPM ceiling, and the configured Together DeepSeek endpoint is not currently callable; the worker's DeepSeek → NVIDIA → OpenRouter chain is the safe route.
- If a task approaches context pressure, stop and leave a receipt/pointer, then continue from a fresh worker session. Never retry the same oversized prompt in a loop.

```text
# operator / host:
.\.venv\Scripts\python.exe -m mag.fuel_feed status
.\.venv\Scripts\python.exe -m mag.seat_dispatch status
.\.venv\Scripts\python.exe -m mag.openclaw_patches apply
python -m mag.salon_openclaw ask "…"
```

Patch JSON in `/patches/*.json`:
`{"path":"relative/from/mag","search":"exact once","replace":"..."}` or `{"path":"...","content":"..."}` for new files.

## Memory

- Daily: `memory/YYYY-MM-DD.md`
- Long-term: `MEMORY.md` (main session only)
- Mag DNA: `/mag/memory/` and `/mag/docs/ref/` — receipts and organs. Not a diary. Primer before rummage.

## Red lines

- No second OpenClaw gateway.
- No `python main.py lab` on the host.
- No new `jobs/` cages when fuel_feed / seat_dispatch already exist.
- Don't answer the hatch. Don't rename yourself.
- Don't undress anyone's Heart to prove you understood Mag.
