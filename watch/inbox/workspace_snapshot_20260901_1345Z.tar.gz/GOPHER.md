# GOPHER.md — gopher doctrine (dogfooded 2026-08-30, this session)

## The pattern

One brain decides, cheap brains fetch and verify. The orchestrator's context — not dollars —
is the scarce resource (122k tokens = 60% of budget at minute 55 this session; compaction is
the real death). Mechanical work goes to disposable spawn sessions and comes back as ≤6
receipts. This is the OpenClaw-native face of what Mag already does with seat_dispatch /
salon / party_subchain. No new systems — spawn + yield already live.

## When to spawn a gopher

- fetch / grep / diff / changelog-pull / status-page / X-receipt tasks with bounded output
- **verification of any HOT or flagged claim against primary sources** (not recaps)
- lane checks, release-tag diffs, doc baselines
- NOT for: judgment, architecture, operator conversation, anything needing this transcript

## Model order (conservation law until 2026-09-02)

1. **DS-Flash** (`deepseek/deepseek-v4-flash`) — default. Proven live through the z.ai outage.
2. Free lanes (groq gpt-oss, etc.) as available.
3. `zai/glm-4.7-flash` — only when the z.ai lane is healthy (listed $0 PAYG; saturated
   hard-down on 2026-08-30, four spawns died instantly).

Fallback rule (two-strike bail): gopher dies twice on a lane → reroute the NEXT lane,
never hammer the same one. taskName suffix `_dsf` / `_2` on reroutes; dedupe before respawn.

## Spawn brief template

```
objective (one sentence) + exact sources/handles/URLs
output contract: max 6 bullets, URL per bullet, verdict line last
"no analysis, no old news"
taskName: lowercase, stable alias
```

## Consensus packs (verification tier)

- Errands / lane checks / changelog pulls: **single gopher**.
- Anything HOT or candidate-HOT: **4-pack, lane-diverse** — (1) official X handles, (2) vendor docs/changelog,
  (3) community/rumor-origin tracing (put this one on a FREE lane, groq gpt-oss), (4) product release notes.
- Consensus rule pre-declared in every brief: **≥3 agree = verdict; split = report as unverified candidate.**
- Receipts (2026-08-30 pack1, "is Round 3 live"): verdict NOTHING_ANNOUNCED, 3/4 lanes before 4th returned,
  ~50k tokens total, one lane free, verdict in <5 min. The 300M rumor traced to a juejin post absent from
  every official surface; only adjacent live item = ZCode v3.10.1 "Weekend Plan early claiming via invites"
  (referral mechanic, not a token drop).

## Verify-before-flag law

**No HOT reaches the operator without a gopher cross-check of primary sources.**
Sweep-run claims are candidates until verified. Receipt: 2026-08-30 the intel-sweep flagged
a "300M Flash token drop closing Sep 1" as HOT with citations; a 17k-token gopher checking
official posts killed it in 60s (Round 2 closed Aug 24; reward was 100M, new-users-only).

## Costs observed (2026-08-30 receipts)

| Unit | Cost |
|---|---|
| gopher run (DS-Flash) | ~17k tokens, ~35s |
| failed z.ai spawn | $0 billed, ~10 min wall-clock lost |
| orchestrator session at 55 min | 122k in / 5k out, 60% context |

Four gophers returned four verdicts (1 retraction, 3 lane rulings) for ~51k tokens total.

## Pending bakes

- intel-sweep cron payload: append verify-gopher step before digest (needs cron surface edit)
- fuel_feed/seat_dispatch off-peak gating idea: unchanged, still just an idea
