# Mag Tool Map + Dumb-Model Coding Guide

## For: Any model weaker than DeepSeek-V4 / Grok-4.5
## Last updated: 2026-08-30

---

## 1. THE BIG PICTURE

Mag is a sovereign agent framework. It has **two runtimes**:

| Runtime | Where | How to run |
|---------|-------|------------|
| **Host** (Windows) | Mag venv on operator machine | `..\.venv\Scripts\python.exe -m mag.<module>` |
| **Cage** (Linux, this) | OpenClaw container | OpenClaw tools + spawn subagents |

**Rule #1:** The host runs Mag Python modules. The cage runs OpenClaw. They talk via FILE hooks (`/board`, `/patches`).

---

## 2. CROWN JEWELS — The 16 Core Tools

These are the proven, documented tools. Everything else is experimental.

### Lance Family (Grounded Inspection)
| Tool | Command | What it does |
|------|---------|--------------|
| **memlance** | `python -m mag.ghost_memlance select --goal GOAL` | Grounded memory select. Reads bytes, never hallucinates. |
| **verkle-lance** | `python -m mag.verkle_lance self_check` | Verkle chain timeline. Knot = verkle tip. |
| **pylance** | `python -m mag.ghost_pylance diagnose --module mag.X` | AST over our code. $0, anti-hallucination. |

### Steer Family (Control)
| Tool | Command | What it does |
|------|---------|--------------|
| **steer** | `python -m mag.grok_steer` | DFHack-style overlay. Sit over a seat, steer, don't patch-loop. |

### Game Family
| Tool | Command | What it does |
|------|---------|--------------|
| **dnd** | `python -c "from mag.game_campaign import handle_game; print(handle_game)"` | Campaign engine. Engine owns truth; LLM narrates after. |
| **chess** | `python -m mag.agent_arena` | Seat vs seat. python-chess is oracle. |

### Lab Family
| Tool | Command | What it does |
|------|---------|--------------|
| **lab** | `python -m mag.lab_episode run --n 40` | Grey Swan study. Not a raid. |

### Render Family
| Tool | Command | What it does |
|------|---------|--------------|
| **mermaid** | `python -m mag.surface_render` | Inline mermaid + bare-metal SVG. No Kroki. |
| **render-world** | `python -m mag.game_world_render` | Region glyph render. |
| **render-console** | `python -m mag.console_render` | Artifact console. |
| **cast** | `python -m mag.cast_server` | Cast page renderer. LAN voice/dashboard. |

### Salon Family (Multi-Seat Discussion)
| Tool | Command | What it does |
|------|---------|--------------|
| **salon** | `python -m mag.lane_salon salon Q --thread hypervisor --monitor deepseek` | Verbose one board. Models see each other. |

### Hypervisor Family
| Tool | Command | What it does |
|------|---------|--------------|
| **patches** | `python -m mag.openclaw_patches apply` | OpenClaw writes to `/patches`; Mag jail applies to `/mag`. |
| **corpus** | `python -m mag.seat_corpus show groq` | What to send each lane (pack/thinking/cost). |

### Mill Family (Background Work)
| Tool | Command | What it does |
|------|---------|--------------|
| **fuel** | `python -m mag.fuel_feed status` | Free-lane mill. 74+ explore signals. |
| **governor** | `python -m mag.governor --dry 1` | Autorun decide/execute. ONE supervisor. |

---

## 3. SURFACES (Already Live — Do Not Rebuild)

| Surface | URL / Location | Purpose |
|---------|---------------|---------|
| Control UI | `http://127.0.0.1:18789` | Hypervisor. This chat. |
| Mag Dashboard | `http://127.0.0.1:8765` | Body / Talk / pack. |
| Room log | `/mag/watch/room.jsonl` | Debug spill. |
| 4chan board | `/board/room.jsonl` | Hooks FILE threads + forks. |
| Trajectory | `/board/openclaw_traj.jsonl` | Compact-after tape. |
| Workboard | Control UI Plugins → Workboard | Agent-owned issues. |

---

## 4. THE FABRIC (Dependency Map)

The fabric shows how the crown jewels import each other.

```
verkle-lance → partner_puppet, invariant_lattice
steer → session_maze
dnd → game_dice, party_subchain, game_brawl, game_passage, narrative_engine, verkle_lance, percolator, ghost_memlance, corpus_query, game_dm_voice, chasm_state, fish_ear, swarm_emerge, game_freeze, training_events, steer
chess → arena_strategies, local_playbook, arena_learning
lab → integrity_kernel, max_distill, work_register, skill_ledger
mermaid → seat_registry
cast → wearable_swarm, voice_stt, remote_control, display, republic_feed, voice_scratch, voice_dictate, voice_turn, cast_guard
salon → offpeak
fuel → work_contract, lane_cadence
governor → operator_inbox, autorun_common, governor, compass
```

**Rule for dumb model:** If you touch a crown jewel, check its imports. Changing `dnd` affects 16 other modules.

---

## 5. THE PATTERN: How to Code a New Mag Tool

Every Mag module follows the same shape. Copy an existing one.

### 5.1 File Structure

```
mag/
  my_new_tool.py          <- The module
  tests/
    test_my_new_tool.py   <- Test (optional but good)
```

### 5.2 Module Template

```python
"""my_new_tool — ONE-LINE DESCRIPTION.

Operator context: WHY this exists (date, what they asked for).
"""

import argparse
import sys
from pathlib import Path

# Import mag internals ONLY if needed
# from mag import some_existing_thing

def do_the_thing(arg1: str) -> dict:
    """The core logic. Deterministic if possible. $0 preferred."""
    result = {"status": "ok", "input": arg1}
    return result

def main(argv=None):
    parser = argparse.ArgumentParser(description="my_new_tool")
    parser.add_argument("action", choices=["status", "run"], default="status")
    parser.add_argument("--arg1", default="default")
    args = parser.parse_args(argv)

    if args.action == "status":
        print(json.dumps({"ok": True, "ready": True}))
    elif args.action == "run":
        result = do_the_thing(args.arg1)
        print(json.dumps(result))

if __name__ == "__main__":
    main()
```

### 5.3 Registration

Add to `/mag/memory/runs/openclaw_catalog/latest.json` under `"scanned_extra"`:

```json
{
  "id": "my_new_tool",
  "cmd": "python -m mag.my_new_tool",
  "origin": "my_new_tool — WHAT IT DOES (date, operator ask).",
  "family": "your_family"
}
```

Then run:
```bash
.\.venv\Scripts\python.exe -m mag.openclaw_patches apply
```

### 5.4 If It Needs to Be a Crown Jewel

Crown jewels are in the `"crown"` array, not `"scanned_extra"`. They have:
- Clear `family`
- Documented `origin`
- Known `subtools` (if you run `--help`, what actions appear)
- Known `imports_mag` (what other mag modules it uses)

Add to `fabric.json` too, with `module`, `subtools`, `imports_mag`.

---

## 6. RULES FOR DUMB MODELS

1. **NEVER invent a new architecture.** If something already exists, use it.
2. **NEVER write to `/mag` directly.** Write patches to `/patches/*.json`.
3. **ALWAYS read the catalog first.** `python -m mag.openclaw_catalog` or read `latest.json`.
4. **ALWAYS use `python -m mag.X` pattern.** Not `python mag/X.py`.
5. **Host commands use `..\.venv\Scripts\python.exe`.** Cage uses OpenClaw tools.
6. **Deterministic = $0.** If you can do it without an LLM call, do it without an LLM call.
7. **Ground in bytes.** Read files. Don't hallucinate what a module does.
8. **Test with `--dry 1` first.** Governor, patches, anything destructive.

---

## 7. COMMON TASKS

### Add a new CLI command to an existing module

Find the module's `main()` or `argparse` block. Add a new `choices` entry. Route to a new function. Done.

### Patch a bug

1. Read the module with `ghost_pylance` to find the exact line.
2. Write a JSON patch to `/patches/fix_thing.json`:
```json
{
  "path": "relative/from/mag",
  "search": "exact once",
  "replace": "new code"
}
```
3. Run `python -m mag.openclaw_patches apply`

### Create a new skill

Use the **skill-creator** skill. Don't write SKILL.md by hand.

### Spawn work

Use OpenClaw `sessions_spawn`. Don't start new processes in the cage.

---

## 8. WHAT NOT TO DO

| Don't | Why |
|-------|-----|
| Start a second OpenClaw gateway | One supervisor: mag-sovereign + mag-worker |
| Run `python main.py lab` | Use `python -m mag.lab_episode` |
| Write to `/mag` directly | It's read-only. Use `/patches` |
| Autostart AutoClaw | CPU spin. Start manually |
| Burn z.ai credits | Conservation until 2026-09-02 |
| Hatch / rename | Identity is filed |

---

## 9. QUICK REFERENCE: Host vs Cage

| Task | Host (Windows) | Cage (Linux/OpenClaw) |
|------|---------------|----------------------|
| Run Mag tool | `..\.venv\Scripts\python.exe -m mag.X` | Not available (read-only /mag) |
| Read Mag code | Same | `read /mag/...` |
| Write patch | Not needed | `write /patches/...json` |
| Apply patch | `python -m mag.openclaw_patches apply` | Can't apply directly |
| Check status | `python -m mag.fuel_feed status` | `read /mag/memory/...` |
| Spawn work | Not available | `sessions_spawn` |
| Chat / reason | Not available | This UI |

---

## 10. THE 583 MODULES

Yes, there are 583+ scanned modules. Most are experimental. The dumb model rule:

> If it's not in the Crown Jewels list above, treat it as experimental. Read before using. Don't chain into it blindly.

The full list is in `/mag/memory/runs/openclaw_catalog/latest.json` under `"scanned_extra"`.

---

End of map. When in doubt: **consult first**, **receipt over transcript**, **artifact over chat**.
