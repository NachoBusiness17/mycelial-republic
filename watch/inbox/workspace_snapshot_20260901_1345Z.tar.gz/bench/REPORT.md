# GLM-4.7 Flash — Benchmark Report (empirical, 2026-08-30)

Subject: **z-ai/glm-4.7-flash** (also `zai/glm-4.7-flash`; on ZAI direct it is FREE; via OpenRouter $0.06/M in, $0.40/M out; 200K context; **text-only, no vision**; thinking/reasoning optional).

Method: 8-task suite × 5 models via OpenRouter (standardized API + pricing), objective graders. Tasks: 2 coding (algorithm + bug-fix), 1 Python refactor, TS async refactor, logic, math-expectation, structured JSON extraction, tool-call selection, instruction-adherence.

---

## 1. Ranked results (8-task suite, objective scores)

| Rank | Model | Avg score | Total cost (8 runs) | Avg latency | Cost/100 quality pts | Tokens/run |
|---|---|---|---|---|---|---|
| 1 | **DeepSeek-V4 Flash** | **92.5** | $0.0005 | 8.1s | $0.0005 | 426 |
| 1 | **Claude Opus 4.8** | **92.5** | $0.042 | 3.0s | $0.045 | 328 |
| 3 | **GPT-5.6 Luna** | 85.0 | $0.0024 | 3.3s | $0.0028 | 334 |
| 4 | **GLM-5.3 Flash** | 75.0 | $0.0014 | 7.7s | $0.0019 | 790 |
| 5 | **GLM-4.7 Flash** | **70.6** | $0.0029 | 15.7s | $0.0041 | 980 |

Per-category scores (GLM-4.7-flash):
- coding-algorithm: 85 | coding-bugfix: 100 | reasoning-logic: 60 | reasoning-math: 60
- knowledge/JSON-extraction: 100 | agentic tool-call: 80 | **coding-multi-step-refactor: 0** | instruction-adherence: 80

**Big picture: GLM-4.7-flash is genuinely strong at single-shot coding and structured extraction, but decisively weaker at multi-step reasoning and complex multi-step refactoring.**

---

## 2. Key empirical findings

### Critical failure mode (verified by controlled retest)
On the *TS async refactor* task (complex, multi-step), GLM-4.7-flash returned **empty output** — its reasoning mode consumed the **entire 2000-token budget** on the thinking trace (46s, finish_reason=length, 0 content tokens).

Controlled retest with reasoning mode forced:
- `reasoning=true`  → score 70, **truncated** (526 chars, finish=length, 2000 tokens, 28.6s)
- `reasoning=null` (default) → score 0, **empty**, 2000 tokens, 27.3s
- `reasoning=false` → score **100**, complete (744 chars), only **186 tokens**, **4.1s**

**Conclusion: GLM-4.7-flash's default reasoning behavior is unreliable on complex tasks — it can silently exhaust the token budget and return nothing. Disabling reasoning fixes it** (fast + correct).

### Latency is bimodal / unpredictable
- **Reasoning OFF + simple task:** genuinely flash-fast, ~0.7s after warmup (comparable to GPT-5.6-luna at ~0.7s; DeepSeek ~1-3s).
- **Reasoning engaged on complex task:** 15–46s, token-budget-exhaustive.
- Server-side variance is high (outlier samples of 7–18s seen across all providers).

### Cost
- On **ZAI direct, GLM-4.7-flash is FREE** — this is its single biggest advantage; in a real high-volume/embedded deployment the $0.0029 OpenRouter cost for 8 tasks (inflated by the reasoning burn) drops to $0 on ZAI.
- DeepSeek-V4 Flash remains cheaper-if-you-pay and far more consistent quality-per-dollar.

### Structural limitations
- **No vision** (text-only). GLM-5.3-flash is the multimodal sibling (also 1.3M ctx vs 200K).
- **200K context** — smallest in this comparison (DeepSeek/GPT-5.6/Opus all ≥1M).

---

## 3. Strengths of GLM-4.7 Flash
- **Excellent single-shot coding** (bug-fixing 100, algorithm 85) — near frontier for small, contained coding tasks.
- **Perfect structured/JSON extraction** (100) — very reliable data extraction.
- **FREE on ZAI direct** — unbeatable cost for bulk/embedded/high-frequency calls.
- **Reasoning-off latency is flash-grade** (~0.7s) — good for interactive/streaming use.
- Good tool-call selection for simple agentic steps (80).

## 4. Weaknesses of GLM-4.7 Flash
- **Reasoning-budget pathology** — complex multi-step tasks can return empty/truncated output because reasoning eats the whole `max_tokens` budget. **Must set `reasoning:{enabled:false}` or a generous `max_tokens`** in production.
- **Weak multi-step reasoning** (logic 60, math-expectation 60) — behind DeepSeek-V4-Flash and Opus (both 100), and behind GPT-5.6-luna (100 on logic).
- **Complex multi-step refactor: 0/100** — the one clear frontier gap; DeepSeek-V4-Flash, GPT-5.6, and Opus all scored 100 here.
- **No vision** — can't do image tasks that GPT-5.6 / GLM-5.3-flash / Opus handle.
- **200K context** — smallest of the cohort.
- **High variance / slower TTFB on larger prompts** — not consistently the fastest, despite the "flash" name (cost-driver is the reasoning tokens, not price).

---

## 5. Verdict — when to use it

**USE GLM-4.7 Flash when (it wins):**
- **Bulk / high-volume / embedded** workloads where **cost → $0 on ZAI direct** matter most (log summarization, classification, extraction, batch label/tag pipelines, chat caching).
- **Single-shot, self-contained coding** (bug-fix, small functions) and **JSON/structured extraction** — it's frontier-competitive and free.
- **Low-latency interactive chat** **with reasoning disabled** — flash-fast at ~0.7s.
- Budget-constrained RAG/agent scaffolds where 1M context isn't required and steps are simple.

**AVOID / delegate elsewhere (it falls short):**
- **Complex multi-step refactors** (empty-output risk) → use DeepSeek-V4-Flash / GPT-5.6 / Opus.
- **Hard multi-step reasoning** (logic puzzles, math derivations) → DeepSeek-V4-Flash or Opus.
- **Anything requiring vision** → GPT-5.6-luna, GLM-5.3-flash, or Opus.
- **1M+ context** → DeepSeek-V4-Flash (same cheap tier, 1M ctx, 92.5 avg) or GLM-5.3-flash.
- **As a default agentic "brain" for open-ended tasks** → DeepSeek-V4-Flash dominates it on quality at similar-or-lower effective cost in this environment.

**Bottom line:** GLM-4.7-Flash is a **great free workhorse for cheap, single-shot coding + extraction + simple chat at high volume (ZAI direct cost=$0)**. It is **not** a frontier reasoning/agentic model — DeepSeek-V4-Flash beats it on quality in this same box for ~nothing, and the reasoning-token-burn bug makes it unsafe as a default for complex multi-step prompts unless `reasoning` is disabled and `max_tokens` is raised. If you must use it, **force `reasoning:{enabled:false}` and set `max_tokens` generously**.
