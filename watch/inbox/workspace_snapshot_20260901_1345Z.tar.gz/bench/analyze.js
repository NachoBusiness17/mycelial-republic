#!/usr/bin/env node
const fs = require('fs');
const rows = fs.readFileSync('/root/.openclaw/workspace/bench/results.jsonl','utf8')
  .trim().split('\n').map(l => JSON.parse(l));

const byModel = {};
for (const r of rows) {
  if (r.error) { (byModel[r.model] ||= []).push({err:r.error,task:r.task}); continue; }
  (byModel[r.model] ||= []).push(r);
}

console.log('=== PER-MODEL SUMMARY (8 tasks) ===\n');
for (const [m, runs] of Object.entries(byModel)) {
  const ok = runs.filter(r => r.score !== undefined);
  const avg = ok.reduce((a, r) => a + r.score, 0) / Math.max(1, ok.length);
  const errs = runs.filter(r => r.err);
  const totalCost = ok.reduce((a, r) => a + (r.cost_usd||0), 0);
  const sumLat = ok.reduce((a, r) => a + r.latency_ms, 0);
  const sumTok = ok.reduce((a, r) => a + r.total_tokens, 0);
  console.log(`${m}`);
  console.log(`  avg_score=${avg.toFixed(1)} | errors=${errs.length} | total_cost=$${totalCost.toFixed(5)} | avg_latency=${(sumLat/ok.length/1000).toFixed(2)}s | avg_tokens=${Math.round(sumTok/ok.length)}`);
  const scores = ok.sort((a,b)=>a.task.localeCompare(b.task)).map(r=>`${r.task}:${r.score}`);
  console.log(`  ` + scores.join(' '));
  console.log('');
}

// Show the GLM coding_refactor failure detail
console.log('=== GLM-4.7-flash FAILURES (score 0) ===');
for (const r of rows) {
  if (r.model === 'z-ai/glm-4.7-flash' && r.score === 0) {
    console.log(`--- task ${r.task} ---`);
    console.log('content:', JSON.stringify(r.content));
    console.log('cost:', r.cost_usd, 'lat:', r.latency_ms, 'tokens:', r.prompt_tokens, '/', r.completion_tokens);
    console.log('');
  }
}
