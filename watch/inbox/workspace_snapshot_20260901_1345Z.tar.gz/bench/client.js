#!/usr/bin/env node
// Benchmark GLM-4.7-flash vs frontier models on a task suite.
// All calls via OpenRouter for fair side-by-side (standardized API + pricing).

const fs = require('fs');
function loadEnv() {
  const env = {};
  for (const line of fs.readFileSync('/mag/.env', 'utf8').split('\n')) {
    const l = line.trim();
    if (!l || l.startsWith('#') || !l.includes('=')) continue;
    const i = l.indexOf('=');
    env[l.slice(0, i).trim()] = l.slice(i + 1).trim();
  }
  return env;
}
const env = loadEnv();
const KEY = env.OPENROUTER_API_KEY;
const BASE = 'https://openrouter.ai/api/v1/chat/completions';

// configurable reasoning-effort param per provider
function modelParams(model) {
  const p = {};
  // openai gpt-5.x / grok / claude: use temperature 0 for determinism
  if (/glm|deepseek|gemini|gpt-5|opus/i.test(model)) {
    p.temperature = 0;
  }
  return p;
}

async function call(model, messages, maxTokens = 1500, extra = {}) {
  const body = {
    model,
    messages,
    max_tokens: maxTokens,
    ...modelParams(model),
    ...extra,
  };
  delete body.temperature_if_not; // safety noop
  const t0 = Date.now();
  let ttfb = null;
  try {
    const r = await fetch(BASE, {
      method: 'POST',
      headers: { Authorization: `Bearer ${KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!r.ok) {
      const txt = await r.text();
      return { error: `HTTP ${r.status}: ${txt.slice(0, 300)}`, latency_ms: Date.now() - t0, ttfb_ms: ttfb };
    }
    const j = await r.json();
    ttfb = Date.now() - t0;
    const u = j.usage || {};
    const msg = j.choices?.[0]?.message || {};
    // some models stream reasoning into reasoning_content
    const content = msg.content ?? '';
    const reasoning = msg.reasoning_content ?? '';
    return {
      latency_ms: Date.now() - t0,
      ttfb_ms: ttfb,
      prompt_tokens: u.prompt_tokens,
      completion_tokens: u.completion_tokens,
      total_tokens: u.total_tokens,
      cached_tokens: u.prompt_tokens_details?.cached_tokens ?? 0,
      content,
      reasoning_content: reasoning,
      finish_reason: j.choices?.[0]?.finish_reason,
    };
  } catch (e) {
    return { error: String(e).slice(0, 300), latency_ms: Date.now() - t0, ttfb_ms: ttfb };
  }
}

module.exports = { call, loadEnv };
