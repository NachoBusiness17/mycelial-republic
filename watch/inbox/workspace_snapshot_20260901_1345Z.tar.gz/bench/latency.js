#!/usr/bin/env node
// Latency/cost probe for "flash-grade" practical use: reasoning disabled, small task, repeated.
// Answers: is glm-4.7-flash actually FLASH-fast when reasoning is off? vs deepseek flash.
const fs = require('fs');
function loadEnv() {
  const env = {};
  for (const l of fs.readFileSync('/mag/.env', 'utf8').split('\n')) {
    const s = l.trim();
    if (!s || s.startsWith('#') || !s.includes('=')) continue;
    const i = s.indexOf('=');
    env[s.slice(0, i).trim()] = s.slice(i + 1).trim();
  }
  return env;
}
const env = loadEnv();
const PROMPT = 'Briefly: extract the two numeric values from "order #4821 total $99.50" as JSON {order_id, total}. Just JSON.';

async function run(model, n, reasoningOn) {
  const times = [];
  for (let i = 0; i < n; i++) {
    const body = {
      model,
      messages: [{ role: 'user', content: PROMPT }],
      max_tokens: 60,
      reasoning: { enabled: reasoningOn },
    };
    const t0 = Date.now();
    try {
      const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + env.OPENROUTER_API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const j = await r.json();
      const lat = Date.now() - t0;
      const u = j.usage || {};
      times.push({ lat, p: u.prompt_tokens, c: u.completion_tokens, content: (j.choices?.[0]?.message?.content || '').length });
    } catch (e) { times.push({ lat: -1, err: String(e).slice(0, 80) }); }
  }
  const ok = times.filter(t => t.lat > 0);
  const avg = ok.reduce((a, t) => a + t.lat, 0) / ok.length;
  console.log(`${model} reasoning=${reasoningOn} n=${n}: avg_lat=${(avg/1000).toFixed(2)}s | samples=${ok.map(t=>((t.lat/1000).toFixed(2))) }`);
}

(async () => {
  // warmup each once
  await run('z-ai/glm-4.7-flash', 2, false);
  await new Promise(r => setTimeout(r, 1000));
  await run('z-ai/glm-4.7-flash', 3, false);
  await new Promise(r => setTimeout(r, 1000));
  await run('z-ai/glm-4.7-flash', 3, true);
  await new Promise(r => setTimeout(r, 1000));
  await run('deepseek/deepseek-v4-flash', 3, false);
  await new Promise(r => setTimeout(r, 1000));
  await run('openai/gpt-5.6-luna', 3, false);
})().catch(e => console.log('ERR', String(e).slice(0, 300)));
