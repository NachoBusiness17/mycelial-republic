#!/usr/bin/env node
// List interesting models from OpenRouter + check OpenAI for GPT-5.6
const fs = require('fs');
function loadEnv(path) {
  const env = {};
  for (const line of fs.readFileSync(path, 'utf8').split('\n')) {
    const l = line.trim();
    if (!l || l.startsWith('#') || !l.includes('=')) continue;
    const i = l.indexOf('=');
    env[l.slice(0, i).trim()] = l.slice(i + 1).trim();
  }
  return env;
}
async function getJSON(url, key) {
  try {
    const r = await fetch(url, { headers: { Authorization: `Bearer ${key}` } });
    return { status: r.status, body: JSON.parse(await r.text()) };
  } catch (e) { return { error: String(e).slice(0, 200) }; }
}
(async () => {
  const env = loadEnv('/mag/.env');
  const or = await getJSON('https://openrouter.ai/api/v1/models', env.OPENROUTER_API_KEY);
  if (or.body && or.body.data) {
    const ids = or.body.data.map(m => m.id);
    const interesting = ids.filter(i => /glm|deepseek|gpt-5|opus|claude|grok|gemini|flash/i.test(i));
    console.log('OpenRouter total models:', ids.length);
    console.log('--- interesting (first 120) ---');
    console.log(interesting.slice(0, 120).join('\n'));
    // pricing for frontier ones we might use
    console.log('\n--- frontier pricing ---');
    const frontier = or.body.data.filter(m => /(gpt-5\.6|opus-4\.8|claude-opus|glm-4\.7|glm-5\.3|deepseek-v4|grok-4)/i.test(m.id));
    for (const m of frontier.slice(0, 30)) {
      const p = m.pricing || {};
      console.log(`${m.id} | ctx=${m.context_length} | prompt=$${p.prompt}/in $${p.completion}/out | ${m.architecture?.input_modalities?.join(',')}->${m.architecture?.output_modalities?.join(',')}`);
    }
  } else {
    console.log('openrouter:', JSON.stringify(or).slice(0, 500));
  }
  const oa = await getJSON('https://api.openai.com/v1/models', env.OPENAI_API_KEY);
  if (oa.body && oa.body.data) {
    const ids = oa.body.data.map(m => m.id);
    console.log('\nOpenAI gpt-5 models:', ids.filter(i => /gpt-5|o[0-9]|4\.8|5\.6/i.test(i)).join('\n') || '(none matching)');
  }
})();
