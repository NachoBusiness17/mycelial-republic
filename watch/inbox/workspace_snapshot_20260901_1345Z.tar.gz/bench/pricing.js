#!/usr/bin/env node
// Get pricing for the specific benchmark models
const fs = require('fs');
function loadEnv(path) {
  const env = {};
  for (const line of fs.readFileSync(path, 'utf8').split('\n')) {
    const l = line.trim();
    if (!l || l.startsWith('#') || !l.includes('=')) continue;
    const i = l.indexOf('=');
    env[l.slice(0, i).trim()] = l.slice(i + 1).trim();
  }
  return env;
}
(async () => {
  const env = loadEnv('/mag/.env');
  const r = await fetch('https://openrouter.ai/api/v1/models', { headers: { Authorization: `Bearer ${env.OPENROUTER_API_KEY}` } });
  const data = (await r.json()).data;
  const targets = /(glm-4\.7-flash|deepseek-v4-flash|claude-opus-4\.8|gpt-5\.6|glm-5\.3-flash|gpt-5\.5|gpt-5\.4|grok-4\.6|claude-opus-4\.7)/i;
  const matches = data.filter(m => targets.test(m.id) && !/batch/i.test(m.id) && !/:-/i.test(m.id));
  console.log('=== comparator model pricing (per M token) ===');
  for (const m of matches) {
    const p = m.pricing || {};
    const modal = (m.architecture?.input_modalities || []).join(',');
    console.log(`${m.id}\n  ctx=${m.context_length} | prompt=$${(+p.prompt*1e6).toFixed(4)}/M | completion=$${(+p.completion*1e6).toFixed(4)}/M | cache_read=$${(+p.input_cache_read*1e6).toFixed(4)}/M | input_mods=[${modal}] | reasoning_mandatory=${m.reasoning?.mandatory}`);
  }
})();
