#!/usr/bin/env node
// Probe available model endpoints for the benchmark. Never prints keys.
const fs = require('fs');
const { execSync } = require('child_process');

function loadEnv(path) {
  const env = {};
  const txt = fs.readFileSync(path, 'utf8');
  for (const line of txt.split('\n')) {
    const l = line.trim();
    if (!l || l.startsWith('#') || !l.includes('=')) continue;
    const idx = l.indexOf('=');
    env[l.slice(0, idx).trim()] = l.slice(idx + 1).trim();
  }
  return env;
}

async function getJSON(url, key) {
  try {
    const r = await fetch(url, { headers: { Authorization: `Bearer ${key}` } });
    const txt = await r.text();
    return { status: r.status, body: txt.slice(0, 2000) };
  } catch (e) {
    return { error: String(e).slice(0, 300) };
  }
}

async function postJSON(url, key, payload) {
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const txt = await r.text();
    return { status: r.status, body: txt.slice(0, 2000) };
  } catch (e) {
    return { error: String(e).slice(0, 300) };
  }
}

(async () => {
  const env = loadEnv('/mag/.env');
  const out = {};

  const zai = env.ZAI_API_KEY || env.ZAI_API_KEY_Pro;
  if (zai) {
    out.zai_probe = await postJSON('https://api.z.ai/api/paas/v4/chat/completions', zai, {
      model: 'glm-4.7-flash',
      messages: [{ role: 'user', content: 'reply exactly: OK' }],
      max_tokens: 5,
    });
  }

  if (env.DEEPSEEK_API_KEY) out.deepseek_models = await getJSON('https://api.deepseek.com/models', env.DEEPSEEK_API_KEY);
  if (env.OPENAI_API_KEY) out.openai_models = await getJSON('https://api.openai.com/v1/models', env.OPENAI_API_KEY);
  if (env.OPENROUTER_API_KEY) out.openrouter = await getJSON('https://openrouter.ai/api/v1/models', env.OPENROUTER_API_KEY);

  console.log(JSON.stringify(out, null, 1).slice(0, 12000));
})();
