#!/usr/bin/env python3
"""Probe available model endpoints for the benchmark. Never prints keys."""
import json, os, sys, urllib.request

def load_env(path="/mag/.env"):
    env = {}
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                env[k.strip()] = v.strip()
    return env

def get_json(url, key, extra=None):
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {key}",
                                                "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        body = e.read().decode()[:300]
        return {"_http_error": e.code, "_body": body}
    except Exception as e:
        return {"_error": str(e)[:300]}

env = load_env()
results = {}

# ZAI chat completion probe
zai = env.get("ZAI_API_KEY", "") or env.get("ZAI_API_KEY_Pro", "")
if zai:
    for ep in ["https://api.z.ai/api/paas/v4/chat/completions",
               "https://api.z.ai/api/v1/chat/completions"]:
        payload = json.dumps({"model": "glm-4.7-flash",
                              "messages": [{"role":"user","content":"reply with exactly: OK"}],
                              "max_tokens": 5}).encode()
        req = urllib.request.Request(ep, data=payload,
                                     headers={"Authorization": f"Bearer {zai}",
                                              "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                results[f"zai:{ep.rsplit('/',2)[1]+'/'+ep.rsplit('/',1)[1]}"] = json.load(r)
        except urllib.error.HTTPError as e:
            results[f"zai:{ep}"] = {"http_error": e.code, "body": e.read().decode()[:300]}
        except Exception as e:
            results[f"zai:{ep}"] = {"error": str(e)[:300]}

# DeepSeek models list
ds = env.get("DEEPSEEK_API_KEY","")
if ds:
    results["deepseek_models"] = get_json("https://api.deepseek.com/models", ds)

# OpenAI models list
oa = env.get("OPENAI_API_KEY","")
if oa:
    results["openai_models"] = get_json("https://api.openai.com/v1/models", oa)

# OpenRouter models (partial)
or_ = env.get("OPENROUTER_API_KEY","")
if or_:
    r = get_json("https://openrouter.ai/api/v1/models", or_)
    if isinstance(r, dict):
        ids = [m["id"] for m in r.get("data",[])][:400]
        interesting = [i for i in ids if any(k in i.lower() for k in
                       ["glm","deepseek","gpt-5","opus","claude","grok","4.5","4.7","5.3","5.6"])]
        results["openrouter_total"] = len(ids)
        results["openrouter_interesting"] = interesting[:80]
    else:
        results["openrouter"] = r

print(json.dumps(results, indent=1)[:8000])
