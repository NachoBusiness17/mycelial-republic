#!/usr/bin/env node
// Re-test GLM-4.7-flash coding_refactor with reasoning explicitly disabled.
const fs = require('fs');
function loadEnv() {
  const env = {};
  for (const l of fs.readFileSync('/mag/.env', 'utf8').split('\n')) {
    const s = l.trim();
    if (!s || s.startsWith('#') || !s.includes('=')) continue;
    const i = s.indexOf('=');
    env[s.slice(0, i).trim()] = s.slice(i + 1).trim();
  }
  return env;
}
const env = loadEnv();
const TASK = require('./tasks').find(t => t.id === 'coding_refactor');

async function run(withReasoning) {
  const body = {
    model: 'z-ai/glm-4.7-flash',
    messages: [
      { role: 'system', content: 'You are a careful precise AI.' },
      { role: 'user', content: TASK.prompt },
    ],
    max_tokens: 2000,
    temperature: 0,
  };
  if (withReasoning !== null) body.reasoning = { enabled: withReasoning };
  const t0 = Date.now();
  const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + env.OPENROUTER_API_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const j = await r.json();
  const u = j.usage || {};
  const msg = j.choices?.[0]?.message || {};
  return {
    reasoning_set: withReasoning,
    finish: j.choices?.[0]?.finish_reason,
    content_len: (msg.content || '').length,
    content: (msg.content || '').slice(0, 400),
    score: TASK.grader(msg.content || '').score,
    p: u.prompt_tokens, c: u.completion_tokens,
    lat_s: ((Date.now() - t0) / 1000).toFixed(1),
  };
}
(async () => {
  for (const mode of [true, false, null]) {
    const res = await run(mode);
    console.log(`reasoning=${res.reasoning_set} | finish=${res.finish} | score=${res.score} | content_len=${res.content_len} | lat=${res.lat_s}s | tokens p/c=${res.p}/${res.c}`);
    if (res.score === 0) console.log('  content:', JSON.stringify(res.content));
    await new Promise(r => setTimeout(r, 1500));
  }
})().catch(e => console.log('ERR', String(e).slice(0, 400)));
