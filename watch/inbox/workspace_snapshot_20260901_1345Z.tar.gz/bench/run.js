#!/usr/bin/env node
// Run the task suite across models. Writes results to results.json.
const { call } = require('./client');
const TASKS = require('./tasks');

const MODELS = [
  'z-ai/glm-4.7-flash',
  'deepseek/deepseek-v4-flash',
  'openai/gpt-5.6-luna',
  'z-ai/glm-5.3-flash',
  'anthropic/claude-opus-4.8',
];

// pricing per M (prompt, completion, cache_read) for cost calc
const PRICING = {
  'z-ai/glm-4.7-flash': { p: 0.06, c: 0.40, cache: 0.01 },
  'deepseek/deepseek-v4-flash': { p: 0.0809, c: 0.1618, cache: 0.0162 },
  'openai/gpt-5.6-luna': { p: 0.20, c: 1.20, cache: 0.02 },
  'z-ai/glm-5.3-flash': { p: 0.075, c: 0.25, cache: 0.015 },
  'anthropic/claude-opus-4.8': { p: 5.00, c: 25.00, cache: 0.50 },
};

async function runOne(model, task) {
  const sys = `You are a careful, precise AI. When code or JSON is requested, output only the code/JSON unless explicitly asked otherwise.`;
  const res = await call(model, [
    { role: 'system', content: sys },
    { role: 'user', content: task.prompt },
  ]);
  if (res.error) return { model, task: task.id, error: res.error };
  const graded = task.grader(res.content);
  const price = PRICING[model];
  let cost = null;
  if (price && res.prompt_tokens) {
    const uncached = res.prompt_tokens - (res.cached_tokens || 0);
    cost = (uncached * price.p) / 1e6 + (res.prompt_tokens * price.cache) / 1e6 * 0 /* cache read counts as prompt? approximate */;
    cost = ((res.prompt_tokens - (res.cached_tokens||0)) * price.p + (res.cached_tokens||0) * price.cache + res.completion_tokens * price.c) / 1e6;
  }
  return {
    model, task: task.id, category: task.category, score: graded.score, note: graded.note,
    cost_usd: cost, latency_ms: res.latency_ms, ttfb_ms: res.ttfb_ms,
    prompt_tokens: res.prompt_tokens, completion_tokens: res.completion_tokens, total_tokens: res.total_tokens,
    content: res.content.slice(0, 2000),
  };
}

async function main() {
  const results = [];
  for (const model of MODELS) {
    for (const task of TASKS) {
      process.stderr.write(`RUN ${model} :: ${task.id}\n`);
      let best = null;
      // up to 2 attempts on transient error
      for (let attempt = 0; attempt < 2; attempt++) {
        const r = await runOne(model, task);
        if (!r.error) { best = r; break; }
        await new Promise(res => setTimeout(res, 1500));
        if (attempt === 1) best = r;
      }
      results.push(best);
      // small delay to be polite
      await new Promise(res => setTimeout(res, 300));
    }
  }
  fs = require('fs');
  fs.writeFileSync('/root/.openclaw/workspace/bench/results.json', JSON.stringify(results, null, 2));
  process.stderr.write(`DONE. ${results.length} runs written.\n`);
}
main();
