#!/usr/bin/env node
// Robust benchmark runner: appends each result immediately to results.jsonl + progress file.
const { call } = require('./client');
const TASKS = require('./tasks');
const fs = require('fs');

const OUT = '/root/.openclaw/workspace/bench/results.jsonl';
const PROG = '/root/.openclaw/workspace/bench/progress.txt';

const MODELS = [
  'z-ai/glm-4.7-flash',
  'deepseek/deepseek-v4-flash',
  'openai/gpt-5.6-luna',
  'z-ai/glm-5.3-flash',
  'anthropic/claude-opus-4.8',
];

const PRICING = {
  'z-ai/glm-4.7-flash': { p: 0.06, c: 0.40, cache: 0.01 },
  'deepseek/deepseek-v4-flash': { p: 0.0809, c: 0.1618, cache: 0.0162 },
  'openai/gpt-5.6-luna': { p: 0.20, c: 1.20, cache: 0.02 },
  'z-ai/glm-5.3-flash': { p: 0.075, c: 0.25, cache: 0.015 },
  'anthropic/claude-opus-4.8': { p: 5.00, c: 25.00, cache: 0.50 },
};

function log(msg) { fs.appendFileSync(PROG, new Date().toISOString() + ' ' + msg + '\n'); }

async function runOne(model, task, maxTokens) {
  const sys = `You are a careful, precise AI. When code or JSON is requested, output only the code/JSON unless explicitly asked otherwise.`;
  const res = await call(model, [
    { role: 'system', content: sys },
    { role: 'user', content: task.prompt },
  ], maxTokens);
  if (res.error) return { model, task: task.id, error: res.error };
  const graded = task.grader(res.content);
  const price = PRICING[model];
  let cost = null;
  if (price && res.prompt_tokens) {
    const uncached = res.prompt_tokens - (res.cached_tokens || 0);
    cost = (uncached * price.p + (res.cached_tokens || 0) * price.cache + res.completion_tokens * price.c) / 1e6;
  }
  return {
    model, task: task.id, category: task.category, score: graded.score, note: graded.note,
    cost_usd: cost, latency_ms: res.latency_ms, ttfb_ms: res.ttfb_ms,
    prompt_tokens: res.prompt_tokens, completion_tokens: res.completion_tokens,
    total_tokens: res.total_tokens, reasoning_tokens: res.reasoning_content ? res.completion_tokens : 0,
    content: res.content.slice(0, 1200),
  };
}

async function main() {
  fs.appendFileSync(OUT, ''); // ensure exists
  const maxTok = {};
  for (const m of MODELS) maxTok[m] = (m.includes('opus') || m.includes('5.6')) ? 1200 : 2000;

  for (const model of MODELS) {
    for (const task of TASKS) {
      let best = null;
      for (let attempt = 0; attempt < 2; attempt++) {
        best = await runOne(model, task, maxTok[model]);
        if (!best.error) break;
        log(`RETRY ${model} :: ${task.id} :: ${best.error.slice(0,100)}`);
        await new Promise(res => setTimeout(res, 1500));
      }
      fs.appendFileSync(OUT, JSON.stringify(best) + '\n');
      log(`OK ${model} :: ${task.id} :: score=${best.score ?? best.error}`);
    }
  }
  log('ALL DONE');
}
main().catch(e => { log('FATAL ' + e); process.exit(1); });
