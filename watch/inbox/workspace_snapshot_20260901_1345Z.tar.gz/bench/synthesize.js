#!/usr/bin/env node
// Final synthesis: cost-per-quality and ranking table.
const fs = require('fs');
const rows = fs.readFileSync('/root/.openclaw/workspace/bench/results.jsonl','utf8')
  .trim().split('\n').map(JSON.parse);

const CAT = {}, avgByCat = {};
const byModel = {};
for (const r of rows) {
  if (r.error || r.score === undefined) continue;
  (byModel[r.model] ||= []).push(r);
}
// per-category score per model
const catNames = [...new Set(rows.map(r => r.category))];
console.log('=== SCORE BY CATEGORY ===');
console.log('model'.padEnd(26) + catNames.map(c=>c.padEnd(12)).join('') + 'AVG');
for (const [m, runs] of Object.entries(byModel)) {
  let out = m.padEnd(26);
  let sum = 0;
  for (const c of catNames) {
    const sc = runs.filter(r => r.category === c);
    const avg = sc.length ? sc.reduce((a, r) => a + r.score, 0) / sc.length : 0;
    sum += avg;
    out += (avg.toFixed(0) + '/100').padEnd(12);
  }
  out += (sum / catNames.length).toFixed(1);
  console.log(out);
}

console.log('\n=== COST PER QUALITY (per-100-quality-points, normalized) ===');
const results = [];
for (const [m, runs] of Object.entries(byModel)) {
  const avg = runs.reduce((a, r) => a + r.score, 0) / runs.length;
  const cost = runs.reduce((a, r) => a + (r.cost_usd || 0), 0);
  const lat = runs.reduce((a, r) => a + r.latency_ms, 0) / runs.length;
  const toks = runs.reduce((a, r) => a + r.total_tokens, 0) / runs.length;
  results.push({ m, avg, cost, lat, toks, cq: (cost / avg) * 100 });
}
results.sort((a, b) => a.cq - b.cq);
console.log('rank | model | avg_q | total_cost | latency_s | cost/100q | tokens/run');
results.forEach((r, i) => {
  console.log(`${i+1} | ${r.m.padEnd(24)} | ${r.avg.toFixed(1)} | $${r.cost.toFixed(5)} | ${(r.lat/1000).toFixed(1)} | $${(r.cq).toFixed(4)} | ${Math.round(r.toks)}`);
});
