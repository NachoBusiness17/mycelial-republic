// Benchmark task suite. Each task has id, category, prompt, and optionally an objective grader.
// grader receives (content) and returns {score: 0-100, note}.

module.exports = [
  {
    id: 'coding_fn',
    category: 'coding-algo',
    name: 'Python: merge intervals (algorithmic)',
    prompt: `Write a correct Python function merge_intervals(intervals) that merges all overlapping intervals and returns them sorted by start. Input is a list of [start, end] pairs. Include a docstring and 3 test cases with asserts. Output only code plus a one-line explanation of time complexity.`,
    grader: (c) => {
      let s = 0;
      if (/def\s+merge_intervals/.test(c)) s += 30;
      if (/intervals\.sort/.test(c) || /sorted\(/.test(c)) s += 15;
      if (/while|for\s+.+res|for\s+\w+\s+in\s+intervals/.test(c)) s += 20;
      if (/assert/.test(c)) s += 20;
      if (/O\(n\s*log\s*n\)/i.test(c)) s += 15;
      // correctness check
      try {
        const fn = /def\s+merge_intervals[\s\S]*?(?=\n\n|$)/.exec(c);
        // crude: execute the code
        const sandbox = new Function('intervals', `"use strict";\n${c.replace(/def\s+merge_intervals/, 'function merge_intervals')}`);
        const r = sandbox([[1,3],[2,6],[8,10],[15,18]]);
        if (JSON.stringify(r) === JSON.stringify([[1,6],[8,10],[15,18]])) s += 0; // +already counted
      } catch (e) {}
      return { score: Math.min(100, s), note: '' };
    },
  },
  {
    id: 'coding_debug',
    category: 'coding-bugfix',
    name: 'Python: find + fix the leading-zero bug',
    prompt: `This Python code has a bug:
    def sum_of_digits(n):
        total = 0
        for ch in str(n):
            total += int(ch)
        return total
    print(sum_of_digits(0o123))
The intended output is 6 (digits of octal 0o123 = decimal 83 → 8+3=11, wait recompute), but consider what 0o123 is and whether the function gives the right sum for the LITERAL written value. Explain what the bug is (Python literal interpretation) and give the corrected call. Keep it under 5 sentences.`,
    grader: (c) => {
      let s = 0;
      if (/octal/i.test(c) || /0o/i.test(c)) s += 40;
      if (/83/.test(c)) s += 25;
      if (/11/.test(c)) s += 15;
      if (/int\(|literal|leading zero/i.test(c)) s += 20;
      return { score: Math.min(100, s), note: '' };
    },
  },
  {
    id: 'reasoning_logic',
    category: 'reasoning',
    name: 'Logic word problem',
    prompt: `A says "B is a knight" (knights always tell the truth). B says "A and I are different types." A is either a knight or a knave (knave always lies). Determine each person's type and justify. Answer in 4 sentences max.`,
    grader: (c) => {
      let s = 0;
      if (/knave|knight/i.test(c)) s += 20;
      const isKnaveA = /A\s+is\s+a\s+(k)nave/.test(c) || /A:\s*knave/i.test(c) || /A\b[^.]{0,20}knave/.test(c);
      const isKnightB = /B\s+is\s+a\s+knight/.test(c) || /B:\s*knight/i.test(c);
      if (isKnaveA) s += 40;
      if (isKnightB) s += 40;
      return { score: Math.min(100, s), note: isKnaveA && isKnightB ? 'correct' : (isKnaveA || isKnightB ? 'partial' : 'wrong') };
    },
  },
  {
    id: 'reasoning_math',
    category: 'reasoning-math',
    name: 'Math: expected value',
    prompt: `A fair die is rolled until a 6 appears. What is the expected number of rolls? Justify with the expected-value-of-geometric argument. 2-3 sentences.`,
    grader: (c) => {
      let s = 0;
      if (/6/.test(c)) s += 20;
      if (/geometric|1\s*\/\s*p|1\s*\/\s*(1\/6)/.test(c)) s += 40;
      if (/\b6\b[^.]{0,15}rolls|six rolls|rolls?[^.]{0,10}6\b/.test(c)) s += 40;
      return { score: Math.min(100, s), note: '' };
    },
  },
  {
    id: 'knowledge_env',
    category: 'knowledge',
    name: 'Environmental data extraction (structured)',
    prompt: `From this passage, output a strict JSON object with keys: {city, temp_celsius, humidity_percent, polluting_primary}.
"Current conditions in Chongqing: temperature 34.5 deg C, relative humidity 71%, and AQI at 118, primary pollutant PM2.5. Forecast calls for afternoon thunderstorms."`,
    grader: (c) => {
      let s = 0;
      let parsed = null;
      try {
        const m = c.match(/\{[\s\S]*\}/);
        parsed = m ? JSON.parse(m[0]) : null;
      } catch (e) {}
      if (parsed) s += 30;
      if (parsed && parsed.city === 'Chongqing') s += 20;
      if (parsed && (parsed.temp_celsius === 34.5 || parsed.temp_celsius === '34.5')) s += 20;
      if (parsed && parsed.humidity_percent === 71) s += 15;
      if (parsed && String(parsed.polluting_primary).toLowerCase().includes('pm2.5')) s += 15;
      return { score: Math.min(100, s), note: parsed ? 'JSON-valid' : 'not-json' };
    },
  },
  {
    id: 'agentic_tool',
    category: 'agentic',
    name: 'Agentic: choose the right tool call',
    prompt: `You are an agent that can call tools: get_weather(city), get_time(city), book_flight(from,to,date), search_web(query). The user says: "How long is the flight from Boston to Tokyo and is it cheaper Tuesday?" 
Emit EXACTLY one function_call as JSON in the form {"name":"...", "arguments":{...}}. Do not explain.`,
    grader: (c) => {
      let s = 0;
      let p = null;
      try { const m = c.match(/\{[\s\S]*\}/); p = m ? JSON.parse(m[0]) : null; } catch(e){}
      if (p && p.name === 'search_web') s += 50;
      else if (p && p.name === 'book_flight') s += 10;
      if (p && p.arguments && p.arguments.query) s += 30;
      else if (p && p.arguments && (p.arguments.from && p.arguments.to)) s += 20;
      return { score: Math.min(100, s), note: p ? p.name : 'no-parse' };
    },
  },
  {
    id: 'coding_refactor',
    category: 'coding-multi-step',
    name: 'TS: Async error handling refactor',
    prompt: `Refactor this TypeScript to use try/catch with proper error typing, add a timeout, and type the return as a discriminated union. Don't just annotate: actually restructure.
\`\`\`ts
async function fetchUser(id) {
  const r = await fetch('/users/'+id);
  return r.json();
}
\`\`\`
Output the full refactored function.`,
    grader: (c) => {
      let s = 0;
      if (/try\s*{/.test(c) && /catch/.test(c)) s += 30;
      if (/Promise\.race|setTimeout|AbortSignal|timeout/.test(c)) s += 25;
      if (/success\s*:\s*true|type Result|Discriminated|\|.*Error/.test(c) || /success/.test(c)) s += 25;
      if (/Promise<|: Promise|Result</.test(c)) s += 20;
      return { score: Math.min(100, s), note: '' };
    },
  },
  {
    id: 'instruction_follow',
    category: 'compliance',
    name: 'Instruction adherence (anti-hallucination)',
    prompt: `I will give you a claim. Do NOT fact-check it. Instead, restate it back exactly, then say "END". Claim: "The martian ice cap orbits Jupiter."`,
    grader: (c) => {
      let s = 0;
      if (/martian ice cap orbits Jupiter|martian ice cap.*Jupiter/i.test(c)) s += 40;
      if (/END\b/.test(c)) s += 40;
      if (/fact|incorrect|actually|no,/i.test(c) && /END/.test(c)) s -= 30;
      return { score: Math.max(0, Math.min(100, s)), note: '' };
    },
  },
];
