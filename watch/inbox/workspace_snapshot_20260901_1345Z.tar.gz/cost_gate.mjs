#!/usr/bin/env node
/**
 * cost_gate.mjs — pre-dispatch cost guardrail v0 (cost_simulator invariant, mining move #3)
 *
 * Law: estimate-before-fire. The synthesis ruled: never resurrect cost_simulator as a
 * daemon; steal the invariant — a dispatch wave gets cost-gated BEFORE firing, from a
 * rate card, not post-hoc telemetry.
 *
 * Usage: node cost_gate.mjs --model <lane> --in <tok> --out <tok> [--label <why>]
 * Exit 0 = PASS (append receipt), exit 1 = BLOCK (append receipt).
 * Policy v0: free/plan lanes always PASS; paid lanes PASS only within --budget-usd
 * (default 0.05 per call); out-of-peak DeepSeek noted. Rate card from measured receipts
 * (MEMORY L46-47, UNTOUCHED_SURFACE §3). $0 lanes: groq/cerebras/nvidia/openrouter:free/ollama.
 */
import { appendFileSync, existsSync, readFileSync, writeFileSync } from "node:fs";

const RATES = {
  // $0 marginal
  "groq/openai/gpt-oss-120b": { in: 0, out: 0, tier: "free" },
  "cerebras/gpt-oss-120b": { in: 0, out: 0, tier: "free" },
  "nvidia/deepseek-ai/deepseek-v4-flash-0731": { in: 0, out: 0, tier: "free-credits(unverified-billing:do-not-spend)" },
  "openrouter/meta-llama/llama-3.3-70b-instruct:free": { in: 0, out: 0, tier: "free" },
  "openrouter/auto": { in: 0, out: 0, tier: "free-lanes-only-if-rotated(check-route)" },
  "ollama/qwen2.5-coder:7b": { in: 0, out: 0, tier: "local" },
  "zai/glm-5.3-flash": { in: 0.075, out: 0.25, cache: 0.015, tier: "plan($0-marginal-on-sub)" },
  "zai/glm-4.7-flash": { in: 0, out: 0, tier: "plan($0-marginal-on-sub)" },
  // measured paid
  "deepseek/deepseek-v4-flash": { in: 0.14, out: 0.28, cache: 0.03, tier: "paid(offpeak-half:01-04,06-10UTC Mon-Fri)" },
  "together/deepseek-ai/DeepSeek-V4-Flash-0731": { in: 0.14, out: 0.28, cache: 0.03, tier: "paid(batch-50pct)" },
};

const args = process.argv.slice(2);
const get = (k, d) => { const i = args.indexOf("--" + k); return i >= 0 ? args[i + 1] : d; };
const model = get("model", "");
const tin = parseFloat(get("in", "2000"));
const tout = parseFloat(get("out", "500"));
const budget = parseFloat(get("budget-usd", "0.05"));
const label = get("label", "unlabeled");

if (!RATES[model]) {
  console.log("BLOCK unknown-lane " + model + " — add to RATES with measured receipt first (no invented prices)");
  process.exit(1);
}
const r = RATES[model];
const est = (tin * r.in + tout * r.out) / 1e6;
const pass = est <= budget;
const row = { ts: new Date().toISOString(), model, tin, tout, est_usd: Number(est.toFixed(6)), budget_usd: budget, tier: r.tier, verdict: pass ? "PASS" : "BLOCK", label };
appendFileSync("/board/cost_gate_ledger.jsonl", JSON.stringify(row) + "\n");
console.log((pass ? "PASS" : "BLOCK") + " est $" + est.toFixed(6) + " (" + r.tier + ") in=" + tin + " out=" + tout + " — " + label);
process.exit(pass ? 0 : 1);
