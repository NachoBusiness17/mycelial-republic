#!/usr/bin/env node
// ctx_watch.mjs — NO SILENT 100% LAW, executable form.
// Measures the active main-session transcript. Exit codes: 0 OK, 1 WARN, 2 CRIT.
// One JSON line out. Used by night_shift_ticker every tick; callable by hand anytime.
import { readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const DIR = '/root/.openclaw/agents/main/sessions';
const WARN_MB = parseFloat(process.env.CTX_WARN_MB || '10');
const CRIT_MB = parseFloat(process.env.CTX_CRIT_MB || '16');

let best = null;
for (const f of readdirSync(DIR)) {
  if (!f.endsWith('.jsonl') || f.includes('checkpoint')) continue;
  const p = join(DIR, f);
  const st = statSync(p);
  if (!best || st.mtimeMs > best.mtimeMs) best = { file: f, path: p, mtimeMs: st.mtimeMs, bytes: st.size };
}
if (!best) { console.error(JSON.stringify({ error: 'no session jsonl found' })); process.exit(3); }
const mb = +(best.bytes / 1048576).toFixed(2);
const level = mb >= CRIT_MB ? 'CRIT' : mb >= WARN_MB ? 'WARN' : 'OK';
console.log(JSON.stringify({ ts: new Date().toISOString(), file: best.file, mb, warnAt: WARN_MB, critAt: CRIT_MB, level }));
process.exit(level === 'CRIT' ? 2 : level === 'WARN' ? 1 : 0);
