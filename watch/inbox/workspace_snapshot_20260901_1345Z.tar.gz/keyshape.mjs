// keyshape.mjs — shape check for a named env var in /mag/.env. Prints NO secret material.
import { readFileSync } from 'node:fs';
const name = process.argv[2] || 'OPENROUTER_API_KEY_2';
const line = readFileSync('/mag/.env', 'utf8').split(/\r?\n/).find(l => l.startsWith(name + '='));
const raw = line ? line.slice(name.length + 1) : null;
const v = raw ? raw.trim() : null;
const strip = v ? v.replace(/^["']+|["']+$/g, '') : null;
console.log(JSON.stringify({
  hasLine: !!line,
  trimmedLen: v ? v.length : null,
  quoted: !!(v && /^[\"']/.test(v)),
  prefixOk: !!(strip && strip.startsWith('sk-or-v1-')),
  lenOk: !!strip && strip.length >= 60 && strip.length <= 80,
  trailingJunk: !!(v && !/[a-zA-Z0-9]$/.test(v))
}));
