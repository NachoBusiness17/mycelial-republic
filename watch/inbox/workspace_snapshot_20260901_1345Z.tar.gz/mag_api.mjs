#!/usr/bin/env node
// mag_api.mjs — one-liner Mag API CLI (gateway http://mag-sovereign:8001)
// Usage:
//   node mag_api.mjs GET /health
//   node mag_api.mjs GET /room/thread/keep
//   node mag_api.mjs POST /room '{...json body...}'
// Key auto-resolved (MAG_API_KEY env => default mag-local-dev-key), never printed.
const BASE = process.env.MAG_API_BASE || "http://mag-sovereign:8001";
const KEY = process.env.MAG_API_KEY || "mag-local-dev-key";

const [, , method, path, bodyArg] = process.argv;
if (!method || !path) {
  console.error("usage: node mag_api.mjs GET|POST <path> [jsonBody]");
  process.exit(2);
}

const opts = { method, headers: { "X-API-Key": KEY } };
if (bodyArg) { opts.headers["Content-Type"] = "application/json"; opts.body = bodyArg; }

fetch(BASE + path, opts)
  .then(async (r) => {
    const text = await r.text();
    console.log(r.status + " " + text);
    if (!r.ok) process.exit(1);
  })
  .catch((e) => { console.error("ERR", (e.cause && e.cause.message) || e.message); process.exit(1); });
