#!/usr/bin/env node
// memory_rib_bounds.mjs — sidecar bounds for append-only tapes (originals NEVER rewritten).
// Usage: node memory_rib_bounds.mjs /board/openclaw_traj.jsonl
// Writes <tape>.bounds.jsonl: {n, sha256, bytes} per line + tape-level meta. Re-run is idempotent:
// already-bounded prefix is skipped (hash of first bounded line anchors the prefix).
import fs from "fs"; import crypto from "crypto";
const sha = (b) => "sha256:" + crypto.createHash("sha256").update(b).digest("hex").slice(0, 16);
const tape = process.argv[2]; if (!tape || !fs.existsSync(tape)) { console.error("usage: <tape.jsonl>"); process.exit(2); }
const sidecar = tape + ".bounds.jsonl";
const raw = fs.readFileSync(tape, "utf8");
const lines = raw.endsWith("\n") ? raw.slice(0, -1).split("\n") : raw.split("\n");
const prev = fs.existsSync(sidecar) ? fs.readFileSync(sidecar, "utf8").trim().split("\n").filter(Boolean).map(JSON.parse) : [];
const anchored = prev.length > 0 && prev[0].sha256 === sha(lines[0]);
const startN = anchored ? prev.length : 0;
const out = anchored ? prev.slice() : [];
for (let i = startN; i < lines.length; i++) out.push({ n: i + 1, sha256: sha(lines[i]), bytes: Buffer.byteLength(lines[i]) });
fs.writeFileSync(sidecar, out.map(o => JSON.stringify(o)).join("\n") + "\n");
const meta = { schema: "tape_bounds.v1", tape, lines: lines.length, bounded: out.length, prefixAnchored: anchored, tapeSha: sha(raw), ts: new Date().toISOString() };
fs.writeFileSync(tape + ".bounds.meta.json", JSON.stringify(meta, null, 1));
console.log(`bounds: ${out.length}/${lines.length} lines (prefixAnchored=${anchored})  tape_sha=${meta.tapeSha}`);
