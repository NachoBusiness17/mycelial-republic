#!/usr/bin/env node
// memory_rib_deref.mjs — read_archive(span) for the cage. Lossless dereference with bound checks.
// Convention: span = <path>:<start>-<end>  (lines, 1-indexed, INCLUSIVE, jsonl-native)
//             node memory_rib_deref.mjs <span>            -> print exact lines + bound check
//             node memory_rib_deref.mjs <concept-id>      -> resolve via /board/MEMORY_RIB.jsonl, print archive info
//             node memory_rib_deref.mjs <concept-id> --pull -> print the full artifact (hash-verified)
//             node memory_rib_deref.mjs --check           -> verify ALL RIB bounds (test-frame discipline)
// Exit 1 on any hash mismatch. Fail loud: a bad bound is a hole, not an error you can ignore.
import fs from "fs"; import crypto from "crypto";
const sha = (b) => "sha256:" + crypto.createHash("sha256").update(b).digest("hex").slice(0, 16);
const arg = process.argv[2]; const pull = process.argv.includes("--pull");
if (!arg) { console.error("usage: <path>:<start>-<end> | <concept-id> [--pull] | --check"); process.exit(2); }

if (arg === "--check") {
  const rib = fs.readFileSync("/board/MEMORY_RIB.jsonl", "utf8").trim().split("\n").map(JSON.parse);
  let pass = 0, fail = 0;
  for (const e of rib) {
    try {
      const body = fs.readFileSync(e.archive.path);
      (sha(body) === e.archive.sha256 && body.length === e.archive.bytes) ? pass++ : fail++;
      console.log((pass + fail), (sha(body) === e.archive.sha256 ? "PASS" : "FAIL"), e.id, e.archive.bytes + "B");
    } catch { fail++; console.log((pass + fail), "FAIL", e.id, "unreadable"); }
  }
  console.log(`BOUND CHECK: ${pass}/${rib.length} lossless, ${fail} defective`); process.exit(fail ? 1 : 0);
}

// concept-id path (no path separator, not a span)
if (!arg.includes(":")) {
  const rib = fs.readFileSync("/board/MEMORY_RIB.jsonl", "utf8").trim().split("\n").map(JSON.parse);
  const e = rib.find(x => x.id === arg);
  if (!e) { console.error("NO SUCH CONCEPT: " + arg); process.exit(2); }
  console.log(JSON.stringify({ id: e.id, tier: e.tier, authority: e.authority, gloss: e.gloss, archive: e.archive }, null, 1));
  if (pull) {
    const body = fs.readFileSync(e.archive.path);
    if (sha(body) !== e.archive.sha256) { console.error("BOUND MISMATCH — artifact drifted; refuse to serve"); process.exit(1); }
    process.stdout.write(body);
  }
  process.exit(0);
}

// span path: <path>:<start>-<end>  (end optional -> single line; lines 1-indexed inclusive)
const m = arg.match(/^(.+):(\d+)(?:-(\d+))?$/);
if (!m) { console.error("bad span: " + arg); process.exit(2); }
const [, path, s, e] = m;
const start = parseInt(s), end = e ? parseInt(e) : start;
if (start < 1 || end < start) { console.error("bad range"); process.exit(2); }
const lines = fs.readFileSync(path, "utf8").split("\n");
if (end > lines.length) { console.error(`range past EOF (${lines.length} lines)`); process.exit(2); }
const slice = lines.slice(start - 1, end).join("\n");
console.log(`# span ${path}:${start}-${end}  lines=${end - start + 1}  bound=${sha(slice)}`);
console.log(slice);
