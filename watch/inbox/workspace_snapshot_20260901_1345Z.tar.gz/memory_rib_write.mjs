#!/usr/bin/env node
// memory_rib_write.mjs — RIB-format memory catalog writer + warmer (v0)
// RIB mapping: ObjectBegin=concept defn, ObjectInstance=citation,
// Procedural DelayedReadArchive=bounded artifact span, DetailRange=tier,
// scope stack: warming opens scopes; compaction illegal while open (enforced by convention here).
// Law: append-only originals, hash bounds, deref = exact span read = lossless.
import fs from "fs"; import crypto from "crypto";
const sha = (b) => "sha256:" + crypto.createHash("sha256").update(b).digest("hex").slice(0, 16);
const now = () => new Date().toISOString();
const concepts = JSON.parse(fs.readFileSync("/board/MEMORY_RIB_CONCEPTS.json", "utf8")).concepts;
const rib = []; const warm = []; const defects = [];
for (const c of concepts) {
  let stat; try { stat = fs.statSync(c.canonical); } catch { defects.push(`MISSING ${c.id} -> ${c.canonical}`); continue; }
  const body = fs.readFileSync(c.canonical);
  const hash = sha(body);
  const entry = {
    op: "ObjectBegin", id: c.id, ts: now(),
    tier: c.tier, authority: c.authority, gloss: c.gloss, volatile: !!c.volatile,
    archive: { kind: "DelayedReadArchive", path: c.canonical, byteRange: [0, stat.size],
               sha256: hash, bytes: stat.size, lossless: true }
  };
  rib.push(entry);
  // Warming: L0/L1 spines go warm (handle+bounds+gloss only, no body). L2 stays archive-only.
  if (c.tier === "L0" || c.tier === "L1") warm.push({ op: "ObjectInstance", id: c.id, bound: hash, gloss: c.gloss, deref: `read ${c.canonical} bytes 0-${stat.size}` });
  else warm.push({ op: "Procedural", id: c.id, archive: c.canonical, bound: hash, note: "deferred; deref on frustum hit only" });
}
const out = { schema: "memory_rib.v1", ts: now(), world: "mag-memory",
  scope_stack: { open: [], law: "compaction/drop of any entry is illegal while any scope is open" },
  entries: rib, defects };
fs.writeFileSync("/board/MEMORY_RIB.jsonl", rib.map(e => JSON.stringify(e)).join("\n") + "\n");
const warmPack = { schema: "warm_pack.v1", ts: now(), world: "mag-memory",
  shape_hash: sha(JSON.stringify(warm)),
  law: ["load this spine first; deref archives only on mention-intersection",
        "full fidelity guaranteed by sha256 bounds; originals append-only, never rewritten",
        "authority label rides on every handle; roast never authorizes"],
  spine: warm, defects };
fs.writeFileSync("/board/WARM_PACK.json", JSON.stringify(warmPack, null, 1));
console.log("RIB entries:", rib.length, "| warm spine:", warm.length, "| defects:", defects.length);
for (const d of defects) console.log("  DEFECT:", d);
const l0l1 = warm.filter(w => w.op === "ObjectInstance").length;
console.log("warm bytes (spine only):", JSON.stringify(warmPack).length, "| L0+L1 warm:", l0l1, "| L2 deferred:", warm.length - l0l1);
