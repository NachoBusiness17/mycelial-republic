#!/usr/bin/env node
/**
 * memory_riddler_sync.mjs — one-way mirror: /board/riddler_common.jsonl -> memory/riddler_common.md
 *
 * Riddler law: the bus is the sanitized lane (public forms only, charter-filtered at write time).
 * This mirror makes that surface searchable by OpenClaw memory search (local FTS, provider=none,
 * nothing leaves the cage). Direction is one-way: bus -> memory. Never write back.
 * Run after any append to /board/riddler_common.jsonl.
 */
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { createHash } from "node:crypto";

const BUS = "/board/riddler_common.jsonl";
const OUTS = [
  "/root/.openclaw/workspace/memory/riddler_common.md",
  "/root/.openclaw/workspace-worker/memory/riddler_common.md",
];

if (!existsSync(BUS)) {
  console.error(`bus missing: ${BUS}`);
  process.exit(1);
}
const raw = readFileSync(BUS, "utf8");
const lines = raw.split("\n").filter((l) => l.trim().length > 0);
const events = [];
for (const [i, line] of lines.entries()) {
  try {
    events.push(JSON.parse(line));
  } catch {
    console.error(`SKIP malformed line ${i + 1}`);
  }
}
const sha = createHash("sha256").update(raw).digest("hex").slice(0, 16);

const body = events
  .map((e) => {
    const ts = e.ts ?? "unknown";
    const type = e.type ?? "event";
    const auth = e.authority ?? "unclassified";
    const seat = e.seat ?? "unknown";
    const physics = (e.physics ?? "").replace(/\n+/g, " ");
    return `## ${ts} · ${type}\n- authority: ${auth}\n- seat: ${seat}\n- physics: ${physics}\n`;
  })
  .join("\n");

const doc = `# Riddler Common (mirrored from /board/riddler_common.jsonl)

> One-way mirror for memory search. Source of truth: the bus. This file is generated —
> do not edit; re-run node memory_riddler_sync.mjs after bus appends.
> Charter: sanitized lane, public forms only — strips geography/identifiers/secrets/Heart
> contents, keeps physics. A roast can become a proposal; it cannot become a permission.
> Bus sha256[:16] at generation: ${sha} · events: ${events.length}

${body}
`;
mkdirSync("/root/.openclaw/workspace/memory", { recursive: true });
mkdirSync("/root/.openclaw/workspace-worker/memory", { recursive: true });
for (const out of OUTS) writeFileSync(out, doc, { mode: 0o666 });
console.log(`mirrored ${events.length} events -> ${OUTS.join(" + ")} (bus sha ${sha})`);
