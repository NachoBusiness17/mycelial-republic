# Personal Mixture-of-Experts (MoE) Routing System — Design Document

**Version:** 1.0 · **Author:** OpenClaw (webchat) · **Date:** 2026-08-30

A personal MoE that turns seven different models into one coherent, cost-aware
answering system. It decides *which* model to use for a task, *how* to present the
task to that model, *when* to ask several models and merge, and *what to do when a
model fails* — all behind a single `run` command.

---

## 1. Overview & Goals

| Goal | Mechanism |
|---|---|
| Pick the right tool for the job | **Routing layer** (task classification → model selection) |
| Present tasks optimally per model | **Prompt compiler** (JIT recompile, chunking, markers, cache) |
| Combine / choose among answers | **Output merger** (aggregation, retry, scoring, selection) |
| Never fail hard on one bad model | **Fallback chain** + **retry with backoff** |
| Know how well it's doing | **Logging + JSONL monitoring** |

The system is intentionally **dependency-light** (Node 22 built-ins only: `fetch`,
`node:test`, `fs`). It calls models over their HTTP APIs. It runs fully offline for
routing/benchmarking with a deterministic *model oracle* when no API keys are present,
so it is testable in CI with zero credentials.

### Model fleet (from `config.json`)

| Model | Provider | Quality | Latency(s) | $/1k in→out | License | Role |
|---|---|---|---|---|---|---|
| glm-5.3-flash | z.ai | 8.2 | 1.8 | 0.0012→0.004 | prop. | **default workhorse** |
| deepseek-v4-flash | deepseek | 7.8 | 2.2 | 0.0006→0.0018 | prop. | cheap coder / reasoning |
| claude-opus-4.8 | anthropic | 9.6 | 3.5 | 0.0125→0.0625 | prop. | scarce frontier, deep reasoning |
| gpt-5.6-luna | openai | 9.2 | 3.0 | 0.0080→0.0400 | prop. | strict structured / planning / agentic |
| grok-2.1-ultra | xai | 8.8 | 2.8 | 0.0040→0.016 | prop. | breadth, current events, creative |
| qwen2.5-coder:7b | ollama | 6.5 | 1.2 | 0→0 | Apache-2.0 | **free, local, private** |
| gpt-oss-120b | groq | 7.4 | 0.9 | 0.0005→0.0008 | Apache-2.0 | very fast, high-throughput |

> Quality is a 0–10 editorial score used as the offline benchmark oracle's base.

---

## 2. Architecture

```
          task text
              │
   ┌──────────▼──────────┐
   │  ANALYZER           │  detect task_type, sensitivity, budget,
   │  (analyzer.js)      │  strict_json, ambiguity, ensemble hint
   └──────────┬──────────┘
              │ routing decision (rules table)
   ┌──────────▼──────────┐
   │  ROUTER             │  build execution plan [primary, f1, f2]
   │  (orchestrator.js)  │  apply privacy override / budget override
   └──────────┬──────────┘
              │
   ┌──────────▼──────────┐
   │  PROMPT COMPILER    │  JIT compile → chunking + boundary markers → cache
   │  (prompt_compiler.js)│  produces [system, user] messages
   └──────────┬──────────┘
              │
   ┌──────────▼──────────┐        ┌─────────────┐
   │  MODEL ADAPTERS      │───►   │  retry/user  │   per model, with backoff
   │  (client.js)         │        │  fallback chain
   └──────────┬──────────┘        └─────────────┘
              │
   ┌──────────▼──────────┐
   │  OUTPUT MERGER      │  score each output, aggregate / rank / select best
   │  (merger.js)        │
   └──────────┬──────────┘
              ▼
         final answer + metrics
   (total cost, latency, winner, ranked list)
```

**Two execution modes:**

- **Serial (default):** primary model → if it fails, next fallback → … Stop at first success.
- **Ensemble (opt-in via rules or `--ensemble`):** run up to `max_ensemble_models`
  (default 3) in **parallel**, score all, pick the best. Used for review/analysis/creative
  tasks where an independent second opinion raises recall. Ensemble is **disabled for
  privacy-sensitive tasks** (a second copy of a secret to another provider is never sent).

---

## 3. Routing Layer

### 3.1 Task analysis (heuristic, no LLM required)

The `analyzer` inspects the prompt string:

- **Task type** — keyword scoring against `routes.json` rules. `code_generation` and
  `privacy_sensitive` carry **weighted cues** (e.g. `function`, `implement`, `def`) so
  they beat generic NLP keywords (`json`, `parse`) in tie cases.
- **Sensitivity** — scan for `secret`, `password`, `token`, `credential`, `private`,
  `local only`, `ssh key`, `api key`, `pii`, … **Overrides routing to the local model**
  first (see §3.3).
- **Budget** — `/fast` `/cheap` → `low`; `/quality` `/opus` → `high`; else rule budget.
- **Strict JSON** — if output should be structured (`json`, `fields for`, `as a JSON…`).
- **Ambiguity** — count of hedge phrases (`either`, `which is best`, `not sure`, `…`)
  → nudges toward ensemble when genuinely undecided.

### 3.2 Routing rules table (`routes.json`)

Each rule: `task_type → primary → fallbacks → ensemble? → why`.

| Task type | Primary | Fallbacks (order) | Ensemble | Rationale |
|---|---|---|---|---|
| code_generation | deepseek-v4-flash | qwen2.5-coder →
gpt-oss-120b → opus | – | cheap+verifiable; local/offline option |
| code_review | **gpt-oss-120b** | grok → deepseek | ✔ | independent readers catch different bug classes |
| reasoning | claude-opus-4.8 | grok → glm | – | deep reasoning needs top shelf |
| analysis | grok-2.1-ultra | opus → glm | ✔ | breadth + ensemble recall |
| summarization | glm-5.3-flash | deepseek → grok | – | fast, faithful |
| rag_retrieval_answer | glm-5.3-flash | deepseek → grok | – | grounded QA, marker-aware |
| nlp_extraction | gpt-5.6-luna | glm → deepseek | – | strict structured output |
| translation | glm-5.3-flash | grok → deepseek | – | multilingual + cost |
| creative_writing | grok-2.1-ultra | opus → glm | ✔ | pick most coherent draft |
| planning | gpt-5.6-luna | opus → glm | – | plan quality; no mode-collapse |
| conversation | glm-5.3-flash | grok | – | latency-sensitive |
| **privacy_sensitive** | **qwen2.5-coder:7b** | gpt-oss-120b | **never** | never send secrets to hosted APIs |
| *default* | glm-5.3-flash | deepseek → grok | – | general workhorse |

### 3.3 Fallback rules

- Plan = `[primary, f1, f2, …]` capped at `fallback_max_depth + 1` (default 3).
- Privacy override: if `sensitivity` is true, *replace* the plan with the
  `privacy_sensitive` rule's local model first — regardless of detected task type.
- A model is skipped if it is **unavailable** (no API key in env), so you never wait on
  a credential you haven't set.
- After the chain is exhausted with **zero survivors**, the orchestrator logs a structured
  error and returns `{ ok:false, errors:[…] }` — it does **not** invent success.

### 3.4 Availability

`isAvailable(model)` = provider `ollama` (local) → always up; else requires the env key
named in config. `node src/moe.js models` prints the fleet with availability.

---

## 4. Prompt Compiler (`prompt_compiler.js`)

- **JIT recompilation** — a compiled prompt is keyed by SHA-256 of `(task, model_id)`.
  On a hit within the TTL it returns the exact cached message array; else rebuilds.
  `evict()` runs a rolling sweep so the cache stays bounded and fresh.
- **System prompt** — built from a shared precedent + task framing + output contract:
  `outputFormat`, `strictJson`, `outputContract`, `maxLength`, plus a `[routed via …]`
  tag naming the model and task type (so a model knows its own role).
- **Chunking for long context** — if the source exceeds `max_context_util × context_window
  − max_output_tokens`, the source is split with greedy char-aware chunking (size +
  overlap), each chunk wrapped in a **boundary marker** (`--- CHUNK N/N ---`), and the real
  **INSTRUCTION is placed after the source** so the model answers rather than extends.
- **Boundary markers** are also scored by the merger: leaked markers in the output lower
  `prompt_adherence`, catching the classic "model just echoes the chunk header" failure.

---

## 5. Output Merger (`merger.js`)

### 5.1 Scoring (no second LLM — cheap, deterministic)

`score = Σ w_i · axis_i` with weights from `config.output.scoring.weights`:

| Axis | Meaning |
|---|---|
| prompt_adherence (0.35) | JSON parses (if strict); penalty for leaked chunk markers |
| information_density (0.25) | ratio of significant chars to total |
| self_consistency (0.25) | low repetition of leading sentence fragments |
| concision (0.15) | near-200-char "sweet spot", penalized as length balloons |

### 5.2 Retry (`runWithRetry`)

- Attempts up to `max_attempts` (default 3) with exponential backoff + jitter
  (`base 1.5s`, cap `12s`).
- Retriable taxonomies normalized by adapter: `rate_limit`, `timeout`, `server_error`,
  `connection_error` (from HTTP 429/500/502/503/504 and `AbortError`).
- Non-retriable (auth, bad_request, empty) fail fast so you don't hammer a bad key.

### 5.3 Selection

- Sort by `score`, tie-break by **cost** (`output.selection.mode = "best"`).
- Return the winner plus a `ranked` array (model / score / cost / latency) for the caller.
- Aggregation returns: `text`, `model`, `score`, `total_cost_usd`, `total_latency_ms`,
  `attempts`, `ranked`.

---

## 6. Configuration (`config.json`)

Single JSON controlling everything:

- `models` — per model: provider, base_url, env_key, model_id, context_window,
  max_output_tokens, cost_per_1k_in/out, avg_latency_sec, quality_score, parallel_ok,
  license, strengths, notes.
- `routing` — confidence thresholds, fallback depth, ensemble flags.
- `prompt` — jit toggle, cache TTL, chunk size/overlap, max context utilization, markers.
- `output` — scoring weights, retry params, selection mode.
- `log` — level, file targets (moe.log + monitor.jsonl), color.
- `benchmarks` — output path + default rounds.

---

## 7. CLI (`src/moe.js`)

```
node src/moe.js run "task…" [--model X] [--ensemble 0|1] [--json] [--file path]
node src/moe.js route "task…"      # show routing decision, no model call
node src/moe.js models             # fleet + availability + cost
node src/moe.js rules [TASK_TYPE]  # inspect routing table
node src/moe.js bench [--rounds N] [--out f.json] [--live]
node src/moe.js monitor            # tail metrics
echo "text" | node src/moe.js run  # pipe input
```

`bench` without `--live` uses the **offline deterministic oracle** (quality = editorial
score × per-task-type weight − latency penalty) → reproducible cost/quality tradeoffs with
no keys. With `--live` it calls real endpoints.

---

## 8. Error Handling Summary

| Failure | Detected by | Handling |
|---|---|---|
| Missing API key | `isAvailable` | skip model in plan, never wait |
| 429 / 5xx / timeout | adapter taxonomy | retry w/ backoff, then next fallback |
| Empty completion | adapter | treated as failure, next fallback |
| All models fail | orchestrator | structured error object, JSONL `run_failed` event |
| Strict-JSON emitted unparseable | merger | `prompt_adherence=0` sinks its score |
| Chunk marker leak | merger | `prompt_adherence` penalty |

---

## 9. Direct Use as a Library

```js
const MoE = require('./src/orchestrator');
const moe = new MoE();                     // reads ./config.json + ./routes.json
const out = await moe.runTask({ text: 'write …', prompt: 'write …' });
console.log(out.text, out.model, out.total_cost_usd);
```

API keys are read from the env vars named in `config.json` (`ZAI_API_KEY`,
`DEEPSEEK_API_KEY`, `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `XAI_API_KEY`,
`GROQ_API_KEY`). Ollama needs no key.

---

## 10. Verification & Tests

`node --test tests/moe.test.js` — 10 offline unit tests covering routing (code /
privacy / reasoning), strict-JSON detection, prompt chunking + markers + cache, score
penalties, and cost math. See `bench/results.json` for the tradeoff benchmark.
