# Personal MoE — OpenClaw Model Router

Turn seven models into one coherent, cost-aware answering system.
Pick the right model per task, compile the prompt per model, ask several and merge,
stay up when any single provider fails.

```
GLM-5.3 Flash ⌐           DeepSeek-V4 Flash    Claude Opus 4.8      GPT-5.6 Luna
Grok-2.1 Ultra                                      │
Ollama qwen2.5-coder:7b                             ▼
Groq gpt-oss-120b          ┌──────────────────────────────┐
                           │        personal-moe          │
                           │  analyze → route → compile   │
                           │  → execute → retry → merge   │
                           └──────────────────────────────┘
                                       │
                                   one answer
                                  + metrics
```

## Requirements

- Node.js ≥ 18 (uses built-in `fetch`). No npm install needed.
- API keys via env vars (see below). Ollama runs keyless and locally.
- Runs fully offline for routing + benchmarking (deterministic model oracle).

## Install / setup

```bash
cd moe
# optional keys (set only the providers you use)
export ZAI_API_KEY=…        # glm-5.3-flash (default workhorse)
export DEEPSEEK_API_KEY=…
export OPENAI_API_KEY=…
export XAI_API_KEY=…
export GROQ_API_KEY=…
export ANTHROPIC_API_KEY=…  # claude-opus-4.8 — absent⇒treated unavailable
# Ollama: no key needed
ollama pull qwen2.5-coder:7b
```

## Quick start

```bash
# interactive prompts / piped input
node src/moe.js run "write a node function isPalindrome(s) that returns true"
echo "summarize: TDD improves quality by …" | node src/moe.js run

# force a specific model
node src/moe.js run "solve: 35 heads, 94 legs, how many chickens?" --model claude-opus-4.8

# force (or suppress) ensemble voting
node src/moe.js run "compare postgres vs sqlite for offline analytics" --ensemble 1

# structured JSON output
node src/moe.js run "extract people/orgs as JSON …" --model glm-5.3-flash --json

# see the routing decision without calling a model
node src/moe.js route "analyze pros and cons of serverless platforms"

# inspect the fleet
node src/moe.js models
node src/moe.js rules reasoning
```

## Benchmark (cost / quality tradeoffs)

```bash
node src/moe.js bench                                   # offline oracle, ~instant
node src/moe.js bench --rounds 5 --out bench/results.json
node src/moe.js bench --live                            # real endpoints (needs keys)
```

Offline mode derives quality from editorial scores per task type and is deterministic —
great for CI and for understanding *why* the router picks what it picks. See
`bench/results.json`.

## Monitoring

```bash
node src/moe.js monitor      # tail JSONL metrics
cat logs/monitor.jsonl       # route/prompt_compiled/run_complete/run_failed events
cat logs/moe.log             # human log
```

## Project layout

```
moe/
├── config.json          # models, costs, latency, context, licenses, retry, scoring
├── routes.json          # routing rules table (type → primary → fallback → why)
├── DESIGN.md            # full architecture + design document
├── src/
│   ├── moe.js           # CLI
│   ├── orchestrator.js  # MoE brain: route → compile → execute → merge
│   ├── analyzer.js      # task classification / sensitivity / budget / json
│   ├── prompt_compiler.js  # JIT recompile, chunking, markers, cache
│   ├── client.js        # model adapters (OpenAI-compat / Anthropic / Ollama) + retry taxonomy
│   ├── merger.js        # scoring, retry/backoff, aggregation, selection
│   ├── config.js        # config + routes loader
│   └── logger.js        # leveled log + JSONL monitoring
├── bench/
│   └── suite.js         # offline oracle + --live benchmark
├── tests/
│   └── moe.test.js      # 10 offline unit tests
└── examples/            # runnable examples + this README
```

## Examples

See `examples/README.md` and the runnable scripts under `examples/`.

## Design

See [`DESIGN.md`](./DESIGN.md) for the full architecture: routing rules, prompt compiler,
output merger, error handling, and the privacy policy (secrets never leave for hosted
APIs — they route to local Ollama first).
