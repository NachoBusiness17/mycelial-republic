'use strict';
// suite.js — benchmark: cost/quality tradeoffs across task types and model choices.
//
// Two modes:
//   offline (default): "virtual oracle" scoring derived from config quality_score + a
//      per-task-type weight + latency/cost from config. Reproducible, needs no keys, and
//      faithfully surfaces the routing tradeoff logic. Good for regression/CI.
//   --live: actually calls each model for each task; fills real latency/cost. Needs keys.

const path = require('path');
const { loadConfig } = require('../src/config');
const { analyzeTask } = require('../src/analyzer');
const { scoreOutput } = require('../src/merger');
const PromptCompiler = require('../src/prompt_compiler');
const { runModel, ModelError } = require('../src/client');

// Deterministic pseudo oracle: effective_quality = quality_score * type_weight - latency_penalty
const TYPE_WEIGHT = {
  code_generation: 1.0, code_review: 1.0, reasoning: 1.15, analysis: 1.05,
  summarization: 0.95, rag_retrieval_answer: 1.0, nlp_extraction: 1.1,
  translation: 0.9, creative_writing: 1.0, planning: 1.1, conversation: 0.9,
  general: 1.0, privacy_sensitive: 0.85
};

const SUITE = [
  { id: 'code_generation', prompt: 'write a function that parses a JSON array of objects and returns only those with active=true', rounds: 3 },
  { id: 'reasoning', prompt: 'solve: a farmer has chickens and rabbits, 35 heads and 94 legs, how many of each? show the math', rounds: 3 },
  { id: 'analysis', prompt: 'compare the pros and cons of three serverless platforms for a high-throughput data pipeline', rounds: 2 },
  { id: 'summarization', prompt: 'summarize the key risks and mitigations from the attached incident-postmortem', rounds: 2 },
  { id: 'nlp_extraction', prompt: 'extract all named entities (person, org, date) as a JSON object from this text', rounds: 2 },
  { id: 'creative_writing', prompt: 'write a two-paragraph product launch blurb for a new VPN aimed at journalists', rounds: 2 },
  { id: 'rag_retrieval_answer', prompt: 'using ONLY the chunked context, answer: what are the three retention tiers? cite chunk numbers', rounds: 2 },
  { id: 'code_review', prompt: 'review this function for security issues and off-by-one bugs in the input validation', rounds: 2 }
];

function defPath(opts) {
  return opts.benchmarks && opts.benchmarks.path || 'bench/results.json';
}

async function run({ rounds, live, configOpts } = {}) {
  const { config, routes } = loadConfig(configOpts);
  const modelNames = Object.keys(config.models);
  const outcomes = [];

  for (const t of SUITE) {
    const n = rounds || t.rounds || 1;
    const analysis = analyzeTask(t.prompt, config, routes);
    const oracle = {
      prompt: t.prompt, task_type: analysis.taskType, text:
        `synthetic ${analysis.taskType} response (${n} rounds)`, strictJson: analysis.strictJson
    };
    const perModel = [];
    for (const mn of modelNames) {
      const mc = config.models[mn];
      let samples = [];
      for (let r = 0; r < n; r++) {
        if (live) {
          // real call (best-effort; skip failures silently per model)
          try {
            const messages = new PromptCompiler(config).compile({ ...oracle, prompt: t.prompt }, mc);
            const res = await runModel(mc, messages, { timeoutMs: mc.avg_latency_sec * 4000, temperature: 0.2 });
            samples.push({ latency_ms: res.latency_ms, cost_usd: res.cost_usd });
          } catch (e) { samples.push({ error: e.message }); }
        } else {
          // offline oracle: deterministic, seeded by model+task
          const typeWeight = TYPE_WEIGHT[analysis.taskType] || 1.0;
          const latencyPenalty = Math.min(0.12, (mc.avg_latency_sec || 1) * 0.015);
          const effQ = Math.max(0.1, Math.min(1, (mc.quality_score || 5) / 10 * typeWeight - latencyPenalty));
          const maxOut = Math.min((mc.max_output_tokens || 4096), (mc.cost_per_1k_output * 1000) > 20 ? 8000 : 2000);
          const cost = ((t.prompt.length / 1000) * (mc.cost_per_1k_input || 0) +
                        (maxOut / 1000) * (mc.cost_per_1k_output || 0));
          const latency = mc.avg_latency_sec * 1000 * (0.9 + ((r * 37 + mn.length) % 5) / 20);
          samples.push({ quality: effQ, latency_ms: latency, cost_usd: cost });
        }
      }
      const good = samples.filter(s => !s.error);
      perModel.push({
        model: mn,
        rounds: n,
        ok: good.length,
        fail: samples.length - good.length,
        avg_latency_ms: good.length ? good.reduce((s, x) => s + x.latency_ms, 0) / good.length : -1,
        avg_cost_usd: good.length ? good.reduce((s, x) => s + x.cost_usd, 0) / good.length : -1,
        quality: live ? NaN : (good.length ? good.reduce((s, x) => s + x.quality, 0) / good.length : 0)
      });
    }
    // routed-choice uses whichever model the rules pick
    const routed = perModel.find(p => p.model === analysis.primary) || perModel[0];
    const best = perModel.slice().sort((a, b) => (b.quality - a.quality))[0];
    const cheapest = perModel.filter(p => p.avg_cost_usd >= 0).sort((a, b) => a.avg_cost_usd - b.avg_cost_usd)[0];
    outcomes.push({
      task: t.id, task_type: analysis.taskType, routed_model: analysis.primary, rounds: n,
      routed: routed && { cost: routed.avg_cost_usd, latency: routed.avg_latency_ms, quality: routed.quality },
      best_quality: best && { model: best.model, quality: best.quality, cost: best.avg_cost_usd },
      cheapest: cheapest && { model: cheapest.model, cost: cheapest.avg_cost_usd, quality: cheapest.quality },
      per_model: perModel, generated_at: new Date().toISOString(), mode: live ? 'live' : 'offline'
    });
  }
  return { suite: SUITE.map(s => s.id), model_names: modelNames, results: outcomes, mode: live ? 'live' : 'offline', generated_at: new Date().toISOString() };
}

function fmtTable(benchmark) {
  let s = '\n';
  s += `${'task'.padEnd(20)} ${'routed'.padEnd(16)} routed$    bestQ(m)      cheap$→Q\n`;
  s += '─'.repeat(70) + '\n';
  for (const o of benchmark.results) {
    const route = o.routed ? `${o.routed.quality != null ? (o.routed.quality * 100).toFixed(0) + '%' : 'na'} @$${o.routed.cost != null ? o.routed.cost.toFixed(4) : '?'}` : 'none';
    const bq = o.best_quality ? `${o.best_quality.model}(${(o.best_quality.quality * 100).toFixed(0)}%)` : 'na';
    const ch = o.cheapest ? `${o.cheapest.model}($${o.cheapest.cost.toFixed(4)}→${o.cheapest.quality != null ? (o.cheapest.quality * 100).toFixed(0) + '%' : 'na'})` : 'none';
    s += `${o.task.padEnd(20)} ${o.routed_model.padEnd(16)} ${route.padEnd(10)} ${bq.padEnd(18)} ${ch}\n`;
  }
  return s;
}

module.exports = { run, defPath, SUITE, fmtTable };
