#!/usr/bin/env node
'use strict';
// 01-basic-run.js — default routing: summarization → glm-5.3-flash
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE({ config: require('path').join(__dirname, '..', 'config.json'), routes: require('path').join(__dirname, '..', 'routes.json') });
  const out = await moe.runTask({
    text: 'summarize test-driven development in one short paragraph',
    prompt: 'summarize test-driven development in one short paragraph'
  });
  if (out.ok) {
    // eslint-disable-next-line no-console
    console.log(out.text);
    // eslint-disable-next-line no-console
    console.log(`\n→ [${out.model}] cost=$${out.total_cost_usd ? out.total_cost_usd.toFixed(5) : '?'} ${(out.ms / 1000).toFixed(2)}s`);
  } else {
    // eslint-disable-next-line no-console
    console.error('Failed:', out.errors.map(e => e.message).join('; '));
  }
})();
