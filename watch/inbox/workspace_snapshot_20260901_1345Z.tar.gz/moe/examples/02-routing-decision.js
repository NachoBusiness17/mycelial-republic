#!/usr/bin/env node
'use strict';
// 02-routing-decision.js — show the routing decision withOUT calling any model.
const path = require('path');
const { loadConfig } = require('../src/config');
const { analyzeTask } = require('../src/analyzer');

const { config, routes } = loadConfig({
  config: path.join(__dirname, '..', 'config.json'),
  routes: path.join(__dirname, '..', 'routes.json')
});

const cases = [
  'write a python function to parse JSON and retry on failure',
  'analyze pros and cons of serverless platforms',
  'redact the credentials in this private file, local only',
  'prove that sqrt(2) is irrational'
];

for (const prompt of cases) {
  const a = analyzeTask(prompt, config, routes);
  // eslint-disable-next-line no-console
  console.log(
    `· ${prompt.slice(0, 48).padEnd(50)} ` +
    `${a.taskType.padEnd(18)} → ${a.primary.padEnd(16)} ` +
    `ensemble=${a.ensemble} sensitive=${a.sensitivity}`
  );
}
