#!/usr/bin/env node
'use strict';
// 03-json-extraction.js — strict JSON output (needs ZAI_API_KEY for glm).
const path = require('path');
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE({ config: path.join(__dirname, '..', 'config.json'), routes: path.join(__dirname, '..', 'routes.json') });
  const out = await moe.runTask({
    text: 'extract people/orgs as JSON {"people":[],"orgs":[]}: Sundar works at Google, met Sam in Palo Alto',
    prompt: 'extract people/orgs as JSON {"people":[],"orgs":[]}: Sundar works at Google, met Sam in Palo Alto'
  }, { model: 'glm-5.3-flash' });
  if (!out.ok) { console.error('Failed:', out.errors.map(e => e.message).join('; ')); return; }
  try { console.log(JSON.stringify(JSON.parse(out.text), null, 2)); }
  catch (_) { console.log('Not strict JSON:\n' + out.text); }
})();
