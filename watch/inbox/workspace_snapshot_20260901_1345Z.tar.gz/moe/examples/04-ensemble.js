#!/usr/bin/env node
'use strict';
// 04-ensemble.js — force ensemble voting (needs keys for the models in the analysis rule).
const path = require('path');
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE({ config: path.join(__dirname, '..', 'config.json'), routes: path.join(__dirname, '..', 'routes.json') });
  const out = await moe.runTask({
    text: 'compare postgres vs sqlite for an offline analytics app, give pros and cons',
    prompt: 'compare postgres vs sqlite for an offline analytics app, give pros and cons'
  }, { ensemble: true });
  if (!out.ok) { console.error('Ensemble failed:', out.errors.map(e => e.message).join('; ')); return; }
  // eslint-disable-next-line no-console
  console.log(`winner=${out.model} score=${out.score ? out.score.toFixed(3) : '?'} attempts=${out.attempts}`);
  if (out.ranked) (out.ranked || []).forEach(r => console.log(`  ${r.model} @ ${r.score ? r.score.toFixed(3) : '?'} cost=$${r.cost_usd ? r.cost_usd.toFixed(5) : '?'}`));
  // eslint-disable-next-line no-console
  console.log('\n' + out.text);
})();
