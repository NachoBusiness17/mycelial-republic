#!/usr/bin/env node
'use strict';
// 05-privacy-local.js — privacy-sensitive tasks route to local Ollama (never hosted).
const path = require('path');
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE({ config: path.join(__dirname, '..', 'config.json'), routes: path.join(__dirname, '..', 'routes.json') });
  const out = await moe.runTask({
    text: 'redact the credentials in this file and return only the safe version. password=abc123 secret=f00',
    prompt: 'redact the credentials in this file and return only the safe version. password=abc123 secret=f00'
  });
  if (out.ok) {
    // eslint-disable-next-line no-console
    console.log(`✓ routed to LOCAL model: ${out.model} (provider should be ollama)`);
    // eslint-disable-next-line no-console
    console.log(out.text);
  } else {
    // eslint-disable-next-line no-console
    console.error('Private path needs local Ollama running + qwen2.5-coder:7b pulled. Errors:', out.errors.map(e => e.message).join('; '));
  }
})();
