#!/usr/bin/env node
'use strict';
// 06-fallback-chain.js — show serial fallback + retry behavior.
const path = require('path');
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE({ config: path.join(__dirname, '..', 'config.json'), routes: path.join(__dirname, '..', 'routes.json') });
  // reasoning → claude-opus (no key ⇒ skipped) → grok → glm
  const out = await moe.runTask({
    text: 'prove that the square root of 2 is irrational, briefly',
    prompt: 'prove that the square root of 2 is irrational, briefly'
  });
  // eslint-disable-next-line no-console
  console.log(`model_plan = [${(out.model_plan || []).join(', ')}]`);
  // eslint-disable-next-line no-console
  console.log(out.ok
    ? `answered by ${out.model} (attempts=${out.attempts})`
    : `ALL models failed: ${out.errors.map(e => '[' + e.model + '] ' + e.message).join('; ')}`);
})();
