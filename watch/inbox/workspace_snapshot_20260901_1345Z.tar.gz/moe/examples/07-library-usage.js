#!/usr/bin/env node
'use strict';
// 07-library-usage.js — use MoE as a library (same as the CLI, minus arg parsing).
const path = require('path');
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE({
    config: path.join(__dirname, '..', 'config.json'),
    routes: path.join(__dirname, '..', 'routes.json'),
    log: { level: 'warn' }          // keep it quiet
  });
  const res = await moe.runTask({
    text: 'tell me a one-liner about REST APIs',
    prompt: 'tell me a one-liner about REST APIs',
    taskType: 'conversation'
  });
  // eslint-disable-next-line no-console
  console.log(res.ok ? res.text : ('failed: ' + res.errors.map(e => e.message).join('; ')));
})();
