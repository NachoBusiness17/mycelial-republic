# MoE Usage Examples

Each example is a small Node script you can run directly. They require only the API key
for the model they use (see README setup); Ollama-based examples need `ollama serve`.

Run from the `moe/` directory:

```bash
node examples/01-basic-run.js
node examples/02-routing-decision.js
node examples/03-json-extraction.js
node examples/04-ensemble.js            # needs 2+ keys for the analysis rule
node examples/05-privacy-local.js       # needs local Ollama for the private path
node examples/06-fallback-chain.js      # demonstrates graceful fallback + retry
node examples/07-library-usage.js       # use MoE as a library, not the CLI
```

---

### 01 — Basic run (default routing)

```js
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE();
  // summarize → glm-5.3-flash
  const out = await moe.runTask({ text: 'summarize test-driven development in one short paragraph', prompt: 'summarize test-driven development in one short paragraph' });
  console.log(out.text, `\n→ ${out.model} cost=$${out.total_cost_usd?.toFixed(5)}`);
})();
```

### 02 — Routing decision without calling any model

```js
const { analyzeTask } = require('../src/analyzer');
const { loadConfig } = require('../src/config');
const { config, routes } = loadConfig();
const a = analyzeTask('write a python function to parse JSON and retry on failure', config, routes);
console.log(a.taskType, '→', a.primary, '/', a.fallbacks.join(','), 'ensemble=' + a.ensemble);
// code_generation → deepseek-v4-flash / qwen2.5-coder-7b,gpt-oss-120b,claude-opus-4.8 ensemble=false
```

### 03 — Strict JSON extraction

```js
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE();
  const out = await moe.runTask({ text: 'extract people/orgs as JSON {"people":[],"orgs":[]}: Sundar works at Google, met Sam in Palo Alto', prompt: 'extract people/orgs as JSON {"people":[],"orgs":[]}: Sundar works at Google, met Sam in Palo Alto' }, { model: 'glm-5.3-flash' });
  console.log(JSON.parse(out.text)); // { people: ['Sundar','Sam'], orgs: ['Google'] }
})();
```

### 04 — Ensemble voting (independent second opinion)

```js
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE();
  // compare/pros-cons analysis → grok + fallbacks in parallel, pick best score
  const out = await moe.runTask({ text: 'compare postgres vs sqlite for an offline analytics app, give pros and cons', prompt: 'compare postgres vs sqlite for an offline analytics app, give pros and cons' }, { ensemble: true });
  console.log(`winner=${out.model} score=${out.score?.toFixed(3)} attempts=${out.attempts}`);
  console.log(out.ranked?.map(r => `${r.model}@${r.score?.toFixed(2)}`).join(' | '));
})();
```

### 05 — Privacy-first routing (local model)

```js
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE();
  // any prompt with "secret/credential/password/local only" NEVER leaves for hosted APIs.
  const out = await moe.runTask({ text: 'redact the credentials in this local-only file: password=abc123', prompt: 'redact the credentials in this local-only file: password=abc123' });
  console.log(out.ok ? `routed to: ${out.model} (local)` : 'private path unavailable (Ollama off)');
})();
```

### 06 — Fallback chain + retry

```js
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE({ config: '../config.json' }); // not needed if cwd=moe
  // reasoning → claude-opus (if no key, skipped) → grok → glm
  const out = await moe.runTask({ text: 'prove sqrt(2) is irrational', prompt: 'prove sqrt(2) is irrational' });
  console.log(out.ok ? `answered by ${out.model} after ${out.attempts} attempt(s)` : `all failed: ${out.errors.map(e=>e.message).join('; ')}`);
})();
```

### 07 — Library usage

```js
const MoE = require('../src/orchestrator');
(async () => {
  const moe = new MoE();
  const task = { text: 'joke about terminals', prompt: 'joke about terminals', taskType: 'conversation' };
  const res = await moe.runTask(task);
  console.log(res.text);
})();
```
