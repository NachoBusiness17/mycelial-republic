'use strict';
// analyzer.js — heuristics over the task description to infer:
//   - task type (match against routing rules keywords)
//   - sensitivity (privacy/local-only)
//   - budget hint (low/medium/high)
//   - whether JSON output is demanded
//   - whether ensemble voting would help (ambiguity signals)

const SENSITIVE_WORDS = ['secret', 'private', 'password', 'token', 'credential', 'confidential', 'do not leak', 'local only', 'ssh key', 'api key', 'pii'];
const JSON_HINTS = ['json', 'yaml', 'return as ', 'structured output', 'schema', 'list of objects', 'fields for'];
const VAGUE_HINTS = ['maybe', 'either', 'not sure', 'opinion', 'which is best', 'compare', 'alternatives', 'pros and cons', 'what would you', 'uncertain', 'guess'];

// Verb/noun cues that strongly imply a code task even when generic NLP keywords (json/parse)
// are also present. Weighted above generic keyword matches.
const CODE_CUES = ['write a function', 'write a code', 'implement', 'def ', 'function that', 'generate code', 'a script', 'the code', 'refactor', 'debug', 'a function', 'python function', 'node function'];
const CODE_CUE_WEIGHT = 2.5;
const PRIVACY_CUE_WEIGHT = 3.0;

function normalize(s) {
  return ' ' + String(s || '').toLowerCase() + ' ';
}

function detectTaskType(prompt, rules) {
  const p = normalize(prompt);
  let best = null;
  let bestScore = 0;
  for (const rule of rules.rules) {
    const kws = rule.keywords || [];
    let score = 0;
    for (const kw of kws) if (p.includes(kw)) score += 1;
    if (rule.task_type === 'code_generation') {
      for (const cue of CODE_CUES) if (p.includes(cue)) score += CODE_CUE_WEIGHT;
    }
    if (rule.task_type === 'privacy_sensitive') {
      for (const kw of kws) if (p.includes(kw)) score += PRIVACY_CUE_WEIGHT;
    }
    if (score > bestScore) {
      bestScore = score;
      best = rule;
    }
  }
  if (!best) {
    best = { task_type: 'general', ...rules.default, primary: rules.default.primary, fallbacks: rules.default.fallbacks.slice(0), ensemble: rules.default.ensemble, why: rules.default.why };
  }
  return { rule: best, score: bestScore, matched: bestScore > 0 };
}

function detectSensitivity(prompt) {
  const p = normalize(prompt);
  return SENSITIVE_WORDS.some(w => p.includes(w));
}

function detectBudget(rules, prompt) {
  // explicit override via /fast /cheap /quality tags, else rule budget.
  const p = normalize(prompt);
  if (/\/high|\/quality|\/opus\b/.test(p)) return 'high';
  if (/\/low|\/cheap|\/fast\b/.test(p)) return 'low';
  return rules.budget || 'default';
}

function wantsJson(prompt) {
  return JSON_HINTS.some(h => normalize(prompt).includes(h));
}

function ambiguityScore(prompt) {
  const p = normalize(prompt);
  return VAGUE_HINTS.filter(h => p.includes(h)).length;
}

function wantEnsemble(rules, rule, prompt, budget) {
  if (rule.ensemble) {
    // high-budget ensemble is wasteful unless ambiguity present
    if (budget === 'high' && ambiguityScore(prompt) <= 1) return false;
    return true;
  }
  // fallback heuristic: ambiguous questions benefit from a second independent opinion
  return ambiguityScore(prompt) >= 3 && budget !== 'low';
}

// Build a fully-resolved routing decision from raw task text.
function analyzeTask(rawTask, config, routes) {
  const prompt = typeof rawTask === 'string' ? rawTask : (rawTask && rawTask.text || '');
  const { rule, score, matched } = detectTaskType(prompt, routes);
  const sensitivity = detectSensitivity(prompt);
  const budget = detectBudget(routes, prompt);
  const strictJson = wantsJson(prompt);
  const ambiguity = ambiguityScore(prompt);
  const ensemble = !sensitivity && wantEnsemble(routes, rule, prompt, budget);

  // Sensitivity overrides routing to local/low-retention models.
  let primary = rule.primary;
  let fallbacks = rule.fallbacks || [];
  let useRule = rule;
  if (sensitivity) {
    const priv = routes.rules.find(r => r.task_type === 'privacy_sensitive');
    if (priv) {
      primary = priv.primary;
      fallbacks = priv.fallbacks || [];
      useRule = priv;
    }
  }

  return {
    prompt,
    taskType: rule.task_type,
    sensitivity,
    budget,
    strictJson,
    ambiguity,
    ensemble,
    primary,
    fallbacks,
    rule: useRule,
    matched
  };
}

module.exports = { analyzeTask, detectTaskType, detectSensitivity, detectBudget, wantEnsemble, wantsJson, ambiguityScore };
