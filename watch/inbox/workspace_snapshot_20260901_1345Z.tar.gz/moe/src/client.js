'use strict';
// client.js — model adapters. Normalizes chat completion calls across providers.
// Supports: OpenAI-compatible (/v1/chat/completions), Anthropic (/v1/messages), Ollama (/api/chat).
// Custom Error classes below map provider failures to a normalized taxonomy for retry logic.

const logger = require('./logger');

class ModelError extends Error {
  constructor(message, meta = {}) {
    super(message);
    this.name = 'ModelError';
    this.taxonomy = meta.taxonomy || 'unknown'; // rate_limit|timeout|server_error|connection_error|empty|bad_gateway|auth
    this.status = meta.status ?? null;
    this.model = meta.model || null;
    this.cause = meta.cause;
  }
}

const ANTHROPIC_HEADERS = ['x-api-key', 'anthropic-version'];

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function _fetchJSON(url, opts, timeoutMs) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(url, Object.assign({}, opts, { signal: ctl.signal }));
    let body = null;
    const text = await res.text();
    try { body = text ? JSON.parse(text) : null; } catch (_) { body = text; }
    clearTimeout(timer);
    return { res, body, text };
  } catch (e) {
    clearTimeout(timer);
    if (e && e.name === 'AbortError') throw new ModelError('Request timeout', { taxonomy: 'timeout' });
    throw new ModelError('Connection failure: ' + (e && e.message), { taxonomy: 'connection_error', cause: e });
  }
}

// ---------- OpenAI-compatible ----------
async function chatOpenAICompatible(modelCfg, messages, opts) {
  const { env_key, base_url, model_id } = modelCfg;
  const apiKey = env_key ? process.env[env_key] : null;
  if (env_key && !apiKey) throw new ModelError(`Missing env var ${env_key}`, { taxonomy: 'auth', model: model_id });

  const url = `${base_url.replace(/\/$/, '')}/chat/completions`;
  const headers = { 'Content-Type': 'application/json' };
  if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;

  const payload = {
    model: model_id,
    messages,
    temperature: opts.temperature ?? 0.4,
    max_tokens: opts.max_tokens || opts.maxOutputTokens || modelCfg.max_output_tokens
  };
  if (opts.stream) payload.stream = true;

  const { res, body } = await _fetchJSON(url, { method: 'POST', headers, body: JSON.stringify(payload) }, opts.timeoutMs || 60000);
  if (res.status >= 400) throw classifyError(res.status, body, model_id);
  const choice = body && body.choices && body.choices[0];
  const content = choice && typeof choice.message === 'object' ? choice.message.content : null;
  if (!content) throw new ModelError('Empty completion', { taxonomy: 'empty', status: res.status, model: model_id });
  return { text: content, finish_reason: choice && choice.finish_reason, model: model_id, usage: body.usage, status: res.status };
}

// ---------- Anthropic ----------
async function chatAnthropic(modelCfg, messages, opts) {
  const apiKey = process.env[modelCfg.env_key];
  if (!apiKey) throw new ModelError(`Missing env var ${modelCfg.env_key}`, { taxonomy: 'auth', model: modelCfg.model_id });
  const url = `${modelCfg.base_url.replace(/\/$/, '')}/messages`;
  const headers = {
    'Content-Type': 'application/json',
    'x-api-key': apiKey,
    'anthropic-version': opts.anthropicVersion || '2023-06-01'
  };
  // Split OpenClaw-style messages into system + user/assistant turns.
  const system = messages.filter(m => m.role === 'system').map(m => m.content).join('\n\n');
  const convo = messages.filter(m => m.role !== 'system');
  const payload = {
    model: modelCfg.model_id,
    max_tokens: opts.max_tokens || opts.maxOutputTokens || modelCfg.max_output_tokens,
    messages: convo.length ? convo : [{ role: 'user', content: 'Please respond.' }]
  };
  if (opts.temperature != null) payload.temperature = opts.temperature;
  if (system) payload.system = system;

  const { res, body } = await _fetchJSON(url, { method: 'POST', headers, body: JSON.stringify(payload) }, opts.timeoutMs || 90000);
  if (res.status >= 400) throw classifyError(res.status, body, modelCfg.model_id);
  const text = (body.content || []).map(b => b.type === 'text' ? b.text : '').join('');
  if (!text) throw new ModelError('Empty completion', { taxonomy: 'empty', status: res.status, model: modelCfg.model_id });
  return { text, finish_reason: body.stop_reason, model: modelCfg.model_id, usage: body.usage, status: res.status };
}

// ---------- Ollama ----------
async function chatOllama(modelCfg, messages, opts) {
  const url = `${modelCfg.base_url.replace(/\/$/, '')}/api/chat`;
  const payload = {
    model: modelCfg.model_id,
    messages,
    stream: false,
    options: { temperature: opts.temperature ?? 0.4 }
  };
  const { res, body } = await _fetchJSON(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }, opts.timeoutMs || 120000);
  if (res.status >= 400) throw classifyError(res.status, body, modelCfg.model_id);
  const text = body && body.message && body.message.content;
  if (!text) throw new ModelError('Empty completion', { taxonomy: 'empty', status: res.status, model: modelCfg.model_id });
  return { text, finish_reason: body.done ? 'stop' : 'length', model: modelCfg.model_id, usage: body.prompt_eval_count != null ? { prompt_tokens: body.prompt_eval_count, completion_tokens: body.eval_count } : undefined, status: res.status };
}

function classifyError(status, body, model) {
  const codes = { 401: 'auth', 403: 'auth', 429: 'rate_limit', 500: 'server_error', 502: 'bad_gateway', 503: 'server_error', 504: 'timeout' };
  const taxonomy = codes[status] || 'server_error';
  const detail = body && (body.error && body.error.message || body.message) || `HTTP ${status}`;
  return new ModelError(`[${model}] ${detail}`, { taxonomy, status, model });
}

// Route a normalized messages array to the right adapter by provider.
async function runModel(modelCfg, messages, opts = {}) {
  const provider = (modelCfg.provider || '').toLowerCase();
  const t0 = Date.now();
  try {
    let result;
    if (provider === 'anthropic') result = await chatAnthropic(modelCfg, messages, opts);
    else if (provider === 'ollama') result = await chatOllama(modelCfg, messages, opts);
    else result = await chatOpenAICompatible(modelCfg, messages, opts);
    result.latency_ms = Date.now() - t0;
    result.cost_usd = estimateCost(modelCfg, result.usage);
    return result;
  } catch (e) {
    if (!(e instanceof ModelError)) {
      logger.warn('Unexpected model error', modelCfg.model_id, e.message);
      e = new ModelError(e.message, { taxonomy: 'server_error', model: modelCfg.model_id });
    }
    e.latency_ms = Date.now() - t0;
    throw e;
  }
}

function estimateCost(modelCfg, usage) {
  if (!usage) return 0;
  const pin = usage.prompt_tokens || 0;
  const pout = usage.completion_tokens || 0;
  return (pin * (modelCfg.cost_per_1k_input || 0) + pout * (modelCfg.cost_per_1k_output || 0)) / 1000;
}

module.exports = { runModel, ModelError, classifyError, estimateCost, sleep };
