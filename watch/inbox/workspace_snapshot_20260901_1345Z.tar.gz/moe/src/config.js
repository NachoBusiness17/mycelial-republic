'use strict';
// config.js — load + validate configuration and routing rules.

const fs = require('fs');
const path = require('path');

const DEFAULT_CONFIG = path.join(__dirname, '..', 'config.json');
const DEFAULT_ROUTES = path.join(__dirname, '..', 'routes.json');

class ConfigError extends Error {}

function loadJson(file, label) {
  try {
    const raw = fs.readFileSync(file, 'utf8');
    return JSON.parse(raw);
  } catch (e) {
    throw new ConfigError(`Failed to load ${label} (${file}): ${e.message}`);
  }
}

function loadConfig(opts = {}) {
  const configPath = opts.config || opts.configPath || DEFAULT_CONFIG;
  const routesPath = opts.routes || opts.routesPath || DEFAULT_ROUTES;
  const config = loadJson(configPath, 'config');
  const routes = loadJson(routesPath, 'routes');
  validate(config, 'config');
  validate(routes, 'routes');
  return { config, routes };
}

function validate(obj, label) {
  if (!obj || typeof obj !== 'object') throw new ConfigError(`${label} must be an object`);
}

module.exports = { loadConfig, loadJson, ConfigError, DEFAULT_CONFIG, DEFAULT_ROUTES };
