'use strict';
// logger.js — leveled logger to console + file, plus a JSONL monitoring stream for metrics.

const fs = require('fs');
const path = require('path');

const LEVELS = { silent: 0, error: 1, warn: 2, info: 3, debug: 4 };
let currentLevel = 'info';
let logStream = null;
let monitorStream = null;
let colored = true;

function openFile(absPath) {
  if (!absPath) return null;
  const dir = path.dirname(absPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return fs.createWriteStream(absPath, { flags: 'a' });
}

function init(opts = {}) {
  currentLevel = opts.level || 'info';
  colored = opts.colored !== false;
  if (opts.file) logStream = openFile(opts.file);
  if (opts.monitoring_file) monitorStream = openFile(opts.monitoring_file);
}

function ts() {
  return new Date().toISOString();
}

function writeLine(level, ...args) {
  const msg = args.map(a => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ');
  const line = `[${ts()}] [${level.toUpperCase()}] ${msg}`;
  if (LEVELS[level] <= LEVELS[currentLevel]) {
    const color = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[36m', debug: '\x1b[90m' }[level] || '';
    const reset = colored ? '\x1b[0m' : '';
    // logs -> stderr so stdout stays clean for machine-readable output (--json)
    // eslint-disable-next-line no-console
    console.error(colored ? `${color}${line}${reset}` : line);
  }
  if (logStream) logStream.write(line + '\n');
}

const logger = {
  init,
  level(n) { currentLevel = n; },
  error: (...a) => writeLine('error', ...a),
  warn: (...a) => writeLine('warn', ...a),
  info: (...a) => writeLine('info', ...a),
  debug: (...a) => writeLine('debug', ...a),
  // monitor: append a structured metric event to JSONL (for dashboards / trend analysis)
  monitor(event) {
    const rec = Object.assign({ t: ts() }, event);
    if (monitorStream) monitorStream.write(JSON.stringify(rec) + '\n');
    return rec;
  }
};

module.exports = logger;
