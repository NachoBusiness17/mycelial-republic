'use strict';
// merger.js — output aggregation, retry orchestration, response scoring, and selection.

const logger = require('./logger');
const { ModelError, sleep } = require('./client');

// ---------- scoring ----------
// Score a single model output on several axes. Heuristic (no second LLM needed).
function scoreOutput(text, analysis) {
  const t = String(text || '');
  let infoDensity = 0;
  let promptAdherence = 0;
  let selfConsistency = 0;
  let concision = 0;

  // information density: verbs/entities/markup weigh vs filler
  const significant = (t.match(/[A-Za-z0-9#*`\-]|[\u4e00-\u9fff]/g) || []).length;
  const total = t.length || 1;
  infoDensity = Math.min(1, significant / total);

  // JSON adherence
  if (analysis.strictJson) {
    let parsed = false;
    try { JSON.parse(t); parsed = true; } catch (_) {}
    promptAdherence = parsed ? 1 : 0;
  } else {
    // marker contamination penalty (prompt compiler boundary markers leaking into output)
    const leaks = (t.match(/CHUNK \d+\/\d+/g) || []).length + (t.match(/%%%SEP%%%/g) || []).length;
    promptAdherence = Math.max(0, 1 - leaks * 0.35);
  }

  // self-consistency: low token repetition entropy proxy — penalize verbatim repeats
  const sentences = t.split(/[.!?]\s+/).filter(s => s.trim().length > 8);
  const unique = new Set(sentences.map(s => s.slice(0, 40))).size;
  selfConsistency = sentences.length ? unique / sentences.length : 0.5;

  // concision: shorter-and-dense is better, but don't reward empty
  if (total > 40) {
    concision = Math.max(0, 1 - (total - 200) / 3000);
  } else {
    concision = 0;
  }

  // weighted
  const w = analysis.scoreWeights || { prompt_adherence: .35, information_density: .25, self_consistency: .25, concision: .15 };
  const score = promptAdherence * w.prompt_adherence +
                infoDensity * w.information_density +
                selfConsistency * w.self_consistency +
                concision * w.concision;
  return { score, infoDensity, promptAdherence, selfConsistency, concision, length: total };
}

// ---------- retry ----------
// Execute a single model call with exponential backoff + jitter on retryable errors.
async function runWithRetry(fn, opts, log) {
  const r = opts.retry || { max_attempts: 3, backoff_base_sec: 1.5, backoff_max_sec: 12, retry_on: ['rate_limit', 'timeout', 'server_error', 'connection_error'] };
  let attempt = 0;
  for (;;) {
    attempt++;
    try {
      const res = await fn();
      logger.debug('Attempt OK', attempt);
      return { result: res, attempts: attempt };
    } catch (e) {
      const tax = e instanceof ModelError ? e.taxonomy : 'server_error';
      const retryable = r.retry_on.includes(tax);
      if (!retryable || attempt >= r.max_attempts) {
        return { error: e, attempts: attempt };
      }
      const backoff = Math.min(r.backoff_max_sec, r.backoff_base_sec * Math.pow(2, attempt - 1)) * (0.8 + Math.random() * 0.4);
      logger.warn(`Retry ${attempt}/${r.max_attempts} after ${tax.toUpperCase()} on ${
        (e && e.model) || ''} (backoff ${backoff.toFixed(1)}s)`);
      await sleep(backoff * 1000);
    }
  }
}

// ---------- aggregation / selection ----------
function bestOutput(results, analysis) {
  const sorted = results.slice().sort((a, b) => (b.score - a.score) || (a.cost_usd - b.cost_usd));
  const winner = sorted[0];
  logger.monitor({ ev: 'selected', model: winner.model, score: winner.score, cost_usd: winner.cost_usd });
  return { winner, ranked: sorted };
}

// Aggregate independent results into one cohesive answer.
// For free-form tasks: pick best and optionally fuse top-2 summaries if ensemble.
function aggregateResults(results, analysis, config) {
  if (!results.length) throw new Error('No results to aggregate');
  const best = bestOutput(results, analysis);
  const winner = best.winner;

  // If ensemble ran and outputs differ meaningfully, merge a compact rationale header
  // but keep the winning body intact (avoid garbage fusion).
  let mergedText = winner.text;
  if (results.length > 1) {
    const uniqueCharters = new Set(results.filter(r => r.text && r.text.length > 20).map(r => r.model)).size;
    if (uniqueCharters === 1) mergedText = winner.text;
  }

  return {
    text: mergedText,
    model: winner.model,
    score: winner.score,
    attempts: results.reduce((n, r) => n + (r.attempts || 0), 0),
    total_cost_usd: results.reduce((s, r) => s + (r.cost_usd || 0), 0),
    total_latency_ms: results.reduce((s, r) => s + (r.latency_ms || 0), 0),
    ranked: best.ranked.map(r => ({ model: r.model, score: r.score, cost_usd: r.cost_usd, latency_ms: r.latency_ms }))
  };
}

module.exports = { runWithRetry, scoreOutput, aggregateResults, bestOutput };
