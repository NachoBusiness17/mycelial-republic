#!/usr/bin/env node
'use strict';
// moe.js — CLI for the OpenClaw Personal MoE router.
//
// Usage:
//   node src/moe.js run "write a function to parse JSON" [--model X] [--json]
//   node src/moe.js run --file prompt.txt
//   node src/moe.js route "analyze this dataset"          (show routing decision, don't call)
//   node src/moe.js models                                  (list configured + availability)
//   node src/moe.js bench [--rounds 3] [--out bench/results.json]
//   node src/moe.js rules [TASK_TYPE]                       (inspect routing table)
//   node src/moe.js monitor                                 (tail JSONL monitoring events)
//   Piping: echo "summarize the fed text" | node src/moe.js run

const fs = require('fs');
const path = require('path');
const { loadConfig } = require('./config');
const logger = require('./logger');
const { analyzeTask } = require('./analyzer');
const PromptCompiler = require('./prompt_compiler');
const MoE = require('./orchestrator');

function die(msg) {
  // eslint-disable-next-line no-console
  console.error('moe: ' + msg);
  process.exit(1);
}

function readStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch (_) { return ''; }
}

async function cmdRun(argv, opts) {
  const { config, routes } = loadConfig(opts);
  const moe = new MoE(opts);
  let raw;
  const i = argv.indexOf('--file');
  if (i !== -1) raw = fs.readFileSync(argv[i + 1], 'utf8');
  else {
    // strip our own flags (and their values) from the positional task text
    const positional = argv.filter((tok, idx) => {
      if (['--json', '--ensemble'].includes(tok)) return false;
      if (tok === '--model') return false;
      if (idx > 0 && argv[idx - 1] === '--model') return false;
      return true;
    }).join(' ').trim();
    // prefer CLI text; only read from pipe if no positional task was given
    raw = positional.length ? positional : (opts._stdin ? readStdin() : '');
  }
  if (!raw || !raw.trim()) die('empty task. usage: moe run "task..." | moe run --file prompt.txt | echo ... | moe run');

  const asJson = argv.includes('--json');
  const modelOverride = (() => { const k = argv.indexOf('--model'); return k !== -1 ? argv[k + 1] : null; })();
  const ensemble = (() => { const k = argv.indexOf('--ensemble'); if (k === -1) return null; return argv[k + 1] !== '0' && argv[k + 1] !== 'false'; })();
  const out = await moe.runTask({ text: raw, prompt: raw }, { model: modelOverride, ensemble });
  if (asJson) {
    // eslint-disable-next-line no-console
    console.log(JSON.stringify(out, null, 2));
  } else if (out.ok) {
    // eslint-disable-next-line no-console
    console.log('\n' + out.text + '\n');
    // eslint-disable-next-line no-console
    console.log(`╭─ [${out.model}] score=${out.score.toFixed(3)} cost=$${out.total_cost_usd.toFixed(5)} (${
      (out.total_cost_usd * 1000).toFixed(2)} mills) ${(out.ms / 1000).toFixed(2)}s type=${out.task_type}`);
  } else {
    die('routing failed for all models: ' + out.errors.map(e => e.message).join('; '));
  }
}

function cmdRoute(argv, opts) {
  const { config, routes } = loadConfig(opts);
  const raw = argv.join(' ').replace(/^--\w+\s*/g, '').trim();
  if (!raw) die('route needs a task description');
  const a = analyzeTask(raw, config, routes);
  // eslint-disable-next-line no-console
  console.log(JSON.stringify({
    task: a.prompt,
    task_type: a.taskType,
    matched: a.matched,
    sensitivity: a.sensitivity,
    budget: a.budget,
    strict_json: a.strictJson,
    ambiguity: a.ambiguity,
    ensemble: a.ensemble,
    execution_plan: [a.primary, ...a.fallbacks],
    why: a.rule.why || null
  }, null, 2));
}

function cmdModels(opts) {
  const { config } = loadConfig(opts);
  const moe = new MoE(opts);
  const width = Math.max(...Object.keys(config.models).map(k => k.length));
  // eslint-disable-next-line no-console
  console.log('configured models:');
  // eslint-disable-next-line no-console
  console.log('  ' + 'model'.padEnd(width + 2) + 'provider    Q  lat   ctx       $/1k-in  $/1k-out  avail');
  for (const name of Object.keys(config.models)) {
    const m = config.models[name];
    const avail = moe.isAvailable(name) ? 'yes' : 'NO-KEY';
    // eslint-disable-next-line no-console
    console.log(`  ${'`' + name.padEnd(width + 1)} ${String(m.provider).padEnd(10)} ${String(m.quality_score).padEnd(3)} ${String(m.avg_latency_sec).padStart(4)} ${String(m.context_window).padEnd(8)} ${String(m.cost_per_1k_input).padEnd(8)} ${String(m.cost_per_1k_output).padEnd(9)} ${avail}`);
  }
}

function cmdRules(argv, opts) {
  const { routes } = loadConfig(opts);
  const filter = argv.find(a => !a.startsWith('--'));
  const list = filter ? routes.rules.filter(r => r.task_type === filter) : routes.rules;
  for (const r of list) {
    // eslint-disable-next-line no-console
    console.log(`[${r.task_type}] primary=${r.primary} fallbacks=[${r.fallbacks.join(',')}] ensemble=${r.ensemble}`);
    // eslint-disable-next-line no-console
    console.log(`    why: ${r.why}`);
  }
  if (!filter) {
    // eslint-disable-next-line no-console
    console.log(`\ndefault: primary=${routes.default.primary} fallbacks=[${routes.default.fallbacks.join(',')}]`);
  }
}

async function cmdMonitor() {
  const file = path.join(__dirname, '..', 'logs', 'monitor.jsonl');
  if (!fs.existsSync(file)) { die('no monitor file yet: ' + file); }
  const lines = fs.readFileSync(file, 'utf8').trim().split('\n').filter(Boolean).slice(-50);
  // eslint-disable-next-line no-console
  console.log('last ' + lines.length + ' monitor events:');
  for (const l of lines) { try { // eslint-disable-next-line no-console
    console.log(JSON.stringify(JSON.parse(l))); } catch (_) { /* skip */ } }
}

async function cmdBench(argv, opts) {
  const rounds = (() => { const k = argv.indexOf('--rounds'); return k !== -1 ? parseInt(argv[k + 1], 10) : opts.rounds || 3; })();
  const outPath = (() => { const k = argv.indexOf('--out'); return k !== -1 ? argv[k + 1] : null; })();

  // Benchmark uses a deterministic "virtual model oracle" so it runs with no API keys.
  // Cost/quality tradeoffs are modeled from config scores. Pass --live to hit real APIs.
  const live = argv.includes('--live');
  const suite = require('../bench/suite');
  const results = await suite.run({ rounds, live, configOpts: opts });
  const target = outPath || suite.defPath(opts);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, JSON.stringify(results, null, 2));
  // eslint-disable-next-line no-console
  console.log('\nBenchmark written to ' + target);
  // eslint-disable-next-line no-console
  console.log(suite.fmtTable(results));
}

async function main() {
  const args = process.argv.slice(2);
  const cmd = args[0];
  const rest = args.slice(1);
  const opts = { _stdin: !!process.stdin && !process.stdin.isTTY };

  try {
    switch (cmd) {
      case 'run':      return cmdRun(rest, opts);
      case 'route':    return cmdRoute(rest, opts);
      case 'models':   return cmdModels(opts);
      case 'rules':    return cmdRules(rest, opts);
      case 'monitor':  return cmdMonitor();
      case 'bench':    return cmdBench(rest, opts);
      case undefined:
      case 'help':
      case '--help':
      case '-h':
        // eslint-disable-next-line no-console
        console.log(`
Usage: node src/moe.js <cmd> [args]

Commands:
  run "task..." [--model X] [--ensemble 0|1] [--json] [--file path]
        Analyze, route, compile, execute, post-process.
  route "task..."            Print the routing decision without calling a model.
  models                     List configured models + availability + cost.
  rules [TASK_TYPE]          Inspect the routing rules table.
  bench [--rounds N] [--out f.json] [--live]
        Cost/quality tradeoff benchmark. Without --live it uses the offline model
        oracle (no API keys needed). With --live it calls real endpoints.
  monitor                    Tail the JSONL monitoring stream.
`);
        break;
      default:
        die('unknown command: ' + cmd + ' (try "moe help")');
    }
  } catch (e) {
    logger.error(e.message || String(e));
    if (process.env.MOE_DEBUG) // eslint-disable-next-line no-console
      console.error(e.stack);
    process.exit(1);
  }
}

function hasShutdownStdin() {
  try { return fs.fstatSync(0).size === 0; } catch (_) { return false; }
}

if (require.main === module) main();
module.exports = { main };
