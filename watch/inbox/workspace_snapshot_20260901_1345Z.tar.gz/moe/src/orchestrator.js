'use strict';
// orchestrator.js — the MoE brain. Routes a task through analysis → prompt compile →
// primary execution (with retry) → fallback chain → optional parallel ensemble → scoring/merge.

const { analyzeTask } = require('./analyzer');
const PromptCompiler = require('./prompt_compiler');
const { runModel, ModelError } = require('./client');
const { runWithRetry, scoreOutput, aggregateResults } = require('./merger');
const logger = require('./logger');
const { loadConfig } = require('./config');

class MoE {
  constructor(opts = {}) {
    const { config, routes } = loadConfig(opts);
    this.config = config;
    this.routes = routes;
    this.compiler = new PromptCompiler(config);
    this.router = config.routing || {};
    logger.init(Object.assign({}, config.log, opts));
  }

  isAvailable(name) {
    const mc = this.config.models[name];
    if (!mc) return false;
    // Ollama / local always "available"; hosted needs an API key unless keyless
    if (mc.provider === 'ollama') return true;
    if (!mc.env_key) return true;
    return Boolean(process.env[mc.env_key]);
  }

  async runTask(rawTask, overrides = {}) {
    const t0 = Date.now();
    const analysis = analyzeTask(rawTask, this.config, this.routes);
    // overrides can pin models or force ensembles
    if (overrides.model) analysis.primary = overrides.model;
    if (overrides.ensemble != null) analysis.ensemble = overrides.ensemble;
    if (overrides.primary) analysis.primary = overrides.primary;

    logger.info(`Routing: type=${analysis.taskType} primary=${analysis.primary} budget=${analysis.budget} ensemble=${analysis.ensemble} sensitive=${analysis.sensitivity}`);
    logger.monitor({ ev: 'route', task_type: analysis.taskType, primary: analysis.primary, ensemble: analysis.ensemble, budget: analysis.budget, sensitivity: analysis.sensitivity });

    const results = [];
    const errors = [];
    const plan = this._buildExecutionPlan(analysis);

    // Execute: primary then fallbacks serially; if ensemble, fire primary+fallback pool in parallel and keep all.
    if (analysis.ensemble && plan.length > 1) {
      const pool = plan.slice(0, Math.min(this.router.max_ensemble_models || 3, plan.length))
        .filter(m => this.isAvailable(m));
      const settled = await Promise.all(pool.map(m => this._execOne(m, analysis).catch(e => ({ error: e, model: m }))));
      for (const s of settled) {
        if (s.error) { errors.push(s.error); logger.warn(`Ensemble member failed`, s.model, s.error.message); }
        else this._ingestResult(results, s.resultModel, s.res, analysis, s.resultCfg);
      }
    } else {
      for (const m of plan) {
        if (!this.isAvailable(m)) { logger.warn(`Skipping unavailable model`, m); continue; }
        const out = await this._execOne(m, analysis).catch(e => ({ error: e, model: m }));
        if (out.error) {
          errors.push(out.error);
          logger.warn(`Model ${m} failed: ${out.error.message}`);
          continue; // fallback chain
        }
        this._ingestResult(results, m, out.res, analysis, out.resultCfg);
        break; // stop at first success for non-ensemble
      }
    }

    if (!results.length) {
      // Ensemble produced nothing (all timeouts/failures). Fall back to serial primary-only before admitting defeat.
      if (analysis.ensemble && analysis.primary && this.isAvailable(analysis.primary)) {
        logger.warn('Ensemble empty; retrying serial primary-only', analysis.primary);
        const s = await this._execOne(analysis.primary, analysis).catch(e => ({ error: e }));
        if (!s.error) { this._ingestResult(results, analysis.primary, s.res, analysis); }
      }
    }

    if (!results.length) {
      const summary = errors.map(e => `[${e.model || '?'}] ${e.taxonomy}: ${e.message}`).join(' | ');
      logger.error('All models failed:', summary);
      logger.monitor({ ev: 'run_failed', ms: Date.now() - t0, errors: errors.length });
      return { ok: false, task_type: analysis.taskType, errors, model_plan: plan, ms: Date.now() - t0 };
    }

    const merged = aggregateResults(results, analysis, this.config);
    const out = {
      ok: true,
      text: merged.text,
      model: merged.model,
      score: merged.score,
      task_type: analysis.taskType,
      budget: analysis.budget,
      ensemble: analysis.ensemble,
      total_cost_usd: merged.total_cost_usd,
      total_latency_ms: merged.total_latency_ms,
      attempts: merged.attempts,
      ranked: merged.ranked,
      model_plan: plan,
      ms: Date.now() - t0
    };
    logger.info(`Done in ${(out.ms / 1000).toFixed(2)}s, ${(out.total_cost_usd * 1000).toFixed(2)} mills, winner=${out.model}`);
    logger.monitor({ ev: 'run_complete', task_type: analysis.taskType, ok: true, model: out.model, ms: out.ms, cost_usd: out.total_cost_usd, attempts: merged.attempts, score: out.score });
    return out;
  }

  // serial fallback plan: [primary, f1, f2]
  _buildExecutionPlan(analysis) {
    const plan = [];
    if (analysis.primary) plan.push(analysis.primary);
    for (const f of analysis.fallbacks || []) if (f !== analysis.primary && !plan.includes(f)) plan.push(f);
    return plan.slice(0, 1 + (this.router.fallback_max_depth || 2));
  }

  async _execOne(modelName, analysis) {
    const mc = this.config.models[modelName];
    if (!mc) throw new ModelError(`Unknown model ${modelName}`, { model: modelName });
    const messages = this.compiler.compile(analysis, mc);
    const maxOut = analysis.strictJson ? Math.min(mc.max_output_tokens, 4096) : mc.max_output_tokens;
    const fn = () => runModel(mc, messages, {
      temperature: analysis.ensemble ? 0.6 : this.config.output && this.config.output.temperature || 0.4,
      max_tokens: maxOut,
      timeoutMs: Math.max(30000, mc.avg_latency_sec * 1000 * 4)
    });
    const { result, error, attempts } = await runWithRetry(fn, this.config.output || {}, logger);
    if (error) throw error;
    return { res: result, resultModel: modelName, resultCfg: mc };
  }

  _ingestResult(results, model, res, analysis) {
    const scored = scoreOutput(res.text, analysis);
    results.push({
      model,
      text: res.text,
      score: scored.score,
      cost_usd: res.cost_usd || 0,
      latency_ms: res.latency_ms || 0,
      attempts: 1,
      finish_reason: res.finish_reason,
      details: scored
    });
  }
}

module.exports = MoE;
