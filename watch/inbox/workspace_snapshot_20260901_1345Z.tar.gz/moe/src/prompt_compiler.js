'use strict';
// prompt_compiler.js — JIT recompilation, chunking with boundary markers, rolling cache.
//
// Compiles a Task + Model into a concrete prompt:
//   system (precedent + task framing + output contract) + user message.
// For oversized context it chunks source material and inserts boundary markers so the
// model can reason across contiguous segments (RAG-style long contexts).
//
// JIT recompile: cache compiled prompts keyed by (task fingerprint + model) and invalidate
// on a TTL or when the underlying task/config changes.

const crypto = require('crypto');
const logger = require('./logger');

class PromptCompiler {
  constructor(config) {
    const p = config.prompt || {};
    this.jit = p.jit_recompile !== false;
    this.cacheTtlSec = p.recompile_cache_ttl_sec || 300;
    this.chunkSize = p.chunk_size_chars || 14000;
    this.chunkOverlap = p.chunk_overlap_chars || 400;
    this.maxUtil = p.max_context_util || 0.85;
    this.markers = p.boundary_markers || ['--- CHUNK N/N ---'];
    this.systemPrecedent = p.system_precedent || '';
    this.cache = new Map(); // key -> { at, compiled }
  }

  fingerprint(task, modelNum) {
    const h = crypto.createHash('sha256');
    h.update(JSON.stringify({ task, model: modelNum }));
    return h.digest('hex');
  }

  // Clear stale cache entries (rolling window) — call periodically.
  evict(now = Date.now()) {
    for (const [k, v] of this.cache) {
      if (now - v.at > this.cacheTtlSec * 1000) this.cache.delete(k);
    }
  }

  // Main entry: build the message array for a model.
  compile(task, modelCfg) {
    const modelId = modelCfg.model_id;
    const key = this.fingerprint(task, modelId);
    if (this.jit) {
      this.evict();
      const hit = this.cache.get(key);
      if (hit) {
        logger.debug('prompt cache hit', modelId);
        return hit.compiled;
      }
    }

    const messages = this._build(task, modelCfg);
    if (this.jit) this.cache.set(key, { at: Date.now(), compiled: messages });
    logger.monitor({ ev: 'prompt_compiled', model: modelId, chars: messages[messages.length - 1].content.length, cached: false });
    return messages;
  }

  _build(task, modelCfg) {
    const source = task.sourceText || task.prompt || '';
    const system = this._systemPrompt(task, modelCfg);
    const available = Math.floor((modelCfg.context_window || 32768) * this.maxUtil) - modelCfg.max_output_tokens;
    let user;

    if (!source || source.length * 1.5 < available) {
      // short: single user message
      user = task.prompt || '';
    } else {
      // long: chunk the source and bracket it with boundary markers
      const chunks = this._chunk(source, available);
      user = this._assembleChunks(chunks, task.prompt || '');
    }

    return [
      { role: 'system', content: system },
      { role: 'user', content: user }
    ];
  }

  _systemPrompt(task, modelCfg) {
    const parts = [];
    if (this.systemPrecedent) parts.push(this.systemPrecedent);
    if (task.outputFormat) parts.push(`Output format: ${task.outputFormat}.`);
    if (task.strictJson) {
      parts.push('Return ONLY valid JSON. No prose outside the JSON object. Do not wrap in markdown fences.');
    }
    if (task.outputContract) parts.push(`Contract: ${task.outputContract}`);
    if (task.maxLength) parts.push(`Keep the response under approximately ${task.maxLength} characters.`);
    parts.push(`[routed via personal-moe | model=${modelCfg.model_id} | type=${task.taskType || 'general'}]`);
    return parts.join('\n');
  }

  // Greedy character chunking with overlap and boundary markers.
  _chunk(text, budget) {
    const chunkSize = Math.min(this.chunkSize, Math.max(2000, budget - 800));
    const overlap = Math.min(this.chunkOverlap, Math.floor(chunkSize * 0.25));
    const chunks = [];
    let start = 0;
    while (start < text.length) {
      const end = Math.min(start + chunkSize, text.length);
      let slice = text.slice(start, end);
      // avoid splitting mid-word where possible
      if (end < text.length) {
        const nl = slice.lastIndexOf('\n');
        if (nl > Math.floor(chunkSize * 0.6)) slice = slice.slice(0, nl);
      }
      chunks.push(slice);
      start += (slice.length - overlap);
      if (slice.length <= overlap) break; // safety
    }
    return chunks;
  }

  _assembleChunks(chunks, instruction) {
    const lines = [];
    const marker0 = this.markers[0] || '--- CHUNK N/N ---';
    chunks.forEach((_, i) => {
      let marker = marker0;
      // replace only the N placeholders: "CHUNK N" -> index, "/N" -> total
      marker = marker.replace(/CHUNK N/, 'CHUNK {I}').replace('{I}', String(i + 1));
      marker = marker.replace(/\/ N\b/, '/' + String(chunks.length));
      lines.push(marker);
      lines.push(chunks[i]);
    });
    // put final instruction AFTER the source so the model "answers" not "extends"
    lines.push('');
    lines.push('INSTRUCTION:');
    lines.push(instruction);
    return lines.join('\n\n');
  }
}

module.exports = PromptCompiler;
