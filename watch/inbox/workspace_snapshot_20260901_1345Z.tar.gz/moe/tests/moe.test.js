'use strict';
// test/moe.test.js — unit tests for the MoE system (no network; offline oracle).
// Run: node --test tests/

const test = require('node:test');
const assert = require('node:assert');
const path = require('path');

const { loadConfig } = require('../src/config');
const { analyzeTask } = require('../src/analyzer');
const PromptCompiler = require('../src/prompt_compiler');
const { scoreOutput } = require('../src/merger');
const { estimateCost } = require('../src/client');

const BASE = { __dirname };
let cfg, routes;
try {
  const l = loadConfig({ config: path.join(__dirname, '..', 'config.json'), routes: path.join(__dirname, '..', 'routes.json') });
  cfg = l.config;
  routes = l.routes;
} catch (e) { cfg = null; routes = null; }

const skip = !cfg;

test('config loads with 7 models', { skip }, () => {
  assert.ok(cfg.models);
  assert.equal(Object.keys(cfg.models).length, 7);
  assert.ok(cfg.models['glm-5.3-flash']);
  assert.ok(cfg.models['qwen2.5-coder-7b']);
});

test('code task routes to deepseek', { skip }, () => {
  const a = analyzeTask('write a function isPalindrome(s) that returns true', cfg, routes);
  assert.equal(a.taskType, 'code_generation');
  assert.equal(a.primary, 'deepseek-v4-flash');
});

test('sensitive task routes local + disables ensemble', { skip }, () => {
  const a = analyzeTask('review this confidential ssh key file, credentials, do not leak', cfg, routes);
  assert.equal(a.sensitivity, true);
  assert.equal(a.primary, 'qwen2.5-coder-7b');
  assert.equal(a.ensemble, false);
});

test('reasoning task routes to claude opus', { skip }, () => {
  const a = analyzeTask('prove that sqrt(2) is irrational and explain the argument step by step', cfg, routes);
  assert.equal(a.taskType, 'reasoning');
  assert.equal(a.primary, 'claude-opus-4.8');
});

test('strict json flag detected', { skip }, () => {
  const a = analyzeTask('return as JSON a list of objects for each employee', cfg, routes);
  assert.equal(a.strictJson, true);
});

test('prompt compiler short path single user message', { skip }, () => {
  const c = new PromptCompiler(cfg);
  const a = analyzeTask('say hi', cfg, routes);
  const msgs = c.compile(a, cfg.models['glm-5.3-flash']);
  assert.equal(msgs.length, 2);
  assert.equal(msgs[0].role, 'system');
  assert.equal(msgs[1].role, 'user');
});

test('prompt compiler chunks long input with boundary markers', { skip }, () => {
  const c = new PromptCompiler({ prompt: { jit_recompile: true, recompile_cache_ttl_sec: 300, chunk_size_chars: 200, chunk_overlap_chars: 40, boundary_markers: ['--- CHUNK N/N ---'], system_precedent: 'x' } });
  const chunks = c._chunk('sentence. '.repeat(60), 2000);
  assert.ok(chunks.length >= 2, 'produces multiple chunks');
  const user = c._assembleChunks(chunks, 'answer the question');
  assert.ok(user.includes('CHUNK 1/'), 'has chunk 1 marker');
  assert.ok(user.includes('CHUNK 2/'), 'has chunk 2 marker');
  assert.ok(user.includes('INSTRUCTION:'), 'has instruction header');
});

test('prompt cache hit on recompile', { skip }, () => {
  const c = new PromptCompiler(cfg);
  const a = analyzeTask('summarize quickly', cfg, routes);
  const first = c.compile(a, cfg.models['glm-5.3-flash']);
  const second = c.compile(a, cfg.models['glm-5.3-flash']);
  assert.strictEqual(first, second, 'same object from cache');
});

test('scoreOutput penalizes chunk-marker leakage', { skip }, () => {
  const a = { strictJson: false };
  const clean = scoreOutput('def foo():\n  return 1\n\nThis function returns one, a concise and dense response.', a);
  const leaky = scoreOutput('--- CHUNK 1/2 --- def foo():\n return 1', a);
  assert.ok(clean.promptAdherence > leaky.promptAdherence, 'leak lowers adherence');
});

test('estimateCost computes from usage', { skip }, () => {
  const mc = cfg.models['glm-5.3-flash'];
  const c = estimateCost(mc, { prompt_tokens: 1000, completion_tokens: 500 });
  assert.ok(Math.abs(c - (1 * 0.0012 + 0.5 * 0.0040)) < 1e-9);
});
