// night_battery.mjs — Night Shift S1: run frozen 20-probe battery on a lane, emit per-lane receipt.
// Usage: node night_battery.mjs <lane> <KEYENV> <baseURL> <model>
// Writes /board/lineage_genC_<lane>_20260901.md. Never prints keys. Honest content tracking.
import { appendFileSync, readFileSync, existsSync, writeFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';

const lane = process.argv[2];
const keyName = process.argv[3];
const BASE = process.argv[4];
const model = process.argv[5];
if (!lane || !keyName || !BASE || !model) {
  console.error('usage: night_battery.mjs <lane> <KEYENV> <baseURL> <model>');
  process.exit(1);
}

function loadKey(name) {
  if (process.env[name]) return process.env[name];
  if (name.includes('-')) {
    try {
      const j = JSON.parse(readFileSync('/root/.openclaw/openclaw.json', 'utf8'));
      const p = j.models && j.models.providers ? j.models.providers[name] : null;
      if (p && p.apiKey) return p.apiKey;
    } catch {}
  }
  if (!existsSync('/mag/.env')) return null;
  const line = readFileSync('/mag/.env', 'utf8').split(/\r?\n/).find(l => l.startsWith(name + '='));
  return line ? line.slice(name.length + 1).replace(/^"|"$/g, '').trim() : null;
}
const key = loadKey(keyName);
if (!key) { console.error('NO_KEY ' + keyName); process.exit(1); }

const batt = JSON.parse(readFileSync('/board/lineage_battery_v1.json', 'utf8'));
const probes = batt.probes;

async function runProbe(p) {
  const body = {
    model,
    messages: [{ role: 'user', content: p.q }],
    max_tokens: 500,
    temperature: 0
  };
  const t0 = performance.now();
  try {
    const res = await fetch(BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
      body: JSON.stringify(body)
    });
    const ms = Math.round(performance.now() - t0);
    if (res.status !== 200) {
      let err = 'HTTP ' + res.status;
      try { const j = await res.json(); err = (j && j.error && (j.error.message || j.error.code)) ? String(j.error.message || j.error.code).slice(0, 160) : err; } catch {}
      return { id: p.id, w: p.w, ok: false, ms, err };
    }
    let text = '';
    try { const j = await res.json(); text = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || ''; }
    catch {}
    return { id: p.id, w: p.w, ok: true, ms, text: String(text).trim() };
  } catch (e) {
    return { id: p.id, w: p.w, ok: false, ms: Math.round(performance.now() - t0), err: String(e && e.message || e).slice(0, 160) };
  }
}

// sequential to be gentle on rate limits; 20 probes
const results = [];
for (const p of probes) {
  results.push(await runProbe(p));
  await new Promise(r => setTimeout(r, 300));
}

const ok = results.filter(r => r.ok);
const empty = ok.filter(r => !r.text);
const withText = ok.filter(r => r.text);
const fails = results.filter(r => !r.ok);
const ms = results.filter(r => r.ok).map(r => r.ms);

let out = `# lineage_genC_${lane} — ${new Date().toISOString()}\n\n`;
out += `model: ${model}\nbase: ${BASE}\n`;
out += `probes: ${results.length} | http-ok: ${ok.length} | text-nonempty: ${withText.length} | empty-content: ${empty.length} | failed: ${fails.length}\n`;
out += `latency-ms (ok): min=${ms.length ? Math.min(...ms) : '-'} med=${ms.length ? ms.sort((a,b)=>a-b)[Math.floor(ms.length/2)] : '-'}\n\n`;
for (const r of results) {
  out += `## ${r.id}  [${r.w}]\n\n`;
  if (!r.ok) out += `(FAILED: ${r.err})\n\n`;
  else if (!r.text) out += `(no content)\n\n`;
  else out += r.text + '\n\n';
}
out += `---\n`;
writeFileSync(`/board/lineage_genC_${lane}_20260901.md`, out);
console.log(`[${lane}] probes=${results.length} ok=${ok.length} text=${withText.length} empty=${empty.length} fail=${fails.length}`);
