// night_cache.mjs — cache-mining probe, night shift S2 (adapted from /board/zai_probe2.mjs)
// Usage: node night_cache.mjs <KEY_ENV_NAME> <baseURL> <model> [parallel] [waves] [label]
// Appends one JSON line per wave to /board/night_cache_receipts.jsonl. Never prints keys.
import { performance } from 'node:perf_hooks';
import { appendFileSync, readFileSync, existsSync } from 'node:fs';

const keyName = process.argv[2];
const BASE = process.argv[3];
const model = process.argv[4];
const PAR = parseInt(process.argv[5] || '10', 10);
const WAVES = parseInt(process.argv[6] || '3', 10);
const label = process.argv[7] || 'night';
// Safe key load: parse /mag/.env in node (never shell-source; never echo values).
function loadKey(name) {
  if (process.env[name]) return process.env[name];
  if (name.includes('-')) {
    try {
      const j = JSON.parse(readFileSync('/root/.openclaw/openclaw.json', 'utf8'));
      const p = j.models && j.models.providers ? j.models.providers[name] : null;
      if (p && p.apiKey) return p.apiKey;
    } catch {}
  }
  if (!existsSync('/mag/.env')) return null;
  const line = readFileSync('/mag/.env', 'utf8').split(/\r?\n/).find(l => l.startsWith(name + '='));
  return line ? line.slice(name.length + 1).replace(/^"|"$/g, '').trim() : null;
}
const key = loadKey(keyName);
if (!key || !BASE || !model) { console.error('usage: night_cache.mjs KEYENV BASE MODEL [par] [waves] [label]'); process.exit(1); }

function FROZEN_PREFIX() {
  const reps = parseInt(process.env.NIGHT_PREFIX_REPS || '380', 10);
  return 'NIGHT_SHIFT_CACHE_PROBE_20260901_V1. ' +
    ('cache-me-now-2026 repetition builds the context cache. '.repeat(reps)) +
    'END_OF_FROZEN_PREFIX.';
}

async function one() {
  const body = {
    model,
    messages: [
      { role: 'system', content: 'You are a terse cache probe. One short sentence.' },
      { role: 'user', content: FROZEN_PREFIX() + ' Reply with exactly the word READY.' }
    ],
    max_tokens: 16,
    temperature: 0
  };
  const t0 = performance.now();
  try {
    const res = await fetch(BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
      body: JSON.stringify(body)
    });
    const ms = Math.round(performance.now() - t0);
    let j = null;
    try { j = await res.json(); } catch {}
    const u = j && j.usage ? j.usage : {};
    const row = {
      ts: new Date().toISOString(), label, model, http: res.status, ms,
      promptTok: u.prompt_tokens ?? null, outTok: u.completion_tokens ?? null,
      cachedTok: (u.prompt_tokens_details && u.prompt_tokens_details.cached_tokens) ?? u.prompt_cache_hit_tokens ?? null,
      missTok: (u.prompt_tokens_details && u.prompt_tokens_details.cached_tokens == null && u.prompt_cache_miss_tokens != null) ? u.prompt_cache_miss_tokens : null,
      errCode: j && j.error && j.error.code ? String(j.error.code).slice(0, 60) : null
    };
    return row;
  } catch (e) {
    return { ts: new Date().toISOString(), label, model, http: 0, ms: Math.round(performance.now() - t0), err: String(e && e.message || e).slice(0, 120) };
  }
}

for (let w = 0; w < WAVES; w++) {
  const results = await Promise.all(Array.from({ length: PAR }, () => one()));
  const okRows = results.filter(r => r.http === 200);
  const cached = okRows.filter(r => r.cachedTok != null).map(r => r.cachedTok);
  const ms = okRows.map(r => r.ms);
  const summary = {
    ts: new Date().toISOString(), label, model, wave: w + 1, par: PAR,
    ok: okRows.length, fail: results.length - okRows.length,
    latMed: ms.length ? ms.sort((a, b) => a - b)[Math.floor(ms.length / 2)] : null,
    cache: cached.length ? { hits: cached.length, min: Math.min(...cached), max: Math.max(...cached) } : null,
    errSample: results.filter(r => r.http !== 200).slice(0, 2).map(r => r.errCode || r.err)
  };
  appendFileSync('/board/night_cache_receipts.jsonl', JSON.stringify(summary) + '\n');
  console.log(JSON.stringify(summary));
  if (w < WAVES - 1) await new Promise(r => setTimeout(r, 2000));
}
