# KNOT_STRATEGY.md — Verkle Lance Self-Check & Knot Placement Strategy

> Author: Sancho (subagent). Source: `verkle_lance self_check` re-run against
> `/mag/memory/biography/verkle_chain.jsonl` + `verkle_tip.json` (chain v1, schema
> `verkle_lance.v1`). Because the Linux cage has no `python` and `/mag` is read-only,
> the exact `self_check()` logic was replicated in Node against the same JSONL/TIP
> files — byte-identical data, same computation. Knot strategy below is **analysis /
> proposal**, not a mutation of `/mag` (edits still go through `/patches` → host jail).

---

## 0. The 7k knot state — hard numbers

| Metric | Value | Reading |
|---|---|---|
| **n_knots (chain rows)** | **6,661** | Target was ~7,000 («7k»). We are at **95%**. One more serious knot-wave closes the round. |
| chain index span | 0 → 6,660 | Contiguous, `order_monotonic: true` |
| **genesis_ts** | `2026-08-10T21:14:05Z` | Chain started 10 Aug |
| **tip_ts** | `2026-08-27T23:17:34Z` | Chain last advanced 27 Aug |
| chain lifetime | ~17 days | ~390 knots/day average |
| **orphans** | **4** | rows with no `session_id` (tiny, but each breaks the session-trace chain) |
| **untagged** | **4,925** (74%) | rows with no `dominant_theme` — the single biggest integrity gap |
| all_content_addressed | ✅ true | every row has `leaf_hash` + `verkle_root` — hashes/roots intact |
| tip_root | `77f4dcfc…71b711` | current merkle root |
| tip_last_session | `mag-agent-cli` | last writing seat |
| knot files on disk | **18,203** in `knots/` | vs 6,661 in the **active chain** → **~11.5k knot leaves are not chained** (stale/orphaned on disk, or outside the canonical chain). |

**The blunt truth:** the chain is *content-healthy* (all addressed, monotonic,
root-valid) but *semantically dirty* — **TWO THIRDS of knots carry no theme**, and
one **~11,500-knot orphanage** sits on disk outside the live chain. The 7k state is
less a "need more knots" problem and more a "the existing 6,661 are half-labeled
and there's a warehouse of unindexed leaves behind the wall."

### Theme distribution (dominant_theme, chain rows)

| Theme | Count | Kind |
|---|---|---|
| **untagged** | **4,925** | ⚠️ unclassified |
| biography | 842 | session digest leaves |
| autonomous_janitor | 382 | janitor/workflow |
| mag_hands | 317 | hands-on sessions |
| constitution | 97 | law/principles |
| mirror_meta | 35 | self/reflection |
| scrum_plan | 13 | planning |
| data_r0 | 9 | r0 data runs |
| harness | 7 | harness ops |
| wow_manifest | 5 | manifest |
| dashboard | 3 | dashboard |
| `usage-digest`, `mem_invariant_map`, `holographic_q`, `agent_os_cycle`, `rib_*` (each `rib_*` ×1), `fact_*` (each ×1) | 1 each | rib / fact-bus one-offs |

Note the long tail: **37 distinct themes**, of which 28 appear **exactly once** —
these are mostly `rib_*` and `fact_*` single-shot probe knots. They are real knots
but too granular to be true "anchor points." The concentration is in
biography + janitor + hands + constitution (~1,638 tagged); everything else is dust
compared to the ~5k untagged.

### Session distribution (by_session_prefix, chain rows)

| Prefix family | Knots | Note |
|---|---|---|
| `memlang-*` | **3,985** | the bulk — memory-language lane (incl. the legacy `--x-tab-*` transcript knots) |
| `mag-*` (incl. `mag-agent-*`, `mag_*`) | ~1,990 | mag seats / agent / orc / dashboard |
| `autonomous-*` | 382 | janitor/autonomous |
| `agent-*` (standing) | 73 | standing agents |
| `castle-*` | 56 | foundation/castle |
| `rib_os-*` | 46 | rib_os lane |
| `wow_manifest_*` | 5 | manifest |
| `problem-*`/`solution-*` | 5/3 | problem/solution knots |
| `steal_pack-*` | 16 | steal pack |
| `probe:stateless`, `invariant:test`, `invariant:drift`, `proof-*`, `usage_digest` | 1 each | probes |
| `work:seat:*`, `work:mem_lands:*`, `work:audit:*`, `work:module:*` | dozens @ 1 | work-module seats |
| raw uuid prefixes (`01a…`) | ~50 @ 1 | ephemeral seats |
| `019f4d15`… (legacy date-stamped) | handful | earliest knots |

- **6,658 unique session_ids across 6,661 rows** → sessions are ~1:1 with knots.
  Almost every knot is its own session. This is the structural tell: **the chain is
  being fed *per-session leaves* (a knot per conversation/seat-tick), not *per-event
  operationalized knots*.** That is why untagged runs so high — a session-id alone
  is not a thematic anchor.

---

## 1. WHEN to knot — event triggers

A knot should be **written (a chain row appended, leaf committed) only on a
*closed, falsifiable event*** — not on every seat heartbeat. From the chain's own
shape (per-session leaves dominant, 74% untagged) the current default is
"knot every session"; that default produces low-information knots. Replace it with
closure-based triggers:

| Trigger event | Knot when | Evidence already present? |
|---|---|---|
| **Round completion** | A kneading/salon round (single or multi) reaches a declared stop → one synthesis knot. **Not** per-turn, per-round. | `scrum_plan`/`salon` lanes exist; weak in chain. ⭐ primary gap |
| **Fork resolution** | A seat/salon fork is reconciled (merged, closed, or deliberately orphaned) → a knot naming both sides + the decision vertex. | `party_subchain` exists; not folded into knot chain. ⭐ gap |
| **Source verification** | A fact/claim passes or fails primary-source gopher cross-check → an evidential knot (witness, ref, status). | `fact_*` ribs exist but ×1 each; needs the **verify-before-flag** loop to write. ⭐ gap |
| **Prediction measurement** | A prediction hits its measurement window and resolves (hit/miss/unknown) → the measured-outcome knot with the prediction id. | `problem-*`/`solution-*` trace exists; no resolution layer. ⭐ gap |
| **Principle operationalization** | A principle/law in `CONSTITUTION`/`operator-corrections` is turned into a testable claim or a rib scene — the moment abstraction → mechanism. | `constitution` theme (97) holds principles; none operationalized as knots. ⭐ gap |
| **Chain-v2 repair/gap** | v1 row healed (committed repair) or irrecoverably gapped → the registry→knot handoff (per `anchor_registry` spec). | `anchor_registry.jsonl` defines the ledger; the knot write is the missing compile step. |

**Corollary — when NOT to knot:** on seat tick, on message, on a new session_id, on
a probe run with no verdict. A knot with no `dominant_theme`, no closure, and no
falsifiable payload is noise that pushes n toward 7k without adding connectivity.

**Implicit rule of thumb:** knot n should rise by **content-closures**, not by
**session-count**. Target the *resolved, verified, operationalized, measured* set —
then 7k of *good* knots beats 20k of session echoes.

---

## 2. WHERE to knot — thematic anchor points

The task proposes F-xx / S-xx / P-Sxx anchors; **those mnemonics do not yet exist
anywhere** in the codebase (verified: zero `F-`, `S-`, `P-S` references in
`docs/ref/`). They are a *proposal target*. Map them onto the families the chain
already shows so the anchors are additive, not invented:

| Anchor mnemonic | Meaning | Backed by existing theme | Candidate label for `dominant_theme` |
|---|---|---|---|
| **F-xx** | **Fit** — the concrete prediction/claim that must hold (falsifiable forecast) | `problem-*`,`solution-*`,`data_r0`,`prediction` | `F-<knead><n>` (e.g. `F-08`) → theme `fit_prediction` |
| **S-xx** | **Sovereign** — the operating decision / law / principle the system commits to | `constitution` (97), `operator-corrections`, `harness` (7) | `S-<law><n>` (e.g. `S-03`) → theme `sovereign_law` |
| **P-Sxx** | **Pulse / Signal** — measured outcome of an F-prediction or S-principle (the readback) | `fact_*`,`usage-digest`,`holographic_q`, `biography` | `P-S<xx>` child of its F-xx parent → theme `pulse_measure` |
| **principle** | the operationalized claim (F/S degenerate to principle when written as a test | `constitution`,`rib_doctrine` | `principle:<name>` |
| **protocol** | the schema/recipe/rib that says *how* the knot is produced | `rib_*` (28 one-offs), `proto` | `protocol:<name>` |

**Suggested anchor taxonomy** (drop into `dominant_theme`; keeps `by_theme`
meaningful and cuts `untagged`):

```
Fit        F-xx    → a falsifiable claim.    theme: fit        parent: round/salon
Sovereign  S-xx    → a committed law/decision theme: sovereign   parent: constitution
Pulse      P-Sxx   → measured readback of F/S theme: pulse       parent: its F-xx or S-xx
Principle  P-…     → operationalized rule     theme: principle
Protocol   Proto-… → how-to-produce recipe    theme: protocol
```

**Anchor-point placement in the chain:** every new knot should cite exactly one
anchor dimension:
- `F-xx` knots chain under a **round** (the round is the temporal container; goal).
- `S-xx` knots chain under **constitution/principle** lineage.
- `P-Sxx` knots **child** the F-xx/S-xx they measure (parent_verkle_root linkage).
- `protocol` knots give the *recipe* (rib path) so any claim is re-derivable.

---

## 3. Current gaps — categories of missing knots

Ordered by severity:

### GAP-1 (CARDINAL): 74% of the chain is untagged
`4,925 / 6,661` rows have no `dominant_theme`. Before *adding* knots, backfill
theme-classification on the existing 4,925 (or mark them `barren`/archive). A
7k-chain with 2/3 anonymous rows has weak `lance`/`link`/`trace` semantics —
`lance --mode themes` can't pick good reference spots if the themes are blank.

> **Fix:** a sweep job that runs the `theme_basis[]` / `theme_vector_raw[]` (already
> present on each leaf — see sample knot: `mirror_meta`, `mag_hands`, `scrum_plan`,
> `constitution`, `dashboard`, `harness`, `biography`, `data_r0`) to derive a
> `dominant_theme` deterministically $0, writes label via `/patches` + host
> `openclaw_patches apply`. That single step recovers ~5k anchor points for free.

### GAP-2: ~11,500 leaves on disk are outside the chain
`18,203` files in `memory/biography/knots/` vs `6,661` chain rows. Either they are
stale (chain rebuilt / superseded) or unindexed. **Whichever it is, it is
undeclared.** The chain must either absorb them (if they are real closure-events) or
explicitly quarantine them (if superseded) so the orphanage is a deliberate choice,
not a silent barn.

### GAP-3: orphans (4) — tiny but rule-breaking
4 rows lack `session_id`. For a content-addressed chain with `trace`/`link` keyed on
session, every orphan is an untraceable island. Re-parent them to a real session or
quarantine; zero orphans should be the standing bar.

### GAP-4: no operationalized-principle knots
`constitution` (97 knots) holds laws but **zero** `principle:<name>` / operationalized
knots — nothing turns "we hold X" into "here is the test that proves X." This is the
**principle operationalization** trigger with no output yet.

### GAP-5: no measured-prediction (P-Sxx) readback knots
No `pulse_measure` family. Predictions (`problem-*`/`solution-*`, 8 total) are
proposed but never close with a hit/miss measurement. The feedback half of the
scientific loop is absent.

### GAP-6: fork-resolution not folded into the chain
`party_subchain` tracks seat-to-seat forks, but nothing writes a **fork-resolution
knot** naming both sides and the decision vertex. Forks die without a tombstone.

### GAP-7: long-tail over-granularity
28 themes appear exactly once (`rib_*`, `fact_*`). These are probe knots; they should
roll up into their F/S/P family instead of adding 28 singleton themes that dilute the
histogram. **Collapse singletons to `rib`/`fact` umbrella labels** unless the probe
itself resolves to a verdict.

---

## 4. Recommended sequencing (to land the 7k right)

1. **Label first, add second.** Sweep → tag the 4,925 untagged (GAP-1) using the
   `theme_basis` already on each leaf. Turns 6,661 anonymous → ~6.6k tagged.
2. **Declare the disk orphanage** (GAP-2): either merge eligible leaves or
   quarantine; get the on-disk count to equal chain count (or document the split).
3. **Close the feedback loop** (GAP-4/5): add `principle:<name>` (operationalize a
   constitution law) and `pulse_measure` (resolve a prediction → P-Sxx child). This
   is where *new value* knots come from — not more session echoes.
4. **Tombstone forks** (GAP-6): write fork-resolution knots off `party_subchain`.
5. **Zero the orphans** (GAP-3) and collapse singletons (GAP-7).

Target arithmetic: **6,661 tagged + ~300–500 principled/measured/fork-resolved
knots ≈ 7,000** — a clean, high-information chain at the 7k mark, not a padded one.

---

## 5. Environment note (execution reality)

- `python -m mag.verkle_lance self_check` **cannot run on this Linux cage** (no
  `python`; the venv at `/mag/.venv` is the **host Windows venv** — `Scripts/*.exe`).
- The command must run on the **host Windows Mag venv**:
  `.\.venv\Scripts\python.exe -m mag.verkle_lance self_check`
- Data files are readable from the cage at `/mag/memory/biography/` (read-only), so
  this analysis reproduces `self_check` byte-equivalent via Node.
- **Any fixes to `/mag` (labels, repairs, quarantine) must go through `/patches`
  JSON → host `python -m mag.openclaw_patches apply`.** Nothing here mutates `/mag`.
