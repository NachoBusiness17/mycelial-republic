# Operator Quick Reference — Verkle Lance Phase 1

## What Was Done

Sancho completed Phase 1 of verkle lance self-check and knot placement for the physical computing research corpus. All deliverables are ready for host application via `/patches`.

---

## Key Files

| File | Purpose | Status |
|------|---------|--------|
| `VERKLE_LANCE_COMPLETION_SUMMARY.md` | Full completion report | ✅ Ready |
| `VERKLE_LANCE_SELF_CHECK.md` | Chain health analysis | ✅ Ready |
| `knot_labeling_patch.json` | Host patch for labeling 4,052 untagged knots | ✅ Ready |
| `knot_templates_fork_resolutions.json` | 3 fork-resolution knot templates (F-01, F-04, F-07) | ✅ Ready |
| `knot_templates_principles.json` | 4 principle operationalization templates | ✅ Ready |

---

## Immediate Next Steps (Host-Side)

Run these commands in order:

```bash
# 1. Apply labeling patch (labels 4,052 untagged knots)
python -m mag.openclaw_patches apply

# 2. Apply fork-resolution patches
python -m mag.openclaw_patches apply

# 3. Apply principle patches
python -m mag.openclaw_patches apply

# 4. Verify labeling
node /root/.openclaw/workspace/physical-computing/knot_labeler.js
```

---

## Chain Health Snapshot

- **Knots:** 4,912 (70.2% of 7k target)
- **Untagged:** 4,052 (82.5%) ← Primary gap
- **Orphans on disk:** ~13,291 (18,203 total - 4,912 chain)
- **Content health:** ✅ All addressed, monotonic, root-valid
- **Semantic health:** ⚠️ 82.5% untagged

---

## What's Next (Phase 2)

After applying the patches:

1. **Create P-Sxx readback knots** for each fork resolution and principle
2. **Measure predictions** (P-S1..P-S4) as experiments run
3. **Address disk orphanage** (merge or quarantine ~13,291 leaves)
4. **Collapse singleton themes** (16 `rib_*`/`fact_*` themes)
5. **Reach 7k target** with high-information knots

---

## Verification

After applying patches, verify by running:

```bash
# Check chain health
node /root/.openclaw/workspace/physical-computing/verkle_lance_port.js

# Check labeling
node /root/.openclaw/workspace/physical-computing/knot_labeler.js
```

---

## Critical Notes

- All scripts run on Linux Node.js; host Windows Mag venv runs the patches
- Data files are read-only from Linux cage (`/mag/memory/biography/`)
- Any fixes to `/mag` go through `/patches` JSON → host jail
- Chain health is high (all addressed, monotonic, root-valid); semantic health is the focus

---

**Prepared by:** Sancho (DeepSeek lane)
**Date:** 2026-08-31
