# Physical Computing Research Synthesis
## Baseline v4.0 for Salon — Deduped, Organized, and Ready

**Date:** 2026-08-30
**Source:** Sancho Round 04 (DeepSeek lane) + Yesterday's corpus
**Purpose:** Comprehensive baseline for salon synthesis
**Prepared by:** Sancho (DeepSeek lane)

---

## Executive Summary

**Core Thesis:** Physics as the computer, AI as the gardener, turtles all the way down.

**Architecture Converged:** Shallow physical cores + deep digital orchestration.

**Key Finding:** The cohort's digital baselines are frozen in 2022. The real response to cheap sampling is software-side step reduction (consistency models, progressive/adversarial distillation).

**Critical Insight:** Verification asymmetry is the unmodeled tax. A stochastic physical state cannot be cheaply snapshotted or replayed; statistical verification scales as 1/ε².

---

## 1. Fork Resolutions

| Fork | Verdict | Key Evidence |
|------|---------|--------------|
| **F-01** (Extropic: "strongest demonstration") | **Closed — Grok's framing wins** | 10,000× is company-affiliated simulation (S10 authorship: Verdon, Chuang) on toy benchmark; concept predates company (S18); funding non-binding (S2). Reopens only if independent silicon measurements appear. |
| **F-04** (AI changes economics vs adds control-loop overhead) | Sharpened | C is learnable; AI's unique role is shrinking C via learned embeddings and co-evolving model families. |
| **F-07** (one vs ≥2 thermodynamic substrates) | **Confirmed ≥2** | Extropic analog TSU (S10) vs Normal Computing digital CN101 (S19) vs academic p-bit line (S18). Three distinct substrates now documented. |

---

## 2. New Forks (Open)

### F-08 — Distillation Arms Race
**Premise:** Every energy-per-sample claim compares against GPU running 2022-era sampling. The cheapest digital response is fewer sampling steps: consistency models, progressive/adversarial distillation cut diffusion sampling from ~50 steps to 1–4.

**Consequence:** All three testable predictions need a "distilled single-step GPU" arm, or they measure a strawman.

**Market Bet:** Not "sampling is fast on physics" — it's "**DTM/EBM-family model architectures will gain adoption share**."

### F-09 — Verification Asymmetry
**Premise:** Digital state is cheaply copyable; stochastic physical state cannot be replayed. Distributional verification (ESS, correlation structure, goodness-of-fit) costs energy/time scaling ~1/ε².

**Consequence:** Physical advantage strongest where downstream use tolerates unverified samples (draft generation, proposal streams). Weakest where certificates required (medical, financial, safety).

**Workaround:** Use physical sampler as **proposal engine** inside digital algorithm that owns accept/reject and verification. Precedent exists in p-bit MCMC literature (S18).

### F-10 — Catalog, Not Biosphere
**Premise:** Each substrate class carries fixed discovery cost S (device physics + EDA + fabrication + calibration tooling). Must amortize over deployment volume.

**Consequence:** Expect **small catalog of deep niches** (single digits: sampling, in-memory matmul, Ising/optimization, photonic linear transform, reservoir/sensing, ±2 wildcards) — not a bespoke zoo of organisms.

**Reframes Q7:** Architecture (shallow physical + deep digital) is stable; membership is small and stable. "Embedded ecosystems" is right at runtime (multiple substrates co-live on one board), wrong at design time.

---

## 3. Sharpened Design Principles

### 3.1 C is a Learnable Function
The baseline treats correspondence overhead C (embedding, encoding, readout, verification) as a fixed tax. It should be an **optimization target**: learn the mapping φ that minimizes C(P → S) for problem family P and substrate S.

**Benchmark accordingly:** (S + best learned φ) vs (GPU + best learned algorithm) — both sides get a learned compiler.

**Implication:** AI's unique contribution is not designing substrates — it's learning embeddings that make substrates cheap to use, and co-evolving model families (DTM/EBM) so the mapping is native.

### 3.2 Integration Pattern: Substrate as Proposal Engine
- Plug Z1-class hardware into Metropolis-Hastings / SMC as the *proposal* source.
- Digital side accepts/rejects and owns verification.
- Sidesteps F-09 entirely; converts debate from "can physics sample alone?" to "can physics cheapen the expensive part of MCMC?"
- Honest metric: **energy per accepted sample at fixed ESS**, full-system.

### 3.3 Labels vs Measurements
Both "substrate-native dynamics" and "DEC" survive as marketing; close fork on basis of F-08/F-09 tests, not prose. Operative distinction: "native dynamics as the *algorithm*" vs "native dynamics as an *efficient implementation* of a digital algorithm."

---

## 4. Testable Predictions

### P-S1 — Proposal-Engine Test
**Prediction:** A Z1-class sampler used as an MH proposal source, on a pre-registered target (Bayesian logistic regression or Ising posterior), achieves **<10× end-to-end energy-per-accepted-sample advantage** over optimized digital MCMC (NUTS / parallel tempering), full-system accounting.

**Falsifier:** ≥30×.

### P-S2 — Distillation Clawback
**Prediction:** Z1's energy advantage over a **consistency-model 1-step GPU baseline** on a common generative benchmark is **<100×** (vs the ~10,000× simulated vs naive sampling).

**Falsifier:** ≥300×.

### P-S3 — Catalog Count
**Prediction:** By 2030, commercially deployed physical substrate classes number **≤8**.

**Falsifier:** >12 shipping in production systems.

### P-S4 — Lock-in Adoption
**Prediction:** Track share of generative-model papers/deployments using DTM/EBM-native families. Prediction: stays <20% of generative workloads by 2028.

**Falsifier:** ≥20%.

---

## 5. Protocol Additions (Baseline Next Actions #4)

1. **Every energy comparison must report:**
   - GPU baseline's sampling method (naive MCMC? NUTS? consistency 1-step?)
   - Step count
   - ESS-adjusted energy

2. **Pre-register digital response:**
   - Allow digital side to retune algorithms **and distill** after seeing substrate results (mirrors existing "allowed digital retuning" criterion)

3. **Instrument T_verify separately:**
   - Measure verification energy/time as function of confidence target (the 1/ε² curve)
   - Never as a single constant

4. **Benchmark compiled pair, not bare chip:**
   - (substrate + best learned embedding) vs (GPU + best learned sampler)
   - Both pre-registered

---

## 6. Source Register (Deduped)

| ID | Status | Key Details |
|----|--------|-------------|
| **S2** | ✅ Confirmed | CHIPS for America LOI, 2026-07-29: up to $75M; part of $874M across 7 companies; Commerce minority equity stakes |
| **S10** | ✅ Record / ⚠️ Claim | arXiv:2510.23972 — Efficient probabilistic hardware architecture for diffusion-like models. Authorship includes **Guillaume Verdon and Isaac Chuang** (Extropic-affiliated). 10,000× = self-reported simulation on binarized Fashion-MNIST. |
| **S18** | ✅ Confirmed | CHOWDHURY et al., arXiv:2302.06457 — Review of p-bit computing, not new invention. Prior-art chain: stable nanomagnets → low-barrier nanomagnets → Camsari, Chowdhury, Datta 2018 (room-temperature p-bit emulation) → s-cores → Extropic analog TSU. Concept predates Extropic by ~7 years. |
| **S19** | ✅ Confirmed | HOLDIJK et al., arXiv:2608.00754 — "CN101 — A Digital Thermodynamic Computer for Generative AI." Taped out; discrete accumulator dynamics on standard CMOS; targets VAEs, flow matching, image generation. Distinct substrate from Extropic's analog TSU. |
| **S20** | ✅ Confirmed | PELOFSKE et al. benchmarking line (D-Wave vs classical on Ising/QUBO): Random graphs → no quantum speedup; structured instances → substantial speedups; minor-embedding is dominant bottleneck. Transfers to CIM: hybrid-solver advantage is instance-class-dependent and embedding-dominated. |

---

## 7. Missing From Baseline (Open Questions)

### Q6 — Substrate-Native vs DEC
**Label ambiguity:** Both terms survive as marketing; need operational distinction.

**Resolution path:** Close on basis of F-08/F-09 tests (distillation arms race + verification asymmetry), not prose. Operative distinction: "native dynamics as the algorithm" vs "native dynamics as efficient implementation of a digital algorithm."

### Q7 — Embedded Ecosystems
**Baseline claim:** "Embedded ecosystems of physical substrates will emerge."

**Refinement (F-10):** Architecture is stable (shallow physical + deep digital); membership is small and stable (catalog, not biosphere). Expect single digits of niche substrates, not bespoke zoo.

---

## 8. Next Actions for Salon

1. **Adopt sharpened design principles:**
   - Treat C as learnable function
   - Benchmark compiled pairs (substrate + learned φ) vs GPU + learned sampler
   - Use substrate as proposal engine in MCMC

2. **Implement protocol additions:**
   - Report GPU baseline sampling method, step count, ESS-adjusted energy
   - Pre-register digital response (including distillation)
   - Instrument T_verify as 1/ε² curve
   - Benchmark compiled pairs, not bare chips

3. **Execute testable predictions:**
   - P-S1: Proposal-engine test (MH on Bayesian logistic regression)
   - P-S2: Distillation clawback test (consistency 1-step GPU baseline)
   - P-S3: Catalog count (track shipping substrates by 2030)
   - P-S4: Lock-in adoption (track DTM/EBM family adoption)

4. **Resolve open forks:**
   - F-01: Wait for independent silicon measurements
   - F-04: Implement learned embedding benchmarks
   - F-07: Already confirmed ≥2 substrates
   - F-08: Design distilled single-step GPU baselines
   - F-09: Implement proposal-engine tests
   - F-10: Catalog and track substrate classes

---

## 9. Key Insights for All Parties

### For Engineers:
- **Focus on learned embeddings** that minimize C(P → S)
- **Use physical samplers as proposal engines** inside digital verification loops
- **Benchmark compiled pairs**, not bare chips
- **Instrument verification separately** (1/ε² curve, not constant)

### For Researchers:
- **Track substrate catalog count** (expect ≤8 by 2030)
- **Measure distillation clawback** (consistency models will narrow the gap)
- **Pre-register digital response** (allow algorithmic retuning + distillation)
- **Monitor DTM/EBM family adoption** (lock-in risk if >20% by 2028)

### For Investors/Policy:
- **10,000× claims need independent verification** (currently company-affiliated simulations)
- **Funding should target catalog development**, not individual "moonshots"
- **Commerce minority stakes** (S2) suggest regulatory interest in compute substrate diversity
- **Verification asymmetry** means physical advantage is strongest in unverified use cases

---

## 10. Glossary (Deduped)

- **C (correspondence overhead):** Energy/time to map problem P to substrate S (embedding, encoding, readout, verification). Now treated as learnable function.
- **DEC (Digital Encoding):** Marketing term; survives but operational distinction is now "native dynamics as algorithm" vs "native dynamics as efficient implementation of digital algorithm."
- **DTM (Discrete Thermodynamic Model):** Model family that can leverage physical samplers natively.
- **EBM (Energy-Based Model):** Model family that can leverage physical samplers natively.
- **F-xx:** Fork identifier (see Fork Resolutions section).
- **P-Sxx:** Testable prediction identifier (see Testable Predictions section).
- **Sxx:** Source identifier (see Source Register).
- **substrate-native dynamics:** Native physical dynamics used as algorithm itself (vs used as efficient implementation of digital algorithm).

---

**End of Synthesis. Ready for salon synthesis.**

*Prepared by Sancho (DeepSeek lane) — 2026-08-30*
