# Round 04 — Sancho (DeepSeek lane)
**Date:** 2026-08-29
**Status:** Contribution for baseline v4.0 synthesis
**Scope:** Verification receipts → fork resolutions → new forks → sharpening → prediction/protocol deltas

---

## 0. Bottom line

The thesis ("physics as the computer, AI as the gardener, turtles all the way down") is directionally correct and the cohort has already converged on the right architecture: **shallow physical cores, deep digital orchestration**. This round does three things the baseline is missing:

1. **F-01 is resolvable now, with receipts.** "Strongest demonstration" was the wrong label. The 10,000× figure is a company-affiliated *system-level simulation* on a toy benchmark — not a silicon measurement. Grok's "most visible attempt" is the accurate label, pending independent measurements.
2. **The cohort's digital baselines are frozen in 2022.** The real digital response to cheap sampling is software-side *step reduction* (consistency models, progressive/adversarial distillation). Every efficiency prediction needs a distillation arm or it is measuring a strawman GPU.
3. **The unmodeled tax is verification asymmetry.** A stochastic physical state cannot be cheaply snapshotted or replayed; statistical verification scales as 1/ε². The integration pattern that sidesteps it: **physical sampler as proposal engine inside a digital algorithm that owns verification**. Testable now.

---

## 1. Verification receipts (searched 2026-08-29)

### S10 — Jelinčič et al., arXiv:2510.23972 — ⚠️ → ✅ (record verified; claim still unverified as silicon)
- Confirmed: "An efficient probabilistic hardware architecture for diffusion-like models." Submitted 2025-10-28, revised v2 2025-12-10. cs.LG / cs.AI.
- Confirmed: all-transistor CMOS probabilistic computer; **system-level analysis** suggesting ~10,000× lower energy vs GPU on a simple image benchmark (binarized Fashion-MNIST per baseline).
- **NEW, matters for F-01:** author list includes **Guillaume Verdon and Isaac Chuang**. This is Extropic-affiliated work, not independent. The 10,000× is a self-reported simulation from the company's own line.

### S2 — CHIPS for America LOI, 2026-07-29 — ✅ confirmed, add detail
- Confirmed: non-binding LOI, up to $75M, subject to diligence/approval/definitive agreements.
- Add: part of $874M in planned incentives across **seven** companies; Commerce plans **minority, non-controlling equity stakes** (per Reuters).

### S19 — Holdijk et al., arXiv:2608.00754 (CN101) — ⚠️ → ✅
- Confirmed: "CN101 — A Digital Thermodynamic Computer for Generative AI." Lead author Lars Holdijk; Normal Computing; taped out; described as discrete accumulator dynamics on standard CMOS (stochastic computing); targets VAEs, flow matching, image generation. Distinct substrate from Extropic's analog TSU — F-07 stands (≥2 thermodynamic substrates).

### S18 — Chowdhury et al., arXiv:2302.06457 — ⚠️ → ✅ (as review; prior-art chain clarified)
- Confirmed as a full-stack **review** of p-bit computing, not a new invention claim.
- Prior-art chain: stable nanomagnets → low-barrier nanomagnets → **Camsari, Chowdhury, Datta 2018, "p-Bits for Probabilistic Spin Logic"** (and the room-temperature p-bit emulation line) → s-cores → Extropic's analog CMOS TSU.
- **Implication:** the p-bit concept predates Extropic by ~7 years. Extropic's contribution is *scale of CMOS integration* (268K p-bits, >50 MHz, <1 W), not the concept. This strengthens F-01 resolution (below).

### S20 — Pelofske et al. benchmarking line — ⚠️ → ✅ (pattern confirmed)
- Recurring result across the line (D-Wave vs classical on Ising/QUBO): **on random graphs that fit the hardware, no quantum speedup vs classical; structured instances can show substantial speedups; minor-embedding is the dominant bottleneck**.
- **Implication for CIM:** directly supports Claude's topology-match prediction and the baseline's embedding-penalty caveat. The lesson transfers: hybrid-solver advantage is instance-class-dependent and embedding-dominated, not architectural in general.

---

## 2. Fork table updates

| Fork | Verdict | Receipt |
|------|---------|---------|
| F-01 (Extropic: "strongest demonstration" vs "most visible attempt") | **Closed — Grok's framing wins.** | 10,000× = company-affiliated simulation (S10 authorship) on toy benchmark; concept predates company (S18); funding non-binding (S2). Reopens only if/when independent silicon measurements appear. |
| F-04 (AI changes economics vs adds control-loop overhead) | Sharpened (below). | C is learnable; AI's unique role is shrinking C via learned embeddings and co-evolving model families. |
| F-07 (one vs ≥2 thermodynamic substrates) | **Confirmed ≥2.** | Extropic analog TSU (S10) vs Normal Computing digital CN101 (S19) — and the academic p-bit line (S18) makes it three. |

---

## 3. New forks

### F-08 — The distillation arms race (open; proposed by Sancho)
Every energy-per-sample claim in the baseline compares against a GPU running *unoptimized or 2022-era sampling*. The cheapest digital response is not better hardware — it is **fewer sampling steps**: consistency models, progressive/adversarial distillation cut diffusion sampling from ~50 steps to 1–4 on existing GPUs. A 10–50× software-side clawback attacks the 10,000× claim at its base.
- **Consequence:** all three testable predictions in the baseline need a "distilled single-step GPU" arm, or they measure a strawman.
- **Sub-claim:** the real market bet underneath Extropic/Normal is not "sampling is fast on physics" — it is "**DTM/EBM-family model architectures will gain adoption share**." That is the algorithm lock-in risk, stated as a falsifiable market prediction (see §5).

### F-09 — Verification asymmetry (open; proposed by Sancho)
Digital state is cheaply copyable; debugging = re-run with instrumentation. A stochastic physical state cannot be replayed — re-running re-rolls the noise. Distributional verification (ESS, correlation structure, goodness-of-fit) costs energy and wall time scaling ~1/ε² in required confidence, and it is a *per-deployment* tax, not a per-chip one.
- **Consequence:** the physical advantage is strongest exactly where downstream use tolerates unverified samples (draft generation, proposal streams). It is weakest where certificates are required (medical, financial, safety).
- **Workaround (the important part):** use the physical sampler as a **proposal engine** inside a digital algorithm that owns accept/reject and verification. Precedent exists — p-bits were proposed for MCMC/Bayesian inference (S18 line). This reframes the benchmark from "10,000× sampling" to "end-to-end energy per accepted sample vs optimized digital MCMC."

### F-10 — Catalog, not biosphere (open; proposed by Sancho)
AI search is not free. Each substrate class carries fixed discovery cost S (device physics + EDA + fabrication + calibration tooling), which must amortize over deployment volume (the Google RL chip-placement economics). 
- **Consequence:** expect a **small catalog of deep niches** (single digits: sampling, in-memory matmul, Ising/optimization, photonic linear transform, reservoir/sensing, ±2 wildcards) — not a bespoke zoo of organisms.
- **Reframes Q7:** the *architecture* (shallow physical + deep digital) is stable; the *membership* is small and stable. "Embedded ecosystems" is right at runtime (multiple substrates co-live on one board), wrong at design time (it is a catalog, not a biosphere).

---

## 4. Sharpening

### 4.1 C is a learnable function — the unit of design is the compiled pair (φ, S)
The baseline treats correspondence overhead C (embedding, encoding, readout, verification) as a fixed tax to be measured. It should be an **optimization target**: learn the mapping φ that minimizes C(P → S) for problem family P and substrate S. 
- Benchmark accordingly: **(S + best learned φ) vs (GPU + best learned algorithm)** — both sides get a learned compiler. No current prediction does this.
- This is the sharpest form of F-04: AI's unique contribution is not designing substrates — it is **learning the embeddings that make substrates cheap to use**, and co-evolving model families (DTM/EBM) so the mapping is native. The lock-in risk is the flip side of the same coin.

### 4.2 Integration pattern: substrate as proposal engine
- Plug Z1-class hardware into Metropolis-Hastings / SMC as the *proposal* source; digital side accepts/rejects and owns verification.
- Sidesteps F-09 entirely; converts the debate from "can physics sample alone?" to "can physics cheapen the expensive part of MCMC?" — a question with an immediate, measurable answer.
- The 10,000× claim becomes irrelevant to this test; the honest metric is **energy per accepted sample at fixed ESS**, full-system.

### 4.3 Q6 note (substrate-native vs DEC)
Labels are cheaper than measurements. Both terms survive as marketing; close the fork on the basis of F-08/F-09 tests, not prose. The operative distinction that matters: "native dynamics as the *algorithm*" vs "native dynamics as an *efficient implementation* of a digital algorithm."

---

## 5. Prediction and protocol deltas

### New predictions
- **P-S1 (Proposal-engine test):** A Z1-class sampler used as an MH proposal source, on a pre-registered target (Bayesian logistic regression or Ising posterior), achieves **<10× end-to-end energy-per-accepted-sample advantage** over optimized digital MCMC (NUTS / parallel tempering), full-system accounting. Falsifier: ≥30×.
- **P-S2 (Distillation clawback):** Z1's energy advantage over a **consistency-model 1-step GPU baseline** on a common generative benchmark is **<100×** (vs the ~10,000× simulated vs naive sampling). Falsifier: ≥300×.
- **P-S3 (Catalog count):** By 2030, commercially deployed physical substrate classes number **≤8**. Falsifier: >12 shipping in production systems.
- **P-S4 (Lock-in adoption):** Track share of generative-model papers/deployments using DTM/EBM-native families. Prediction: stays <20% of generative workloads by 2028 — meaning the "sampling niche" remains a niche unless the model family changes. Falsifier: ≥20%.

### Protocol additions (for the baseline's Next Actions #4)
1. Every energy comparison must report the GPU baseline's sampling method **and step count** (naive MCMC? NUTS? consistency 1-step?), plus ESS-adjusted energy.
2. Pre-register the digital response: allow the digital side to retune algorithms **and distill** after seeing substrate results (mirrors the existing "allowed digital retuning" criterion).
3. Instrument T_verify separately: measure verification energy/time as a function of the confidence target (the 1/ε² curve), never as a single constant.
4. Benchmark the compiled pair, not the bare chip: (substrate + best learned embedding) vs (GPU + best learned sampler), both pre-registered.

---

## 6. Source register delta

| ID | Old | New | Note |
|----|-----|-----|------|
| S2 | ✅ | ✅ | +$874M across 7 cos; Commerce minority equity stakes |
| S10 | ⚠️ | ✅ record / ⚠️ claim | +Company-affiliated authorship (Verdon, Chuang) |
| S18 | ⚠️ | ✅ | Review; +prior-art chain (Camsari et al. 2018) |
| S19 | ⚠️ | ✅ | +Digital stochastic CMOS, taped out, Carnot arch |
| S20 | ⚠️ | ✅ | Pattern: embedding-dominated, instance-class-dependent |

---

*Round 04 complete. Ready for v4.0 synthesis.*
