# VERKLE GAPS — Research Corpus Knot Ledger

**Producer:** Sancho (DeepSeek lane) · **Date:** 2026-08-30
**Lance used:** `python -m mag.verkle_lance self_check` (verkle_lance.v1)
**Corpus checked:** `physical-computing/RESEARCH_SUMMARY_FOR_SALON.md` (baseline v4.0) + `SANCHO-ROUND-04.md`

> **Chain health snapshot (self_check):**
> n_knots=6661 · order_monotonic=✅ · all_content_addressed=✅ · genesis=2026-08-12 · tip=2026-08-27
> **orphans=4** · **untagged=4925 (74%)**

Each knot below is bite-sized and actionable: **gap → why it matters → what closes it.**

---

## VG-0 · 4 orphan knots break the temporal lattice

**Gap (chain health):** `self_check` reports 4 orphans: knots at indices **6395, 6400, 6403, 6439**, all on **2026-08-26**, with `session_id=unknown`, `dominant_theme=null`, filename pattern `_untagged_unknown_`. They sit in the chain but link to no session and carry no theme — they are content-addressed **placeholders**, not events.

**Why it matters:** Orphans break `link()` and `trace()`: an event mapped to that window lands on a knot that cannot say *which session or theme* it anchors. The temporal map (parent→child root linkage) is continuous, but the *semantic* map is hole-y at four points. Reprocessing this day's biography will silently re-tag them as if new.

**Closes when:** each orphan is back-filled with its true `session_id` + `dominant_theme` (+ `start/end_minute`), confirmed against `memory/biography` for that minute. Then `self_check` reports **orphans=0**. (Amend-in-place, as the tip note allows.)

---

## VG-1 · 74% of the lattice is untagged — the corpus has no theme backbone

**Gap (chain health):** **4925 of 6661 knots (74%)** carry `dominant_theme="untagged"`. The verkle chain is the temporal spine of the research corpus; 3-in-4 of its knots say nothing about what they are about. Only ~1,736 knots have real themes, and the large `biography` (842) / `autonomous_janitor` (382) / `mag_hands` (317) buckets are *operational* tags, not *research-subject* tags.

**Why it matters:** `lance(mode="themes")` and `rib_builder()` can only seed the swarm from thematically-labeled knots. With 74% untagged, the theme-based lance converges on a handful of buckets and cannot represent the physical-computing research surface (forks, sources, predictions, principles) as distinct attractors. The corpus is connected in time but not in subject.

**Closes when:** the 4,925 untagged knots are re-themed via a deterministic pass (map `filename`/`dossier_commit` → subject), and — critically — the research subject families **F-xx / S-xx / P-Sxx** are injected as first-class lag themes so the temporal lattice and the research corpus share one vocabulary.

---

## VG-2 · Fork resolutions are prose, not receipts — no F-xx knot

**Gap (fork resolutions):** The corpus resolves forks F-01 (closed), F-04 (sharpened), F-07 (confirmed ≥2), F-08/F-09/F-10 (open) — but **no verkle knot carries an `F-xx` verdict receipt**. There is no knot that can answer "what is the current verdict on F-08, and what evidence closed/held it?" by tracing the chain. F-01's "reopens only if independent silicon measurements appear" condition is a trigger with no knot to fire it.

**Why it matters:** Fork verdicts are the corpus's live decisions. Untied to knots, they exist only in the prose file; `link("F-08")` returns nothing, so any downstream seat (salon, roundtable) cannot pull the *evidence chain* behind a verdict, only the summary line.

**Closes when:** one `fork_knot` per F-xx is created — `{fork, verdict, basis: [S-xx receipts], reopen_condition, ts}`. F-01 gets a `reopen_condition="independent_silicon"` watcher knot. New verdicts amend the fork knot in place (mirroring session-leaf amend behavior).

---

## VG-3 · Source register lacks verification-receipt knots

**Gap (source register):** S2, S10, S18, S19, S20 are tabulated with status (`✅ Confirmed / ⚠️ Claim`), but the **⚠️→✅ verification transitions are prose-only**. S10's company affiliation (Verdon/Chuang), S18's prior-art chain, S20's embedding-dominated pattern, S2's $874M/7-companies detail — none is a queryable knot. There is no `trace("S10")` → the receipt that flipped it.

**Why it matters:** The corpus's credibility rests on these receipts (esp. S10: the 10,000× claim is company-affiliated simulation vs independent silicon). Until each source has a knot carrying `{source, verified_claims, still_claimed, evidence}`, a seat cannot audit *why* a source holds its status — it must re-read prose.

**Closes when:** one `source_knot` per S-xx — `{source, status, verified, still_in_dispute, evidence_file, verified_ts}`. S10 gets an explicit `still_claimed=10,000x_simulation` field so the "independent silicon" reopen condition is machine-checkable.

---

## VG-4 · Testable predictions lack falsifier knots

**Gap (testable predictions):** P-S1..P-S4 each have a prediction + falsifier (`≥30×`, `≥300×`, `>12`, `≥20%`) in prose. But **no knot operationalizes the falsification gate** — there is no record answering "when measured, is this prediction falsified?" via a timestamped measurement. The falsifiers exist as numbers, not as executable gates.

**Why it matters:** Predictions are the one falsifiable asset of the whole thesis. An unfalsified/un-tested prediction is an assertion. Without a `prediction_knot` per P-Sxx carrying its falsifier, measurement outcomes cannot be posted back to the chain, so the corpus cannot flip a prediction to *falsified / not-yet-falsified* and let the next round inherit that state.

**Closes when:** one `prediction_knot` per P-Sxx — `{prediction, falsifier, status: open|measured|falsified|held, preregistered_protocol, measurement_ts}`. P-S1's MH/Bayesian-logistic-regression protocol is pre-registered into the knot so a future measurement posts its ESS result against the `≥30×` gate.

---

## VG-5 · Design principles are statements, not operationalized knots

**Gap (design principles):** Principles 3.1 (C is learnable), 3.2 (substrate as proposal engine), 3.3 (labels vs measurements, close via F-08/F-09 tests) are crisp statements — but **none is operationalized into a measurable protocol knot**. There is no knot that says "the compiled-pair benchmark (S+φ vs GPU+optimized) is *the* unit of measurement for 3.1" or "T_verify must be measured as a 1/ε² curve, never a single constant" (protocol #3).

**Why it matters:** An operationalized principle is a *standing instruction* the swarm can act on; a statement is not. 3.2 ("proposal engine") is the single most important actionable idea (it sidesteps F-09), yet nothing in the chain instructs a seat to build the MH-prototype. The 74% untagged latency (VG-1) also means these principles can't be tied to the events that would test them.

**Closes when:** one `principle_knot` per principle — `{principle, operational_metric, protocol_pointer, status}`. E.g. 3.1 → metric `energy_per_accepted_sample at fixed ESS` on the compiled pair; 3.2 → protocol pointer to pre-registered P-S1 MH test; 3.3 → "resolved by P-S2 (distillation clawback) falsifier"; plus a `T_verify 1/ε²` instrument knot for protocol #3.

---

## VG-6 · Chain/round cadence gap — corpus trail, not events

**Gap (chain health):** `self_check` tip_ts=**2026-08-27**; the corpus baselines are dated **2026-08-29/30**. The research corpus is **ahead of the verkle chain by ~2–3 days**, and the corpus files themselves (baseline v4.0, round 04) are **not represented as knots at all** — only operational sessions are. The round/corpus trail is not yet part of the temporal lattice.

**Why it matters:** The whole point of lancing is to tie events temporally to roots. If the corpus artifacts (rounds, baselines, fork verdicts from VG-2) never enter the chain, then the research corpus floats free of the deterministic timeline — the very linkage verkle_lance exists to provide.

**Closes when:** the corpus artifacts (SANCHO-ROUND-04, RESEARCH_SUMMARY_FOR_SALON) are ingested as `artifact_knot` leaves with `dominant_theme` drawn from the F-/S-/P- families, and the chain is advanced past the 2026-08-30 as-of date so `trace("round-04")` and `link("baseline-v4.0")` both resolve.

---

## Close order (dependency-aware)

1. **VG-0** (orphans) → cleanest, pure back-fill, unblocks clean `link()`.
2. **VG-1** (re-theme 74% + introduce F/S/P families as themes) → prerequisite vocabulary for VG-2..VG-5.
3. **VG-2 → VG-3 → VG-4 → VG-5** (fork / source / prediction / principle knots) → buildable in parallel once the theme vocabulary exists.
4. **VG-6** (ingest corpus artifacts into chain) → ties it all back into the deterministic timeline.

**Definition of done:** `verkle_lance self_check` reports **orphans=0**, far fewer `untagged`, and `trace("F-08")`, `trace("S10")`, `trace("P-S1")`, `link("principle-3.2")` all return populated knots with receipts.

---

*Prepared by Sancho — 2026-08-30. Knot ledger for the salon synthesis round.*
