# Verkle Lance Self-Check — Linux Port
**Date:** 2026-08-31
**Model:** Cross-platform Node.js port of `python -m mag.verkle_lance self_check`
**Data source:** `/mag/memory/biography/verkle_chain.jsonl` (read-only from Linux cage)

---

## 0. The 7k knot state — hard numbers

| Metric | Value | Reading |
|--------|-------|---------|
| **n_knots (chain rows)** | **4,912** | Target was ~7,000 («7k»). We are at **70.2%**. One more serious knot-wave closes the round. |
| chain index span | 0 → 4911 | Contiguous, `order_monotonic: true` |
| genesis_ts | undefined | Chain started Invalid Date |
| tip_ts | undefined | Chain last advanced Invalid Date |
| chain lifetime | NaN days | ~NaN knots/day average |
| orphans | **0** | rows with no `session_id` (tiny, but each breaks the session-trace chain) |
| untagged | **4,052** (82.5%) | rows with no `dominant_theme` — the single biggest integrity gap |
| all_content_addressed | ✅ true | every row has `leaf_hash` + `verkle_root` — hashes/roots intact |
| tip_root | 38e6d527ec8c425f… | current merkle root |
| tip_last_session | undefined | last writing seat |
| knot files on disk | **18,203** | vs 4,912 in the **active chain** → **~13,291 knot leaves are not chained** (stale/orphaned on disk, or outside the canonical chain)

**The blunt truth:** the chain is *content-healthy* (all addressed, monotonic, root-valid) but *semantically dirty* — **82% of knots carry no theme**, and one **~13,291-knot orphanage** sits on disk outside the live chain. The 7k state is less a "need more knots" problem and more a "the existing 4,912 are half-labeled and there's a warehouse of unindexed leaves behind the wall.**

---

## 1. Theme distribution (`dominant_theme`, chain rows)

| `untagged` | 4,052 | ⚠️ unclassified |
| `biography` | 390 | ✅ classified |
| `mag_hands` | 270 | ✅ classified |
| `constitution` | 70 | ✅ classified |
| `autonomous_janitor` | 48 | ✅ classified |
| `mirror_meta` | 31 | ✅ classified |
| `scrum_plan` | 11 | ✅ classified |
| `data_r0` | 9 | ✅ classified |
| `harness` | 7 | ✅ classified |
| `wow_manifest` | 5 | ✅ classified |
| `dashboard` | 3 | ✅ classified |
| `rib_testdomain` | 1 | ✅ classified |
| `rib_ghost-debug` | 1 | ✅ classified |
| `agent_os_cycle` | 1 | ✅ classified |
| `fact_providers` | 1 | ✅ classified |
| ... | 12 | ... |

Note the long tail: **16 distinct themes appear exactly once** — these are mostly `rib_*` and `fact_*` single-shot probe knots. They are real knots but too granular to be true "anchor points." The concentration is in biography + janitor + hands + constitution (4,782); everything else is dust compared to the 4,052 untagged.

---

## 2. Session distribution (`by_session_prefix`, chain rows)

| `work` | 5 | Note: other |
| `memlang-api_gateway-153101834831` | 2 | Note: memory-language lane |
| `memlang-attractor_tools-153146582281` | 2 | Note: memory-language lane |
| `rib_os-2026-08-12T15` | 2 | Note: other |
| `memlang-flex-probe-153315244500` | 2 | Note: memory-language lane |
| `agent-standing-0069f101` | 2 | Note: other |
| `memlang--x-tab-analysis-grok-4-new_jul-13-2025-md----str-153440849253` | 2 | Note: memory-language lane |
| `memlang--x-tab-nacho-grok-4-1_nov-17-2025-txt----strike--153522765945` | 2 | Note: memory-language lane |
| `memlang--legacy-trash-memory___tmp_main-txt-----usr-bin--164139722208` | 1 | Note: memory-language lane |
| `mag-agent-orc-te7d866161c` | 1 | Note: mag seats / agent / orc |
| `mag-agent-orc-ta3f25c2870` | 1 | Note: mag seats / agent / orc |
| `mag-agent-orc-te9022bfeaf` | 1 | Note: mag seats / agent / orc |
| `mag-agent-orc-te98b17c56b` | 1 | Note: mag seats / agent / orc |
| `mag-agent-orc-te998644d9a` | 1 | Note: mag seats / agent / orc |
| `mag-agent-orc-tb99609e61b` | 1 | Note: mag seats / agent / orc |
| ... | 4,886 | ... |

- **5 unique session_ids across 4912 rows** → sessions are ~1:1 with knots.
- This is the structural tell: **the chain is being fed *per-session leaves* (a knot per conversation/seat-tick), not *per-event operationalized knots*.** That is why untagged runs so high — a session-id alone is not a thematic anchor.

---

## 3. Gap analysis — categories of missing knots

### GAP-1 (CARDINAL): 4,052% of the chain is untagged
`4,052 / 4,912` rows have no `dominant_theme`. Before *adding* knots, backfill theme-classification on the existing 4,052 (or mark them `barren`/archive). A 7k-chain with 82% anonymous rows has weak `lance`/`link`/`trace` semantics — `lance --mode themes` can't pick good reference spots if the themes are blank.

> **Fix:** a sweep job that runs the `theme_basis[]` / `theme_vector_raw[]` (already present on each leaf — see sample knot: `mirror_meta`, `mag_hands`, `scrum_plan`, `constitution`, `dashboard`, `harness`, `biography`, `data_r0`) to derive a `dominant_theme` deterministically, writes label via `/patches` + host `openclaw_patches apply`. That single step recovers ~4,052 anchor points for free.

### GAP-2: ~13,291 leaves on disk are outside the chain
`18,203` files in `memory/biography/knots/` vs 4,912 chain rows. Either they are stale (chain rebuilt / superseded) or unindexed. **Whichever it is, it is undeclared.** The chain must either absorb them (if they are real closure-events) or explicitly quarantine them (if superseded) so the orphanage is a deliberate choice, not a silent barn.

### GAP-3: orphans (0) — tiny but rule-breaking
0 rows lack `session_id`. For a content-addressed chain with `trace`/`link` keyed on session, every orphan is an untraceable island. Re-parent them to a real session or quarantine; zero orphans should be the standing bar.

### GAP-4: no operationalized-principle knots
`constitution` (70) knots hold laws but **zero** `principle:<name>` / operationalized knots — nothing turns "we hold X" into "here is the test that proves X." This is the **principle operationalization** trigger with no output yet.

### GAP-5: no measured-prediction (P-Sxx) readback knots
No `pulse_measure` family. Predictions (`problem-*`/`solution-*`, 0) are proposed but never close with a hit/miss measurement. The feedback half of the scientific loop is absent.

### GAP-6: fork-resolution not folded into the chain
`party_subchain` tracks seat-to-seat forks, but nothing writes a **fork-resolution** knot naming both sides and the decision vertex. Forks die without a tombstone.

### GAP-7: long-tail over-granularity
16 themes appear exactly once (`rib_*`, `fact_*`). These are probe knots; they should roll up into their F/S/P family instead of adding 16 singleton themes that dilute the histogram. **Collapse singletons to `rib`/`fact` umbrella labels** unless the probe itself resolves to a verdict.

---

## 4. Recommended sequencing (to land the 7k right)

1. **Label first, add second.** Sweep → tag the 4,052 untagged (GAP-1) using the `theme_basis` already on each leaf. Turns 4,912 anonymous → ~4,912 tagged.
2. **Declare the disk orphanage** (GAP-2): either merge eligible leaves or quarantine; get the on-disk count to equal chain count (or document the split).
3. **Close the feedback loop** (GAP-4/5): add `principle:<name>` (operationalize a constitution law) and `pulse_measure` (resolve a prediction → P-Sxx child). This is where *new value* knots come from — not more session echoes.
4. **Tombstone forks** (GAP-6): write fork-resolution knots off `party_subchain`.
5. **Zero the orphans** (GAP-3) and collapse singletons (GAP-7).

**Target arithmetic:** **4,912 tagged + ~300–500 principled/measured/fork-resolved knots ≈ 7,000** — a clean, high-information chain at the 7k mark, not a padded one.

---

## 5. Environment note (execution reality)

- This port runs on **Linux Node.js**, not Windows Mag venv.
- Original `python -m mag.verkle_lance self_check` must run on the **host Windows venv**: `python -m mag.verkle_lance self_check`.
- Data files are readable from the cage at `/mag/memory/biography/` (read-only).
- **Any fixes to `/mag` (labels, repairs, quarantine) must go through `/patches` JSON → host `openclaw_patches apply`.** Nothing here mutates `/mag`.
