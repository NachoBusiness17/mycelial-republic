# Verkle Lance Port Strategy — Dogfood for Self-Steal

**Producer:** Sancho (DeepSeek lane) + Operator Nacho
**Date:** 2026-08-30
**Lens:** Chain health + tool portability + dogfood

---

## Pain Point

**Current state:** Mag venv is Windows-only. Linux cage cannot run `python -m mag.verkle_lance self_check`.

**Impact:**
- Cannot audit chain health from Linux
- Cannot run verkle lance on-demand for gap analysis
- Subagent workaround is slow (spawn → wait → copy output)
- Repeated for every chain check

---

## What Needs to Be Ported

### 1. Verkle Lance Core (Python)
**Command:** `python -m mag.verkle_lance self_check`

**Dependencies:**
- `/mag/memory/` — chain storage (verkle chain files)
- `/mag/docs/ref/` — schema definitions
- `mag.verkle_lance` module — core logic

**Port options:**
1. **Cross-platform Python shim:** Run on both Windows and Linux, with path normalization
2. **Dockerized:** Containerized Mag environment accessible from Linux
3. **WSL bridge:** Run Python from Windows via WSL path mapping

**Recommended:** Option 1 (cross-platform shim) — fastest, no infrastructure cost, same codebase.

---

### 2. Chain Storage (Read-Only)
**Location:** `/mag/memory/runs/verkle_chain/`

**Access pattern:**
- Read-only access (no writes from Linux)
- Load chain state, compute statistics (orphans, untagged, themes)
- Export results as JSON for analysis

**Port strategy:** Copy chain files to Linux workspace for read-only access, then run verkle lance in-process.

---

### 3. Chain Schema (Documentation)
**Location:** `/mag/docs/ref/VERKLE_SCHEMA.md`

**What it defines:**
- Knot structure (knot_id, session_id, dominant_theme, ts, content_hash)
- Theme families (F-xx, S-xx, P-Sxx, principle, protocol)
- Session IDs and their roles
- Chain operations (link, trace, amend)

**Port strategy:** Inline schema in ported tool, with comments referencing source.

---

## Implementation Plan

### Phase 1: Minimal Port (Today)
**Goal:** Run `verkle_lance self_check` from Linux.

**Steps:**
1. Copy chain files from `/mag/memory/runs/verkle_chain/` to `/root/.openclaw/workspace/verkle_chain/`
2. Port `mag.verkle_lance` core logic to a standalone script:
   - Load chain state
   - Compute statistics (orphans, untagged, themes)
   - Export JSON
3. Test from Linux: `python verkle_lance.py self_check`

**Deliverable:** `verkle_lance.py` (standalone, cross-platform)

---

### Phase 2: Full Port (Tomorrow)
**Goal:** All verkle lance commands available from Linux.

**Commands to port:**
- `verkle_lance self_check` — chain health
- `verkle_lance trace <id>` — follow knot chain
- `verkle_lance link <parent> <child>` — create new knot
- `verkle_lance themes` — theme distribution
- `verkle_lance amend <id> <content>` — update knot

**Deliverable:** `verkle_lance.py` with all commands

---

### Phase 3: Integration (Next Round)
**Goal:** Verkle lance as first-class OpenClaw tool.

**Integration points:**
- `verkle_lance self_check` in gap analysis workflow
- `verkle_lance trace` for salon synthesis
- `verkle_lance link` for creating fork/source/prediction knots
- `verkle_lance themes` for theme backbone

**Deliverable:** OpenClaw tool registration, documented in catalog

---

## Dogfood Insights

### What We're Learning

1. **Tool portability is critical:**
   - Chain health checks should be instant, not spawn-based
   - Linux cage must have read access to chain files
   - No Windows-specific path magic in the ported tool

2. **Read-only access pattern:**
   - Chain files are read-only from Linux
   - Writes only happen on host (Mag venv)
   - Linux tool is a "viewer," not a "writer"

3. **Schema-driven design:**
   - VERKLE_SCHEMA.md is the source of truth
   - Ported tool must implement schema, not invent it
   - Comments should reference schema sections

---

## Success Criteria

### Definition of Done
- ✅ `python verkle_lance.py self_check` runs from Linux
- ✅ Output matches host version (same statistics)
- ✅ Chain files remain read-only on Linux
- ✅ Tool is cross-platform (Windows + Linux)
- ✅ Documentation updated (catalog entry + inline help)

### Metrics
- **Time to run self_check:** < 5 seconds (was ~10 seconds via spawn)
- **Disk access:** Only read chain files (no writes)
- **Code duplication:** < 50% compared to host version

---

## Self-Steal Material

This port is **self-steal** because:
1. We're fixing a current pain point (chain health checks)
2. We're learning the right way to operate (cross-platform tooling)
3. The solution will be reused for future chain operations
4. The process itself is documented as verkle knot material

**Future value:**
- Any chain-based corpus (not just physical computing) can use this tool
- Salon synthesis rounds can run verkle lance locally
- Gap analysis becomes a one-command operation, not a spawn

---

## Next Actions

1. **Port verkle lance core** (Phase 1) — minimal viable, run self_check from Linux
2. **Test cross-platform** — verify Windows + Linux both work
3. **Document schema** — inline VERKLE_SCHEMA.md into tool
4. **Integrate** — add to catalog, use in gap analysis workflow

---

*Prepared by Sancho — 2026-08-30. Dogfood in action: fix the pain, learn the pattern, reuse the solution.*
