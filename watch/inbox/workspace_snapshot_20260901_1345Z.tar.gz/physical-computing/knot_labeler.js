#!/usr/bin/env node
/**
 * Verkle Lance Knot Labeler — Phase 1: Label Untagged Knots
 *
 * This script reads the chain, identifies untagged knots, and uses the
 * `theme_basis[]` and `theme_vector_raw[]` fields to assign `dominant_theme`
 * labels. Labels are written to a JSON patch file for the host to apply.
 *
 * Design: Replicate Python theme classification logic against the same JSONL.
 * Edits to /mag still go through /patches → host jail.
 */

const fs = require('fs');
const path = require('path');

// Configuration
const MAG_DIR = '/mag/memory/biography';
const CHAIN_FILE = path.join(MAG_DIR, 'verkle_chain.jsonl');
const PATCH_FILE = '/root/.openclaw/workspace/physical-computing/knot_labeling_patch.json';

// Theme classification rules (simplified from Python implementation)
function classifyTheme(knot) {
  const { theme_basis, theme_vector_raw, session_id, dominant_theme } = knot;

  // If already tagged, return as-is
  if (dominant_theme && dominant_theme !== 'untagged') {
    return { label: dominant_theme, confidence: 1.0 };
  }

  // If no theme data, default to session-based
  if (!theme_basis || !theme_vector_raw) {
    if (session_id) {
      const prefix = session_id.split(':')[0];
      if (prefix.startsWith('memlang')) return { label: 'memlang_session', confidence: 0.5 };
      if (prefix.startsWith('mag')) return { label: 'mag_session', confidence: 0.5 };
      return { label: 'session_based', confidence: 0.5 };
    }
    return { label: 'untagged', confidence: 0.0 };
  }

  // Simple theme inference from theme_basis keywords
  const basis = theme_basis.toLowerCase();
  const vector = theme_vector_raw;

  // Heuristic rules (can be expanded)
  const rules = [
    { keywords: ['constitution', 'law', 'principle', 'rule'], label: 'constitution' },
    { keywords: ['problem', 'solution', 'prediction', 'test'], label: 'problem' },
    { keywords: ['fork', 'resolution', 'merge', 'reconcile'], label: 'fork' },
    { keywords: ['session', 'conversation', 'chat', 'message'], label: 'biography' },
    { keywords: ['verification', 'check', 'verify', 'audit'], label: 'autonomous_janitor' },
    { keywords: ['fabric', 'catalog', 'tool', 'module', 'subtool'], label: 'harness' },
    { keywords: ['dashboard', 'status', 'metrics'], label: 'dashboard' },
    { keywords: ['manifest', 'vision', 'mission'], label: 'wow_manifest' },
  ];

  for (const rule of rules) {
    if (rule.keywords.some(kw => basis.includes(kw))) {
      return { label: rule.label, confidence: 0.7 };
    }
  }

  // Default: session-based
  return { label: 'session_based', confidence: 0.5 };
}

// Analyze and label knots
function runLabeler() {
  console.log('🏷️  Verkle Lance Knot Labeler — Phase 1\n');

  // Read chain
  console.log('📖 Reading chain...');
  const lines = fs.readFileSync(CHAIN_FILE, 'utf-8').trim().split('\n');
  const knots = lines.map((line, idx) => {
    try {
      const row = JSON.parse(line);
      return { idx, ...row };
    } catch (e) {
      console.error(`Failed to parse line ${idx}: ${line.substring(0, 50)}...`);
      return null;
    }
  }).filter(Boolean);

  console.log(`   Found ${knots.length} knots in chain\n`);

  // Identify untagged knots
  const untagged = knots.filter(k => !k.dominant_theme || k.dominant_theme === 'untagged');
  console.log(`   Found ${untagged.length} untagged knots (${((untagged.length / knots.length) * 100).toFixed(1)}%)\n`);

  // Classify each untagged knot
  const labeled = [];
  const stats = {};

  untagged.forEach(knot => {
    const { label, confidence } = classifyTheme(knot);
    stats[label] = (stats[label] || 0) + 1;

    labeled.push({
      index: knot.idx,
      old_dominant_theme: knot.dominant_theme || 'untagged',
      new_dominant_theme: label,
      confidence,
      session_id: knot.session_id,
      has_theme_basis: !!knot.theme_basis,
      has_theme_vector: !!knot.theme_vector_raw
    });
  });

  console.log('📊 Label distribution:');
  Object.entries(stats)
    .sort((a, b) => b[1] - a[1])
    .forEach(([label, count]) => {
      console.log(`   ${label}: ${count} (${((count / untagged.length) * 100).toFixed(1)}%)`);
    });
  console.log('');

  // Build patch
  const patch = {
    schema: 'verkle_lance.knot_labeling.v1',
    ts: new Date().toISOString(),
    description: 'Label untagged verkle knots using theme_basis',
    operation: 'update',
    targets: labeled.map(l => ({
      path: `/memory/biography/verkle_chain.jsonl:${l.index}`,
      op: 'replace',
      value: {
        dominant_theme: l.new_dominant_theme
      }
    }))
  };

  // Write patch
  fs.writeFileSync(PATCH_FILE, JSON.stringify(patch, null, 2), 'utf-8');
  console.log(`✅ Patch written to: ${PATCH_FILE}\n`);
  console.log('Next steps:');
  console.log(`1. Review the patch: cat ${PATCH_FILE}`);
  console.log(`2. Apply to host: python -m mag.openclaw_patches apply`);
  console.log(`3. Verify: node knot_labeler.js`);
}

// Run if executed directly
if (require.main === module) {
  runLabeler();
}

module.exports = { runLabeler, classifyTheme };
