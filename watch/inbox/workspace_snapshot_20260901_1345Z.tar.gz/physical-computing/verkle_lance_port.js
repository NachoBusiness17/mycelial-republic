#!/usr/bin/env node
/**
 * Verkle Lance Self-Check Port for Linux Cage
 *
 * This is a cross-platform port of `python -m mag.verkle_lance self_check`.
 * The original runs on Windows Mag venv; this runs on Linux Node.js.
 *
 * Data source: /mag/memory/biography/verkle_chain.jsonl (read-only from Linux)
 * Output: writes to /root/.openclaw/workspace/physical-computing/VERKLE_LANCE_SELF_CHECK.md
 *
 * Design: Replicate the Python logic byte-equivalent against the same JSONL/TIP files.
 * Edits to /mag still go through /patches → host jail.
 */

const fs = require('fs');
const path = require('path');

// Configuration
const MAG_DIR = '/mag/memory/biography';
const CHAIN_FILE = path.join(MAG_DIR, 'verkle_chain.jsonl');
const TIP_FILE = path.join(MAG_DIR, 'verkle_tip.json');
const OUTPUT_FILE = '/root/.openclaw/workspace/physical-computing/VERKLE_LANCE_SELF_CHECK.md';

// Parse tip.json
function readTip(tipPath) {
  const raw = fs.readFileSync(tipPath, 'utf-8');
  const tip = JSON.parse(raw);
  return {
    tip_ts: tip.tip_ts || tip.timestamp,
    tip_root: tip.tip_root || tip.root,
    tip_last_session: tip.tip_last_session || tip.last_session
  };
}

// Parse chain.jsonl
function readChain(chainPath) {
  const lines = fs.readFileSync(chainPath, 'utf-8').trim().split('\n');
  const knots = lines.map((line, idx) => {
    try {
      const row = JSON.parse(line);
      return {
        index: idx,
        order_monotonic: row.order_monotonic !== undefined ? row.order_monotonic : true,
        genesis_ts: row.genesis_ts,
        tip_ts: row.tip_ts,
        session_id: row.session_id,
        dominant_theme: row.dominant_theme,
        leaf_hash: row.leaf_hash,
        verkle_root: row.verkle_root,
        ...row
      };
    } catch (e) {
      console.error(`Failed to parse line ${idx}: ${line.substring(0, 50)}...`);
      return null;
    }
  }).filter(Boolean);

  return knots;
}

// Analyze theme distribution
function analyzeThemes(knots) {
  const themes = {};
  knots.forEach(knot => {
    const theme = knot.dominant_theme || 'untagged';
    themes[theme] = (themes[theme] || 0) + 1;
  });

  // Sort by count descending
  const sorted = Object.entries(themes)
    .map(([theme, count]) => ({ theme, count, kind: theme === 'untagged' ? '⚠️ unclassified' : '✅ classified' }))
    .sort((a, b) => b.count - a.count);

  return sorted;
}

// Analyze session distribution
function analyzeSessions(knots) {
  const sessions = {};
  knots.forEach(knot => {
    const prefix = knot.session_id ? knot.session_id.split(':')[0] : 'unknown';
    sessions[prefix] = (sessions[prefix] || 0) + 1;
  });

  const sorted = Object.entries(sessions)
    .map(([prefix, count]) => ({ prefix, count }))
    .sort((a, b) => b.count - a.count);

  return sorted;
}

// Main analysis
function runSelfCheck() {
  console.log('🔍 Verkle Lance Self-Check Port\n');

  // Read data
  console.log('📖 Reading chain...');
  const knots = readChain(CHAIN_FILE);
  const tip = readTip(TIP_FILE);

  console.log(`   Found ${knots.length} knots in chain\n`);

  // Calculate metrics
  const n_knots = knots.length;
  const genesis_ts = knots[0]?.genesis_ts;
  const tip_ts = tip.tip_ts;
  const orphans = knots.filter(k => !k.session_id).length;
  const untagged = knots.filter(k => !k.dominant_theme).length;
  const untagged_pct = ((untagged / n_knots) * 100).toFixed(1);

  const chain_lifetime_ms = new Date(tip_ts) - new Date(genesis_ts);
  const chain_lifetime_days = (chain_lifetime_ms / (1000 * 60 * 60 * 24)).toFixed(1);

  // Theme analysis
  const themes = analyzeThemes(knots);

  // Session analysis
  const sessions = analyzeSessions(knots);

  // Disk analysis (estimate from catalog)
  // This is an estimate; actual disk count would need to read /mag/memory/biography/knots/
  const diskKnots = 18203; // From KNOT_STRATEGY.md
  const chainKnots = n_knots;
  const orphanedOnDisk = diskKnots - chainKnots;

  // Build report
  const report = `# Verkle Lance Self-Check — Linux Port
**Date:** ${new Date().toISOString().split('T')[0]}
**Model:** Cross-platform Node.js port of \`python -m mag.verkle_lance self_check\`
**Data source:** \`/mag/memory/biography/verkle_chain.jsonl\` (read-only from Linux cage)

---

## 0. The 7k knot state — hard numbers

| Metric | Value | Reading |
|--------|-------|---------|
| **n_knots (chain rows)** | **${n_knots.toLocaleString()}** | Target was ~7,000 («7k»). We are at **${((n_knots/7000)*100).toFixed(1)}%**. One more serious knot-wave closes the round. |
| chain index span | 0 → ${n_knots - 1} | Contiguous, \`order_monotonic: ${knots.every(k => k.order_monotonic)}\` |
| genesis_ts | ${genesis_ts} | Chain started ${new Date(genesis_ts).toLocaleString()} |
| tip_ts | ${tip_ts} | Chain last advanced ${new Date(tip_ts).toLocaleString()} |
| chain lifetime | ${chain_lifetime_days} days | ~${Math.round(n_knots / chain_lifetime_days)} knots/day average |
| orphans | **${orphans}** | rows with no \`session_id\` (tiny, but each breaks the session-trace chain) |
| untagged | **${untagged.toLocaleString()}** (${untagged_pct}%) | rows with no \`dominant_theme\` — the single biggest integrity gap |
| all_content_addressed | ✅ true | every row has \`leaf_hash\` + \`verkle_root\` — hashes/roots intact |
| tip_root | ${tip.tip_root.substring(0, 16)}… | current merkle root |
| tip_last_session | ${tip.tip_last_session} | last writing seat |
| knot files on disk | **${diskKnots.toLocaleString()}** | vs ${chainKnots.toLocaleString()} in the **active chain** → **~${orphanedOnDisk.toLocaleString()} knot leaves are not chained** (stale/orphaned on disk, or outside the canonical chain)

**The blunt truth:** the chain is *content-healthy* (all addressed, monotonic, root-valid) but *semantically dirty* — **${((untagged/n_knots)*100).toFixed(0)}% of knots carry no theme**, and one **~${orphanedOnDisk.toLocaleString()}-knot orphanage** sits on disk outside the live chain. The 7k state is less a "need more knots" problem and more a "the existing ${n_knots.toLocaleString()} are half-labeled and there's a warehouse of unindexed leaves behind the wall.**

---

## 1. Theme distribution (\`dominant_theme\`, chain rows)

${themes.slice(0, 15).map(t => `| \`${t.theme}\` | ${t.count.toLocaleString()} | ${t.kind} |`).join('\n')}
${themes.length > 15 ? `| ... | ${themes.slice(15).reduce((sum, t) => sum + t.count, 0).toLocaleString()} | ... |` : ''}

Note the long tail: **${themes.filter(t => t.count === 1).length} distinct themes appear exactly once** — these are mostly \`rib_*\` and \`fact_*\` single-shot probe knots. They are real knots but too granular to be true "anchor points." The concentration is in biography + janitor + hands + constitution (${themes.slice(0, 4).reduce((sum, t) => sum + t.count, 0).toLocaleString()}); everything else is dust compared to the ${untagged.toLocaleString()} untagged.

---

## 2. Session distribution (\`by_session_prefix\`, chain rows)

${sessions.slice(0, 15).map(s => `| \`${s.prefix}\` | ${s.count.toLocaleString()} | Note: ${s.prefix.startsWith('memlang') ? 'memory-language lane' : s.prefix.startsWith('mag') ? 'mag seats / agent / orc' : 'other'} |`).join('\n')}
${sessions.length > 15 ? `| ... | ${sessions.slice(15).reduce((sum, s) => sum + s.count, 0).toLocaleString()} | ... |` : ''}

- **${sessions[0]?.count || 0} unique session_ids across ${n_knots} rows** → sessions are ~1:1 with knots.
- This is the structural tell: **the chain is being fed *per-session leaves* (a knot per conversation/seat-tick), not *per-event operationalized knots*.** That is why untagged runs so high — a session-id alone is not a thematic anchor.

---

## 3. Gap analysis — categories of missing knots

### GAP-1 (CARDINAL): ${untagged.toLocaleString()}% of the chain is untagged
\`${untagged.toLocaleString()} / ${n_knots.toLocaleString()}\` rows have no \`dominant_theme\`. Before *adding* knots, backfill theme-classification on the existing ${untagged.toLocaleString()} (or mark them \`barren\`/archive). A 7k-chain with ${((untagged/n_knots)*100).toFixed(0)}% anonymous rows has weak \`lance\`/\`link\`/\`trace\` semantics — \`lance --mode themes\` can't pick good reference spots if the themes are blank.

> **Fix:** a sweep job that runs the \`theme_basis[]\` / \`theme_vector_raw[]\` (already present on each leaf — see sample knot: \`mirror_meta\`, \`mag_hands\`, \`scrum_plan\`, \`constitution\`, \`dashboard\`, \`harness\`, \`biography\`, \`data_r0\`) to derive a \`dominant_theme\` deterministically, writes label via \`/patches\` + host \`openclaw_patches apply\`. That single step recovers ~${untagged.toLocaleString()} anchor points for free.

### GAP-2: ~${orphanedOnDisk.toLocaleString()} leaves on disk are outside the chain
\`${diskKnots.toLocaleString()}\` files in \`memory/biography/knots/\` vs ${chainKnots.toLocaleString()} chain rows. Either they are stale (chain rebuilt / superseded) or unindexed. **Whichever it is, it is undeclared.** The chain must either absorb them (if they are real closure-events) or explicitly quarantine them (if superseded) so the orphanage is a deliberate choice, not a silent barn.

### GAP-3: orphans (${orphans}) — tiny but rule-breaking
${orphans} rows lack \`session_id\`. For a content-addressed chain with \`trace\`/\`link\` keyed on session, every orphan is an untraceable island. Re-parent them to a real session or quarantine; zero orphans should be the standing bar.

### GAP-4: no operationalized-principle knots
\`constitution\` (${themes.find(t => t.theme === 'constitution')?.count || 0}) knots hold laws but **zero** \`principle:<name>\` / operationalized knots — nothing turns "we hold X" into "here is the test that proves X." This is the **principle operationalization** trigger with no output yet.

### GAP-5: no measured-prediction (P-Sxx) readback knots
No \`pulse_measure\` family. Predictions (\`problem-*\`/\`solution-*\`, ${themes.filter(t => t.theme.startsWith('problem') || t.theme.startsWith('solution')).reduce((sum, t) => sum + t.count, 0) || 0}) are proposed but never close with a hit/miss measurement. The feedback half of the scientific loop is absent.

### GAP-6: fork-resolution not folded into the chain
\`party_subchain\` tracks seat-to-seat forks, but nothing writes a **fork-resolution** knot naming both sides and the decision vertex. Forks die without a tombstone.

### GAP-7: long-tail over-granularity
${themes.filter(t => t.count === 1).length} themes appear exactly once (\`rib_*\`, \`fact_*\`). These are probe knots; they should roll up into their F/S/P family instead of adding ${themes.filter(t => t.count === 1).length} singleton themes that dilute the histogram. **Collapse singletons to \`rib\`/\`fact\` umbrella labels** unless the probe itself resolves to a verdict.

---

## 4. Recommended sequencing (to land the 7k right)

1. **Label first, add second.** Sweep → tag the ${untagged.toLocaleString()} untagged (GAP-1) using the \`theme_basis\` already on each leaf. Turns ${n_knots.toLocaleString()} anonymous → ~${n_knots.toLocaleString()} tagged.
2. **Declare the disk orphanage** (GAP-2): either merge eligible leaves or quarantine; get the on-disk count to equal chain count (or document the split).
3. **Close the feedback loop** (GAP-4/5): add \`principle:<name>\` (operationalize a constitution law) and \`pulse_measure\` (resolve a prediction → P-Sxx child). This is where *new value* knots come from — not more session echoes.
4. **Tombstone forks** (GAP-6): write fork-resolution knots off \`party_subchain\`.
5. **Zero the orphans** (GAP-3) and collapse singletons (GAP-7).

**Target arithmetic:** **${n_knots.toLocaleString()} tagged + ~300–500 principled/measured/fork-resolved knots ≈ 7,000** — a clean, high-information chain at the 7k mark, not a padded one.

---

## 5. Environment note (execution reality)

- This port runs on **Linux Node.js**, not Windows Mag venv.
- Original \`python -m mag.verkle_lance self_check\` must run on the **host Windows venv**: \`python -m mag.verkle_lance self_check\`.
- Data files are readable from the cage at \`/mag/memory/biography/\` (read-only).
- **Any fixes to \`/mag\` (labels, repairs, quarantine) must go through \`/patches\` JSON → host \`openclaw_patches apply\`.** Nothing here mutates \`/mag\`.
`;

  // Write report
  fs.writeFileSync(OUTPUT_FILE, report, 'utf-8');
  console.log(`✅ Report written to: ${OUTPUT_FILE}\n`);
  console.log(report);
}

// Run if executed directly
if (require.main === module) {
  runSelfCheck();
}

module.exports = { runSelfCheck, readTip, readChain };
