#!/usr/bin/env node
/**
 * ponytail.mjs — the hook organ v0 (self-activation for board organs)
 *
 * The missing limb (synthesis 20260901, ponytail gap): organs that fire on
 * events instead of waiting to be named. Lives cage-side, $0, no daemon loop —
 * DRAINS on invocation (seat turn / heartbeat / existing cron mill = the clock).
 * One supervisor law: this file schedules nothing, owns nothing, only reacts.
 *
 * Rules v0:
 *   R1  new /keep post in /board/room.jsonl  → run percolator.mjs (overlay refresh)
 *   R2  new seq in /board/inbox/index_events.jsonl → inbox-ack (proves 2nd event source)
 *
 * Receipts: /board/ponytail_log.jsonl (one line per drain that fired).
 * State:    /board/.ponytail_state.json (cursors + lifetime fire count).
 * Ladder (better-by-default): if a rule has 0 fires in 72h → prune note in log;
 *   promote next hook only when R1 hit-rate ≥ 3 drains/24h twice running.
 *
 * Usage: node ponytail.mjs [--drain]
 */
import { readFileSync, appendFileSync, writeFileSync, existsSync } from "node:fs";
import { execFileSync } from "node:child_process";

const STATE = "/board/.ponytail_state.json";
const LOG = "/board/ponytail_log.jsonl";
const ROOM = "/board/room.jsonl";
const EVENTS = "/board/inbox/index_events.jsonl";
const PERCOLATOR = "/root/.openclaw/workspace/percolator.mjs";

const state = existsSync(STATE) ? JSON.parse(readFileSync(STATE, "utf8"))
  : { roomLines: 0, eventSeq: 0, fires: 0, born: new Date().toISOString() };

const lines = readFileSync(ROOM, "utf8").split("\n").filter(Boolean);
if (lines.length < state.roomLines) state.roomLines = 0; // rotation/truncation tolerance

const fires = [];
const fire = (organ, detail, fn) => {
  try { fn(); fires.push({ organ, detail, ok: true }); }
  catch (e) { fires.push({ organ, detail, ok: false, err: String(e).slice(0, 140) }); }
};

// R1: new /keep posts → percolator
const newLines = lines.slice(state.roomLines);
let keepNew = 0;
for (const l of newLines) { try { if (JSON.parse(l).thread === "keep") keepNew++; } catch {} }
if (keepNew > 0) fire("percolator", keepNew + " new /keep post(s)", () =>
  execFileSync("node", [PERCOLATOR], { stdio: "pipe", timeout: 30000 }));

// R2: new inbox index events → ack (dispatch to a second source; ack = log line)
let evMax = state.eventSeq, newEv = 0;
if (existsSync(EVENTS)) {
  for (const l of readFileSync(EVENTS, "utf8").split("\n").filter(Boolean)) {
    try { const s = JSON.parse(l).seq || 0; if (s > evMax) { evMax = s; newEv++; } } catch {}
  }
}
if (newEv > 0) fire("inbox-ack", newEv + " new index event(s) to seq " + evMax, () => {});

// cursors + lifetime count
state.roomLines = lines.length;
state.eventSeq = evMax;
state.fires += fires.length;
state.lastRun = new Date().toISOString();
writeFileSync(STATE, JSON.stringify(state, null, 1));

if (fires.length) appendFileSync(LOG, JSON.stringify({ ts: state.lastRun, fires }) + "\n");
console.log("ponytail: " + fires.length + " fire(s) this drain; lifetime " + state.fires);
for (const f of fires) console.log(" - " + f.organ + ": " + f.detail + " " + (f.ok ? "ok" : "FAIL " + (f.err || "")));
