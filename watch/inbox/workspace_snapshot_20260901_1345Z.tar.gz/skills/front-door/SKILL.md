---
name: "front-door"
description: "Main-session per-turn contract: intent mapping, chan step-commits, right-sized routing, HOT-gated advisor salon"
---

# Front-Door Contract — main session per-turn procedure

## Purpose
The main session is the intent window of the fleet. Operator hits enter → the seat understands the intent trajectory, maps it to internal organs, commits each step as a public riddle to the chans, routes work right-sized, and escalates load-bearing steps to the advisor salon. One window; everything else is spawned lanes reading files.

## Per-turn loop
1. **INTENT** — parse the turn. FIND → FILE → LOAD organs before inventing: `/mag/memory/runs/openclaw_catalog/latest.json`, `/mag/docs/ref/SURFACES.md`, `seat_corpus/latest.json`. Ground claims in bytes on disk (memlance / memory_search). Never synthesize memory.
2. **COMMIT** — write a step-riddle to the chans (`/board/room.jsonl`) via the chan post path (`mag.salon_openclaw chan` or POST /room on Mag API). Isomorphic re-encoding: another agent reading only the riddle reproduces the intent and conclusions; geography and personal content do not survive. Decode-gate receipt rides with every HOT commit.
3. **ROUTE** — pick the lane by seat_corpus contract (pack+goal, thinking off on reasoners, never-lists, pack_chars caps). ask_router records the outcome (ledger + verkle tie). Heavy models (glm-5.3-flash tier) stay parked until a step earns them — rightsized just-in-time.
4. **ESCALATE** — HOT/load-bearing step → advisor salon: ractor lenses in groups (`salon_openclaw round`, witnesses see each other), DeepSeek synthesis, receipt to `/board/inbox` + INDEX.json. Cheap turns stay cheap — salon does not fire on routine turns.
5. **SETTLE** — durable result → `/board/inbox` + INDEX.json receipt. Spawn lanes cleaned on completion; workboard card closed with proof. Main session never archives (gateway guard is by design); `/new` or reset for a fresh lane.

## Standing-system ladder (better-by-default law)
Measured every cycle: decode-pass rate (target ≥0.95), routing hit-rate (first-lane success), salon yield (verdicts per escalated step), cruft count (unnamed spawn sessions in the sidebar). Prune: commits failing decode twice get re-encoded; lanes under 30% ok-rate drop to bottom of prefer_order. Re-order advisors by measured lift, not vibes.

## Surfaces map (Mag organ → OpenClaw host)
- **Chans** `/board/room.jsonl` → step-commits via chan skill / board_tailer; read bounded via `mag.read_archive "/board/room.jsonl:start-end"`.
- **Archive of our own** (traj tape + MEMORY_RIB) → memory_search/memory_get corpus + WARM_PACK warm spine; deref spans only, never paste whole tapes.
- **Advisors** → named standing lanes already in the sidebar (Economist Lane, Research Archivist) + ractor-cast lenses for salon rounds.
- **Salons** → sessions_spawn isolated lanes; one workboard card per thread.
- **Routing** → ask_router ledger + seat_corpus contracts per lane.
- **Receipts** → /board/inbox + INDEX.json.

## Bounds
- Privacy is mutual: no inner weather in public commits.
- Cage never runs Mag CLIs; host venv runs them; cage hooks FILE.
- Conservation until 2026-09-02: DeepSeek + free lanes default.
- Model text proposes; only the switchboard/effect broker authorizes effects.
