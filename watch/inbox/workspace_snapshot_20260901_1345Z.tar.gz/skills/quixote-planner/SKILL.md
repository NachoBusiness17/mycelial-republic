---
name: "quixote-planner"
description: "Planning doctrine: one plan-owner, plan-as-data on Workboard, basecamp one-step climbs, reconciliation from outcome memory — no new planner code."
when_to_use: Multi-step goals, "plan this", experiment sequences (lane probes, deploys, windows), any moment a queue is being built or re-ordered, long-running worker runs needing mid-run correction.
---

# QUIXOTE-PLANNER — the planning window doctrine

## Law (4 lines)
1. Plan is DATA, not vibes: every plan lives on the Workboard (cards = steps) with acceptance criteria per card.
2. ONE objective owner: the planning seat re-orders; workers execute; the elder audits; nobody conducts twice.
3. One-step climbs: sequence = basecamp's method — one bounded step, receipt, remap. Never a 10-step novel.
4. Plans get reconciled from measured outcomes, not intentions — BETWEEN cards (reconciliation) and DURING a card (live steering, PILOT pattern, arXiv:2608.26530).

## The cycle
1. **SPEC**: reduce the goal to Workboard cards. Each card: title, acceptance test, named organs/lane, expected receipt. Card that can't name its acceptance test isn't planned yet.
2. **MEASURE THE GROUND**: host → `python -m mag.atlas build` (receipts-first map) + `python -m mag.elder audit` (gap rank). Cage → read last receipts + memory_search. A plan built without the map plans ghosts.
3. **SEQUENCE**: order cards dependency-first; cheapest-lane-first inside equal dependency depth; conservation law overrides (free lanes before paid, window rules first).
4. **EXECUTE**: one card at a time through the archivist/dispatch machinery (existing: sessions_spawn, seat_dispatch host-side, workboard_claim cage-side).
5. **LIVE STEER (in-card, PILOT pattern)**: a supervisor view exists over long worker runs — Mag's `python -m mag.grok_steer` (overlay: sit over a seat, steer, don't patch-loop) host-side; cage-side, the planner may send a mid-run correction via sessions_send. Steering decisions get logged to the card (steered / aborted / let-run + why). Abort conserves the worker's receipts: kill the process, keep the worktree, replay from the last good gate.
6. **LIVE DISTILL (in-card)**: lessons observed mid-run get written into the card's worker_log and receipt WHILE the run continues — procedures that worked, failure modes that appeared. A lesson that waits for run-end is a changelog, not self-improvement.
7. **RECONCILE (between cards)**: after each card, ask — did the receipt change what the NEXT card should be? If yes, re-order or delete cards BEFORE running them. Log the re-order in the plan card. This is outcome-memory → plan reconciliation, procedural, no code.
8. **REMUP**: `python -m mag.basecamp [goal]` host-side or elder audit — confirm the ground after each climb step.

## Division of labor
- Mag host organs (atlas/elder/basecamp): deterministic measurement — map, gaps, next-step. They never command.
- OpenClaw Workboard: the plan's body (cards, dependencies, labels, acceptance criteria).
- Archivist: the research lane feeding the plan (facts, lane maps, verdicts).
- Workers/subagents: execution hands; report receipts, never re-plan.
- Operator: constitutional root; confirm gate on spend/irreversible steps; steer/abort requests on long runs flow through the operator when the run is theirs.

## Anti-patterns
- No second conductor: elder audits, basecamp climbs, planner sequences — none grants permissions.
- No plan without a remap trigger: a plan that can't be re-ordered by evidence is a novel.
- No scanned-only spine trust: atlas/elder/basecamp are real but un-crowned (family:"scanned") — treat their output as measurement, verify crowning before load-bearing routing.
- No post-hoc-only learning: a run that ends without distilling its lessons mid-flight wasted its supervision (PILOT's core result: live beats after, +14.6pp, −47% tokens).
- Planning seats do not research (that's the archivist) and research seats do not re-order the plan.

## Filed 2026-08-31 · receipts: planning_spine_research + inbox_pilot_liveloop (ARCHIVIST_RECEIPTS.jsonl) · evidence: staging/PLANNING_ORGANS_20260831.md, /mag/mag/{atlas,elder,basecamp}.py, arXiv:2608.26530
