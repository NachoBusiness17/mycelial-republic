# PLANNING ORGANS — catalog sweep 2026-08-31

Full sweep artifact by GOPHER worker (planning_organs_sweep). All quotes verbatim from:
- A = /mag/memory/runs/openclaw_catalog/fabric.json (17 crown nodes)
- B = /mag/memory/runs/openclaw_catalog/latest.json scanned_extra (608 CLIs)

(Contents copied from worker output staging file; see receipt planning_spine_research.)

## Key rows
- seat_dispatch (B): task interface, lanes openclaw/autoclaw/opencode
- ask_router (B): "the missing controller: outcome-ledger-driven ask routing"
- fuel_feed (A ribs): consumes work_contract + lane_cadence
- governor_autorun (B): "fill queue, plan, route, execute"
- self_drive_cadence (B), north_star (B), flock_scheduler (B), job_floor (B), queue_ops/learn/rightsize (B), guard_registry (B), session_overseer (B)
- atlas/basecamp/elder: ABSENT from fabric crown (all three false), PRESENT in scanned_extra; corroborated by elder_brief.md + elder_missing.json in same dir

## Verdict (worker)
1. Spine exists, distributed, bottom-heavy.
2. Crown gap: planning organs all family:"scanned" (un-ribbed).
3. No objective owner reconciles the plan itself.
4. compute_reconcile/queue_rightsize reconcile cost/tier only; guard_registry reconciles fixes.
5. Biggest gap: outcome-memory → plan reconciliation (organs read ledgers, nothing re-plans build order from measured results).
