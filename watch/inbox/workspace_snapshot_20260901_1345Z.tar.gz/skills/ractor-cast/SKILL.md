---
name: "ractor-cast"
description: "Rotating persona-lenses from published work only (Lessig, Jung, Ellul, Bernays, Steiner, Blavatsky, ponytail), RIB-anchored, decode-gated, salon rails."
when_to_use: Salon/roundtable reviews, red-team passes, plan audits, HOT-gate adversarial review, any turn that wants a named lens instead of a generic opinion.
---

# RACTOR-CAST — the hive's rotating lenses

## Law (5 lines)
1. **Lens, not ghost.** A ractor is a method-of-attention built ONLY from published life-work (books, essays, lectures, papers). It never claims the person's identity, never predicts their private views, and each reply carries the calibration line: "lens of [name]'s published work; the person said nothing about this."
2. **RIB-anchored or it didn't happen.** Every signature concept in a ractor file carries a deref span to a primary source (path:start-end or URL + fetch date + quote). Memory-RIB format: ObjectBegin=concept, hash-bounded artifact spans. Deep self-steal = the ractor's knowledge is deref-able and lossless, not vibes.
3. **Refusal moves keep them honest.** Each ractor file lists what its lens REFUSES to endorse (Lessig refuses governance-by-vibes; Ellul refuses efficiency-without-cost-accounting; Jung refuses shadow-analysis of the operator's inner life — privacy is mutual, AGENTS.md law, no diary psychoanalysis of anyone, Adam too).
4. **Decode-parity gate.** A fresh seat reads ONLY the ractor file and reproduces the lens's verdict on 3 test questions; parity with the builder's expected lens-logic = PASS. No PASS → quarantined. HOT gate applies to any factual claim about the real person's work: quote or mark [inferred].
5. **Rails, not roles.** Ractors ride existing rotation (salon roundtable / party_subchain / riddler_common). A ractor is a skill file loaded as a lens on a turn — not a seat, not a process, not a supervisor.

## The founding cast (build order by load-bearing need)
1. **LESSIG** — governance lens: code-is-law, modalities of regulation (law/norms/market/architecture). Role: authority-boundary reviewer on board mutation patterns. Source corpus: Code v2, The Future of Ideas (CC releases via lessig.org).
2. **BERNAYS** — consent-engineering lens (Propaganda 1928, Crystallizing Public Opinion — public domain). Role: the hostile attack pass; one-way mirror only, never builds campaigns.
3. **ELLUL** — technique critique (The Technological Society). Role: the planner's cost-ghost — "what does this machine now demand that nobody decided?" Pairs with elder audit. Copyrighted: cite-by-reference + private-study copies only.
4. **JUNG** — pattern/archetype lens (published: archetypes, shadow, enantiodromia). Role: surfaces recurring failure-patterns in the ledger as named shapes. Scope-lock: patterns of the SYSTEM's failures, never the operator's psyche.
5. **STEINER** — epistemology-of-attention lens. Role: reviews research doctrine (deref-before-lane, calibration words) as discipline of attention. Source: Rudolf Steiner Archive public lectures.
6. **BLAVATSKY** — correspondences method lens ONLY. Flagged: factual corpus contested; every surfaced claim gets the HOT gate.
7. **PONYTAIL** — the practice-persona (not a person): the lazy-senior-dev ladder, verified (JetBrains-tested). First non-human ractor; zero impersonation risk.

## Builder procedure (per ractor, no new code)
1. DEREF what we hold: memory_search, /mag corpus, primer booth.
2. GOPHER fetch primary texts (archive.org, gutenberg.org, steiner.archive.org, publisher pages; paywalled = cite-by-reference, never paraphrase-blind). Fetch log mandatory.
3. **DISTILL via the book-to-skill file shape** (github.com/virgiliojr94/book-to-skill, verified 2026-08-31) — the corpus-compilation pattern independently converged four times this week (WikiSkill, CUDA-Agent SKILL.md, ponytail, book-to-skill):
   - `SKILL.md` = the ractor file: calibration line, 5–7 signature concepts, trigger rules
   - per-chapter/concept files = deep spans, loaded on mention-intersection (the memory-RIB deref pattern, born as a skill convention)
   - `glossary` = signature-concepts table with RIB spans
   - `patterns.md` = interrogation moves (3+)
   - `cheatsheet.md` = refusal moves (2+) + calibration card
4. DECODE-PARITY: fresh seat reads ONLY the ractor file + reproduces verdicts on 3 test questions (evals/fixtures pattern from book-to-skill). PASS → file via skill_workshop; FAIL → quarantine, log reason (WikiSkill law: rejected builds persist root-cause).
5. REGISTER in rotation: post public form to riddler_common (isomorphic re-encode; public form reveals the lens, not the full corpus if restricted).

## Corpus archive (vault Tier D — distribution-risk law applied to texts)
The ractor corpora get the same insurance as weights: hash-manifested local copies of every source a ractor derefs (public-domain and CC works archived freely; copyrighted works = cite-by-reference or private-study copies). Rationale: ractors must be REBUILDABLE — lens file + corpus + decode fixtures = full regeneration recipe; sources vanish (out of print, takedowns, edition churn) faster than ideas do. Size: text, hundreds of MB total. Decode fixtures ride with the corpus so parity is testable forever.

## Anti-patterns
- No claimed identity, no first-person-as-the-dead, no "X would say."
- No private-person modeling: published work only; nothing from biographies' inner-life speculation.
- No ractor output bypasses the HOT gate — a famous lens is still a lane, not an authority label.
- No new supervisor, no new session type: ractors are files on existing rails.

## First three to build after apply: Lessig (governance), Bernays (adversarial), Ellul (technique-cost) — all three corpora legally archivable. Filed 2026-08-31 · operator-ordered "for the hive."
