# ARCHIVIST — Research-Agent Skill Design Brief
> Built ONLY from existing Mag machinery (self-steal, no new infra, no new code).
> Every command below is copy-pasted verbatim from `/mag/memory/runs/openclaw_catalog/latest.json` or `fabric.json`; each row cites its file.
> Context laws (GOPHER, HOT, seat-corpus, Riddler, Memory-RIB) are assumed from the task brief; not re-read here.

---

## Section A — Inventory of existing research organs

| Organ | Exact command (source) | Family / cost lane | Sub-organs / output format |
|---|---|---|---|
| **fuel_feed** (free-lane mill) | `python -m mag.fuel_feed` [latest.json scanned] · `python -m mag.fuel_feed status` [latest.json crown, fabric.json] | mill / **free rotation** (groq dual-key, ox, nvidia, openrouter×2, cerebras, ollama) | subtools: `status, run, profile, curve, clarify, pending, main` [fabric.json]. Ledger: `fuel_feed lane_profile.jsonl` per-lane ok-rates; logs `provider_usage.jsonl` |
| **ghost_memlance** | `python -m mag.ghost_memlance select --goal GOAL` [latest.json crown, fabric.json] · `python -m mag.ghost_memlance` [latest.json scanned] | lance / memory selector | subtools: `index, select, trace_state, verify, self_check, select_wave, main` [fabric.json]. "Select grounded states, never synthesize." [latest.json crown] → returns grounded MEMORY states; no synthesis |
| **seat_corpus** | `python -m mag.seat_corpus show groq` [latest.json crown, fabric.json] · `python -m mag.seat_corpus` [latest.json scanned] | hypervisor / "what to send each lane" | subtools: `compile_corpus, show, main` [fabric.json]. Compiles providers.yaml send laws (thinking, cache, jail) [latest.json scanned origin] → per-lane send corpus |
| **read_archive** | `python -m mag.read_archive` [latest.json scanned] | archive dereference / RIB | "Lossless, bounded archive dereference for the RIB. Spans are one-based inclusive JSONL line ranges" [latest.json scanned origin] → returns exact JSONL lines |
| **research_fold** | `python -m mag.research_fold` [latest.json scanned] | research-pack auto-fold → case law | "Passive research-pack auto-fold — turn landed research answers into case law" [latest.json scanned origin] |
| **steal_pack** | `python -m mag.steal_pack` [latest.json scanned] | file STEAL outputs into swarm research-pack pipeline | "Every external-steal / deep-research / distillation … (queue/handoff/STEAL_*…)" [latest.json scanned origin] |
| **arxiv_mine** | `python -m mag.arxiv_mine` [latest.json scanned] | tier-A research source | "mine arXiv the same way we steal … (configs/improve.yaml…)" [latest.json scanned origin] |
| **perplexity_research** | `python -m mag.perplexity_research` [latest.json scanned] | deep web research w/ citations | "real-time web search + cited sources — the ‘deep research’… folded into the corpus" [latest.json scanned origin] |
| **corpus_expand / corpus_ingest / corpus_wave** | `python -m mag.corpus_expand` · `python -m mag.corpus_ingest` · `python -m mag.corpus_wave` [latest.json scanned] | corpus growth | "expand the research corpus for FREE into our growing library" [origin corpus_expand] |
| **stateless_research / socratic_research / deep_research_moonshot** | `python -m mag.stateless_research` · `python -m mag.socratic_research` · `python -m mag.deep_research_moonshot` [latest.json scanned] | stateless research shells | (steal-compatible one-shot research modes; no origin text in catalog) |
| **surface_steal** | `python -m mag.surface_steal` [latest.json scanned] | "on every ask, surface lingering threads from our OWN corpus" | "every time i ask you a question you do a self steal" [origin] |

**Fabric import-ribs that involve research (Section A/B context):**
- `fuel -> work_contract`, `fuel -> lane_cadence` [fabric.json edges] → fuel_feed consumes work_contract + lane_cadence (the mill's contract/cadence ribs).
- `corpus` (seat_corpus) `imports_mag: []` [fabric.json] → stands alone; feeds lanes, imports nothing.
- `memlance` (ghost_memlance) `imports_mag: []` [fabric.json] → stands alone; AND is **consumed by `dnd`** (`dnd -> ghost_memlance` edge). So memlance is a leaf selector consumed elsewhere.
- `fuel_feed`/`read_archive`/`research_fold`/`steal_pack`/corpus/arxiv/perplexity are **NOT crown nodes** → they have **no fabric edges** in the 17-node topology (only crown organs get rib edges). Archivist treats them as composable leaves we call by subprocess, same as `ask_router`'s stated contract ("Composes existing organs by subprocess, never imports" [latest.json ask_router origin]).

---

## Section B — Gaps an archivist skill must close (WITHOUT new code)

1. **No standing "which organ for which question" router.** The catalog lists the tools; nothing in the files encodes *when* to call `ghost_memlance` vs `seat_corpus` vs `perplexity_research` vs `arxiv_mine` per question type. `ask_router` exists but is a thin subprocess composer — it doesn't carry the archivist's semantics.
2. **No receipt format for web-research sessions.** `perplexity_research` returns citations; `research_fold` folds landed answers into case law; but no schema persists "who ran what, which lanes, which sources, which claims shipped." Reviews need a per-session receipt.
3. **No HOT-claim → 3/4-lane gate is wired to research output.** HOT law demands ≥3/4 lane consensus or a primary-source check before a claim reaches the operator. Nothing in the catalog attaches a verification gate to `perplexity_research`/`arxiv_mine` output automatically.
4. **No "when to convert a one-shot answer into a pack" rule (fireball law).** `steal_pack` can file an answer into the research-pack pipeline, but nothing decides *when* a one-shot answer is durable enough to promote.
5. **No lane-contract binding for research bursts.** `fuel_feed` uses `work_contract`+`lane_cadence` internally; the archivist has no stated rule for which lane a research burst claims first (free lanes first, per seat-corpus law).
6. **No "terminology identity" preflight.** Riddler law (isomorphic re-encode + decode-test) and Memory-RIB (concepts→RIB map, deref on mention-intersection) imply a question should be reduced to RIB-intersection spans and dereferenced via `read_archive` before spending lanes; no procedure states "deref first, lane second."
7. **`atlas`, `basecamp`, `elder` are NOT real organs.** The task asked about them; verification shows they appear **nowhere** in the catalog (`atlas`/`basecamp`: 0 hits in both files; `Elder` is only a k8s reference "Ben-The-Elder lane" in `verify_gate`'s origin, not an organ). Do not invent commands for them. (Honesty: these may be conversational nicknames, but there is no CLI to steal.)

---

## Section C — Recommended archivist skill skeleton (~120 lines max, no invented CLIs)

```markdown
# ARCHIVIST skill — self-steal research agent

## Trigger rules
- Fire when the operator asks a researchable question, cites "research"/"archive"/"deep dive",
  or a seat surfaces a lingering thread (surface_steal instinct).
- Do NOT fire for game/chess/dnd turns, fleet render requests, or pure coding sessions
  (those have dedicated organs).
- First action on any trigger: check SURFACES.md (registry) so we don't rebuild a listed row.

## Decision tree — question → which organ (each command copy-pasted from latest.json / fabric.json)
Q is "do we already hold this?"
  YES grounded -> python -m mag.ghost_memlance select --goal "Q"         # memlance (grounded states, never synthesize)
  Need raw lines  -> python -m mag.read_archive                           # deref RIB span (path:start-end) from mention-intersection
  Need a lane fmt -> python -m mag.seat_corpus show <lane>               # per-lane send corpus (e.g. show groq)
Q is NEW web research (citations wanted)?
  -> python -m mag.perplexity_research                                    # cited web research -> corpus
Q is NEW paper mining?
  -> python -m mag.arxiv_mine                                             # tier-A source
Q is a free-lane burst to run the above cheaply?
  -> python -m mag.fuel_feed run   (status: python -m mag.fuel_feed status)
Q is a one-shot/steal the operator wants banked?
  -> python -m mag.steal_pack                                             # file into research-pack pipeline
Q is a just-landed set of answers ready to become case law?
  -> python -m mag.research_fold                                          # auto-fold answers -> case law
Q is "what did our OWN corpus already say"?
  -> python -m mag.surface_steal                                          # self-steal lingering threads

## Ordering (rightsized)
1. RIB-first: reduce Q to concept->RIB map; find mention-intersection spans.
2. Deref via python -m mag.read_archive (span = path:start-end, 1-based inclusive JSONL).
3. If grounded state satisfies Q -> python -m mag.ghost_memlance select --goal Q; STOP, no lanes spent.
4. Else pick a web/paper organ (perplexity_research / arxiv_mine).
5. Run under free-lane mill: python -m mag.fuel_feed (free rotation first; work_contract + lane_cadence ribs).

## Receipt format (persist per web-research session)
- question / reduced RIB term
- organ run (cmd verbatim above) + lane used
- sources + citations (perplexity_research returns these)
- claims extracted
- HOT-gate status (below)
- fold decision (below)

## HOT-claim gate (operator trust wall)
- Any claim destined for the operator: route through >=3/4 free lanes via
    python -m mag.fuel_feed run    then   python -m mag.verkle_lance self_check  (chain-verify the line, if signed)
  — OR, if <3/4 consensus, do a primary-source check per GOPHER (mechanical fetch/grep/verify
  via disposable spawns) before the claim ships. Never ship a contested HOT claim unpacked.

## Lane contract
- Free lanes first (groq/ox/nvidia/openrouter×2/cerebras/ollama via fuel_feed).
- Paid lanes z_ai/z_ai4/z_ai2/z_ai3 only when free lanes can't satisfy or cache economics require.
- Respect fuel_feed cadence ledger; do not tight-loop a lane (429/Retry-After honored).

## Conversion rule (fireball law — one-shot -> pack)
- Promote a ONE-SHOT answer to a PACK (via python -m mag.steal_pack) when it is:
  (a) verified by the HOT gate, AND
  (b) the product is durable/reusable (not a throwaway), AND
  (c) fireball (a tool) already exists OR the answer becomes load-bearing for a future query.
- When several landed answers from one thread all pass -> python -m mag.research_fold
  to convert them into case law automatically.
- Nothing durable + verified stays a one-shot: it must be promoted or archived; no orphan threads.

## Anti-patterns (do not do)
- Do NOT invent commands: every cmd above is verbatim from latest.json / fabric.json.
- atlas/basecamp/elder are NOT catalog organs — do not invoke them.
- No new Mag code, no new cron, no new supervisor. Archivist is a SKILL that composes
  existing CLIs by subprocess, exactly as ask_router's contract states.
- Do not synthesize memlance output beyond grounded states ("never synthesize").
```

---
*Sources: `/mag/memory/runs/openclaw_catalog/latest.json`, `/mag/memory/runs/openclaw_catalog/fabric.json`, `/mag/docs/ref/SURFACES.md`. All commands extracted verbatim; no invented CLIs.*
