# Bridge Operator Inbox — MAG Deferred Proposal Interface

## Where proposals appear

When the switchboard `grant()` encounters an effect listed in `policy.require_confirmation`
(default: `fs_write`, `lane_spawn`, `model_call`), the proposal is **not** immediately
authorized. Instead:

1. The proposal status becomes `DEFERRED`.
2. It is appended to `bridge/operator_inbox.jsonl`.
3. A `confirm_by` timestamp is set (default: 300 seconds from deferral).

## How to view pending proposals

```bash
# Show the last 10 deferred items
python -m mag.harness status

# Or read the raw inbox
cat bridge/operator_inbox.jsonl | tail -n 10
```

## How to confirm or deny

```bash
# Confirm a deferred proposal (upgrade DEFERRED → AUTHORIZED)
python -m mag.switchboard confirm <event_id>

# Deny a deferred proposal (upgrade DEFERRED → DENIED)
python -m mag.switchboard deny <event_id>
```

The `confirm` / `deny` commands read the operator inbox, locate the proposal by
`event_id`, update its status, and append the decision to the switchboard trail.

## What happens if the operator does not respond

- At `confirm_by` time, any proposal still `DEFERRED` is automatically treated as
  `DENIED` by the next `run_once()` or `expire()` pass.
- No effect is executed without explicit confirmation.
- The auto-deny is recorded in `memory/runs/switchboard/trail.jsonl` with
  reason `"auto-deny: confirmation window elapsed"`.

## Response time

- **Default confirmation window:** 300 seconds (5 minutes).
- **Configurable via:** `python -m mag.policy_engine set confirmation_ttl <seconds>`
- The operator may extend the window by confirming with a longer TTL on a
  per-proposal basis (not yet implemented; use policy-wide setting for now).

## Security properties

- The inbox is append-only. No agent can modify or delete a deferred proposal.
- Only the operator (or a process with operator-equivalent authority) can call
  `confirm`/`deny`.
- A confirmed proposal still requires the effect broker to validate the
  authority before execution; confirmation only changes status, it does not
  bypass checks.
- If the inbox file is corrupted or deleted, pending proposals are lost — they
  will auto-deny. No unauthorized execution can occur.

## Operator workflow summary

1. Run `python -m mag.harness status` to see deferred count.
2. Read `bridge/operator_inbox.jsonl` for details.
3. Run `python -m mag.switchboard confirm <event_id>` to approve.
4. The next `harness run_once` will pick up the AUTHORIZED proposal and execute.

---
*File: BRIDGE_OPERATOR_INBOX.md · Track B/C of Self Steal Master Spec*
