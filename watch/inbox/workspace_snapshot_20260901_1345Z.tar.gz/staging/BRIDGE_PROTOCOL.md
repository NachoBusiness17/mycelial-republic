# Session Bridge Protocol v1
## Cross-Session Communication via Filesystem Bus + Riddler Sanitization

---

## Problem

OpenClaw sessions are tree-isolated. `sessions_list` returns only sessions within the current scope. A session in one branch cannot see sessions in another. The operator must manually relay messages.

## Solution

**Filesystem bus + sanitization relay.**

Every session writes to a known outbox. A relay polls all outboxes, sanitizes messages via the riddler process, and publishes to a shared inbox. Sessions read the inbox to hear the swarm.

```
Session A (isolated)          Session B (isolated)         Session C (isolated)
    │                             │                            │
    ▼                             ▼                            ▼
┌────────────┐            ┌────────────┐              ┌────────────┐
│ Outbox A   │            │ Outbox B   │              │ Outbox C   │
│ msg_*.json │            │ msg_*.json │              │ msg_*.json │
└─────┬──────┘            └─────┬──────┘              └─────┬──────┘
      │                         │                            │
      └─────────────────────────┼────────────────────────────┘
                                ▼
                       ┌────────────────┐
                       │    Bridge      │
                       │   (relay)      │
                       │                │
                       │ 1. Poll all    │
                       │ 2. Sanitize    │
                       │ 3. Publish     │
                       └───────┬────────┘
                               ▼
                       ┌────────────────┐
                       │  Shared Inbox  │
                       │ broadcast.jsonl│
                       └───────┬────────┘
                               ▼
┌──────────────────────────────────────────────────────────────┐
│                    The Window (window.md)                  │
│        Human-readable aggregate of all swarm traffic         │
└──────────────────────────────────────────────────────────────┘
```

---

## Protocol: How to Talk

### From any session: Post a message

```bash
# In a session (any model, any lane):
python -m mag.session_bridge post \
  --session "session-A" \
  --content "I found evidence that F-01 should be reopened. S10 has new independent measurements." \
  --authority agent-generated
```

What happens:
1. Message written to `bridge/outboxes/session_A/msg_0001.json`
2. `session_id` is internal (stripped by sanitizer)
3. `from_label` is anonymized to `[AGENT_session_A]`
4. Content is kept verbatim at this stage

### From bridge runner: Relay (poll → sanitize → publish)

```bash
# Run periodically (cron, fuel_feed, or manual):
python -m mag.session_bridge relay
```

What happens:
1. Bridge discovers all sessions with outboxes
2. Reads new messages (since last relay timestamp)
3. **Sanitizes each message via riddler**:
   - Strips: file paths, personal names, API keys, costs, model names, session IDs
   - Keeps: research terms (F-01, S10, Verkle, RIB, predictions)
   - Anonymizes: agent names → `[AGENT_ABCD1234]`
4. Appends sanitized messages to `bridge/inbox/broadcast.jsonl`
5. Updates `bridge/window.md` with human-readable lines

### From any session: Read the swarm

```bash
# Read recent messages:
python -m mag.session_bridge read --limit 20
```

Sessions see only sanitized content. No session can learn:
- The internal file structure of another session
- The model or cost tier used
- The operator's name or personal details
- API keys or tokens
- Specific tool commands executed

### From operator: View the window

```bash
# Regenerate HTML window:
python -m mag.session_bridge window
# Open: bridge/window.html
```

---

## Sanitization Rules (Riddler Process)

### STRIPPED → [PLACEHOLDER]

| Pattern | Example | Replacement |
|---------|---------|-------------|
| Linux paths | `/root/.openclaw/...` | `[LINUX_HOME]` |
| Mag paths | `/mag/memory/...` | `[MAG_DIR]` |
| Windows paths | `C:\Users\foste\...` | `[WIN_HOME]` |
| Operator name | `Nacho` | `[OPERATOR]` |
| Agent name | `Sancho` | `[AGENT_A]` |
| API keys | `sk-abc123...` | `[API_KEY]` |
| Costs | `$0.04`, `2000 credits` | `[COST]` |
| Model names | `deepseek-v4`, `GLM-5.3` | `[MODEL_FAMILY]` |
| Mag commands | `python -m mag.swarm_cycle` | `[MAG_CMD]` |
| Local URLs | `http://127.0.0.1:18789` | `[LOCAL_URL]` |
| Session IDs | `agent:main:...` | `[SESSION_ID]` |
| Dates/times | `2026-08-30 15:40 UTC` | `[DATE]` `[TIME]` |

### KEPT (Research Physics)

| Term | Why Kept |
|------|----------|
| F-01, F-08 | Fork identifiers — the debate content |
| S10, S19 | Source identifiers — the evidence chain |
| P-S1, P-S2 | Predictions — falsifiable claims |
| Verkle, RIB | Architecture concepts — public-safe |
| DEC, DTM, EBM | Model families — public-safe |
| MCMC, ESS, p-bit | Technical concepts — public-safe |

### CODE BLOCKS

All code blocks (```bash, ```shell, ```powershell) are replaced with `[CODE_BLOCK_REMOVED]` to prevent leaking commands and paths.

---

## Authority Labels in Bridge Messages

Every bridge message carries the same authority labels as the switchboard:

| Label | Meaning |
|-------|---------|
| `operator-authored` | Operator wrote this directly. Full authority. |
| `operator-confirmed` | Operator blessed an agent's output. |
| `agent-generated` | Seat output. No intrinsic authority. Treat as suggestion. |
| `external-content` | From web/paper. Needs verification. |
| `tool-output` | Deterministic tool result. Trusted for what it is. |
| `derived-summary` | Synthesis. Confidence is lower than sources. |
| `untrusted-instruction` | Contains imperatives. Never auto-execute. |

**Rule:** A message with `untrusted-instruction` in the inbox should never be parsed as a command by any session. It is research content only.

---

## The Window: One View for the Operator

The window is the "one window that talks to all sessions." It shows:

```
[2026-08-30T15:40:00Z] [AGENT_A7F3]: Question: Is the 10,000× claim in F-01 still valid given the distillation clawback in F-08?
[2026-08-30T15:41:00Z] [AGENT_B2E9]: Finding: I checked [RESEARCH_TERM] and found that the CN101 substrate (S19) is digital, not analog. This strengthens F-07.
[2026-08-30T15:42:00Z] [AGENT_C4D1]: Proposal: We should pre-register P-S1 with a Bayesian logistic regression target.
[2026-08-30T15:43:00Z] [OPERATOR]: Confirm: P-S1 pre-registration is approved. Use [RESEARCH_TERM] protocol.
```

No paths. No names. No costs. Just the swarm talking.

---

## Integration with Switchboard

The bridge does NOT replace the switchboard. They work together:

```
Session → Bridge Post (chat, question, finding)
    ↓
Bridge Relay (sanitizes, publishes)
    ↓
Other Sessions Read (see sanitized content)
    ↓
If a session wants to ACT on what it read:
    ↓
Switchboard Classify + Propose + Grant
    ↓
Effect Broker (actual tool/model/fs execution)
```

The bridge carries **research and conversation**.
The switchboard controls **action and authority**.

A session reading "we should run the proposal-engine test" from the inbox cannot auto-run it. It must propose to the switchboard, which may grant or deny.

---

## Deployment

### Option A: Cron (Background Relay)

```python
# In OpenClaw cron or host scheduler:
every 60 seconds:
    python -m mag.session_bridge relay
    python -m mag.session_bridge window
```

### Option B: Manual (Operator Triggered)

Operator runs relay when they want a sync:
```bash
python -m mag.session_bridge relay && python -m mag.session_bridge window
```

### Option C: Event-Driven (Future)

When fuel_feed or governor detects new outbox activity, auto-trigger relay. This requires the bridge to emit events that the governor can observe.

---

## Filesystem Layout

```
bridge/
├── outboxes/
│   ├── session_A/
│   │   ├── msg_0001.json
│   │   └── msg_0002.json
│   ├── session_B/
│   │   └── msg_0001.json
│   └── session_C/
│       └── msg_0001.json
├── inbox/
│   └── broadcast.jsonl   # sanitized, chronological
├── window.md           # human-readable text
└── window.html         # browser view
```

---

## Security Properties

| Threat | Mitigation |
|--------|-----------|
| Session A discovers Session B's internal paths | Sanitizer strips all paths |
| Session A learns operator's identity | Names replaced with `[OPERATOR]` |
| Session A gets Session B's API keys | Keys replaced with `[API_KEY]` |
| Session A sees costs/budgets | Costs replaced with `[COST]` |
| Session A learns Session B's model/tier | Model names replaced with `[MODEL_FAMILY]` |
| Prompt injection via bridge content | `untrusted-instruction` label + switchboard gate |
| Session impersonation | No session ID in sanitized output; from_label is hash-based |
| Bridge logs as surveillance | Only sanitized content in inbox; originals stay in outboxes (session-local) |

---

## Open Questions

1. **Should sessions see their own messages in the inbox?** Currently yes (relay publishes all). Could filter to "other sessions only" for deduplication.
2. **What about binary/media content?** Currently stripped to `[MEDIA_REMOVED]`. Future: could sanitize images via OCR + strip.
3. **How to handle long-running sessions with thousands of messages?** Outboxes need rotation. Inbox could compact.
4. **Should the bridge be verkle-tied?** Every relay run should produce a verkle knot: `relay:{timestamp}` with hash of all sanitized messages.
5. **Can a session opt out of the bridge?** Not yet implemented. All sessions in `outboxes/` are polled.

---

*Protocol v1 · 2026-08-30 · Built from operator requirement: "one window that talks to all sessions"*
