# CREATIVE CORPUS → SOCRATIC PLAY DESIGN
**Operator order 23:37Z · 2026-08-31 · inventory + play format + engine hookup**

---

## A — CORPUS INVENTORY (read-only sweep)

**Rashomon / narrative core**
- `memory/narrative_corpus/INDEX.md` — law gates (multi-perspective seeds OK, single-truth propaganda not), waves, "salon multi-seat vs engine_truth" product idea, train labels (perspective/unreliable/hub_return/threshold). **= the charter for this design.**
- `memory/narrative_corpus/rashomon/tavern_bar_fight_party.v1.md` — THE template: one event (`tavern_bar_fight_party`), 5 unreliable voices + short boring `engine_truth` ledger (mug, chair, HP, flags). Craft rails: unreliable=character, engine_truth=Sancho, Le Guin-clean. **= the socratic seed.**
- `NARRATIVE law / waves` catalog-only Le Guin/Jung/Campbell/Rashomon = inspiration tags only.

**Rib-bus archetypes/game (JSON rib invariants — T2 doctrine)**
- `game.json` (3 ribs: gear→RIB; game-IS-hologram-rooms-are-coding; game-field magnetic-field swarm).
- `emergent-play.json` (patch law: unknown verbs collide w/ room bytes + verkle trace; never dump session_ids into narrate; hearth=Calcifer; babel fish=fish_ear).
- `archetypes-esoteric.json` (12 archetypes × Jung + Manly P. Hall esoteric correspondence — Hermes/Logos/Fool/coniunctio; ground any character against shadow AND symbol). **= character-depth palette.**
- `doctrine.json` (19+ instances: foundational verkle field; table-merge; game-field instance; operator-bus LAW incl. "models interchangeable; chain is ground truth" — defines engine/seat split).

**Game mechanics / character / D&D tools (`docs/ref/`)**
- `GAME_THEORY_PLAY_MAP.md` — **the design spine**: engine=game form/referee, roles=strategy sets, packs=info structure, REFEREE BEFORE NARRATIVE, info-sets by role, equilibria not vibes, generalization (B2) over 5e cosplay.
- `GAME_SALON_LOOP.md` — 5-step salon (local→frontier→clarify→confirm→output); frontier never writes map unconfirmed.
- `DM_MAG_TRANSFER.md` — DM↔Mag harness map; data harvest turns emit `training_events` w/ `dogfood_dm`.
- `GAME_VILLAIN_GUILD_DESIGN.md` — 6 villain laws (funny-mean, fair hindsight, flaw-collapse), rooms→verification-skills, kid-test gate. **= quest/threat budget example.**
- `CHAT_PLAY_LOOP.md`, `PLAY_BENCHMARK.md`, `LEXICON.md`, `CORE_MEMORY_PROTOCOL.md` — glue.

**Game modules + engine (`memory/game_modules/`, `mag/*.py`)**
- `adventure_2d6_stub.v1.json` — 2d6-lite, fail-forward, rooms as data.
- `dnd_classic_stub.v1.json` — "The Guttered Lantern→Classic Keep" 5e-srd-lite; the **hub whose fraternal twin** is the tavern fight.
- `water_computer.v1.json` + `mag/water_computer.py` — height-IS-computation keep; engine owns heights, bucket is DISPUTED cheat. **= phase/verb physics.**
- Engine: `game_campaign.py` (state/legal-actions first, LLM narrates after; CHAR_DIR `game_characters/`, traits fire CK-lite tables), `game_narrate.py`, `game_dm.py/_llm/_voice`, `game_brawl_perspectives.py` (**multi-POV monologue banks, engine-bound** — already Rashomon-ized), `lane_salon.py` (multi-LANE consensus: roshomon token-overlap + distinct contributions — the **proposer/attacker/synthesizer plumbing already exists!**), `narrative_engine.py`.
- Campaigns (`campaigns/*/module.json`): `sunless_citadel` (ghost harness), `quiet_forge`, `parable_ledger_capture`, `villains_guild`.
- `memory/train_data/resident_actor_seed.jsonl` — fireball/metal-fish lifecycle importance-scored memory seeds.

**Fireball-cycle skill (`/mag/.agents/skills/fireball-cycle/SKILL.md`)** — OLIVER LAW: fireball changes phase + CREATES A TOOL; water keep earned height; don't score a beat as an ending while charge remains; don't invent a CLI that FILE already is; heart=operator. **= the creative physics all this must respect.**

---

## B — SOCRATIC CORPUS-PLAY FORMAT (multi-lane character depth)

**Format name:** *Rashomon Salon* (v1). Reuses `lane_salon.py` concurrency as prose.
**Ground rule (from INDEX + GAME_THEORY):** engine holds `engine_truth`; models trade *voice*. One lane owns the ledger = referee lane; it never improvises facts.

**Lanes (reuse existing seat roles)**
- **Proposer lane** (engine/ledger): states the beat + the `engine_truth` card. Question to others: *"Given ONLY this, what does your character want/suppress/rationalize?"*
- **Attacker lane** (adversarial voice): attacks the thin spots — *"Which HP/room/flag would your account violate?"* Meets obligations, never invents verbs/HP. Supplies the hard_negative (died/no-death) check.
- **Synthesizer lane** (frontier/guest): never writes a beat unconfirmed. *"What single load-bearing invariant survives all five accounts?"* Outputs the merged character card.
- **Archetype lane** (esoteric grounding): *"Which of the 12 archetypes + shadow correspondences is this voice performing? What is the coniunctio they refuse?"*

**Per-bear loop:** proposer reads event + truth → each voice-lane renders the same moment in its lens → attacker stress-tests against `engine_truth` (leaches invented HP/Kills) → synthesizer folds into an upgraded character card, silent craft rails (Le Guin-clean, hub_return) enforced.

**Synthesis output = character depth artifact:** `{archetype, esoteric correspondence, want, wound, tell, anchor_invariant, voice_lines[]}` — FIGHT-GROUNDED (each tell traces to an engine flag, e.g. fighter↔`bar_brawl_tonight`).

**Tavern fight IS the template, not a metaphor:** fighter/wizard/rogue/barkeep/stranger across one bar fight = same moment × N lenses, engine truth in one lane = exactly the loop. Character depth = how many *admissible* perspectives a single character can honestly hold + how sharp the attacker's contradiction.

---

## C — CONNECTION TO THE dnd-tools / GAME ENGINE

**Existing contract (confirmed in code/doc, matches TOOLS.md):** `game_campaign.py` = "state/legal-actions first; LLM narrates after"; `game_narrate.py` is color-only; engine is form/referee. Engine owns `engine_truth`.

**Integration points (no new CLI — FILE/LOAD is the tool, fireball law):**
1. **Character sheets as corpus-resident state:** socratic synthesis writes to `CHAR_DIR` (`memory/working/game_characters/`), NOT to chat. Traits already fire CK-lite tables — socratic tells become `traits` entries the engine can roll on.
2. **Corpus = few-shot bank:** tavern seed + brawl perspective banks feed `game_narrate.py` as passage-cards; `resident_actor_seed` importance-scoring keeps load-bearing state alive.
3. **Engine-voices split:** engine lints every player-char claim against the ledger (attacker-lane logic reuses Sancho/engine_truth) → illegal verb = refuse (game theory play-map). LLM never contradicts engine when role=engine.
4. **Rashomon Salon session = one turn type** alongside freeze/salon/brawl; output = upgraded character card + `training_events` (`perspective`, `unreliable`, `hub_return`, `threshold`) for later train.

**Campaign look (models who socratically read the corpus):**
- Each seat plays a character whose **identity is the intersection of its narrative read + engine truth** — Fighter isn't "brave," Fighter is "loyal-to-keep + `bar_brawl_tonight` flag + shadow=outlaw esoteric." The socratic read pre-loads *voice* (what this character would honestly say) while engine binds *fact* (what happens).
- Proposer/attacker/synthesizer recur *inside the diegesis* as the party's own arbitration: characters argue = the salon loop becomes play.
- Campaigns (`sunless_citadel`/`villains_guild`) accept these cards directly; villains_guild's "fooled-30%/caught-70%" fairness law maps to the attacker lane's calibration.
- No ending scored while engine charge remains; every socratic gain must trace to a file the engine reads, or it's the Captain-Planet cheat (all water / no tool) — fireball law holds.

---

*One line: engine owns what happened; socratic salon owns who's telling it; the file is the character.*
