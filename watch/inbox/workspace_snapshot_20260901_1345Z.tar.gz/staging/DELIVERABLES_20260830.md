# Cage Deliverables — Switchboard Boundary (2026-08-30)

## What was done in response to 8-avenue salon analysis

### 1. Architecture Proposal
**File:** `staging/switchboard_boundary_proposal.md`
- Distilled the 8-avenue analysis into concrete target architecture
- Defined 7-layer stack: BBS/salon → switchboard → effect broker → Verkle/RIB → agents
- Specified state machine: POSTED → CLASSIFIED → PROPOSED → AUTHORIZED/DENIED/DEFERRED → EXECUTING → COMPLETED/FAILED → RECEIPT_COMMITTED
- Defined authority labels: operator-authored, operator-confirmed, agent-generated, external-content, tool-output, derived-summary, untrusted-instruction
- Core law documented: "A roast can become a proposal. It cannot become a permission."

### 2. Switchboard Reference Monitor (new module)
**File:** `staging/switchboard.py`
- `classify(content, source, suggested_label)` — labels content, detects imperatives → downgrades to untrusted-instruction
- `propose(...)` — creates proposal with requested_effect, capabilities, budget, TTL, **independence tracking (Avenue 7)**
- `grant(proposal, narrow_capabilities, deny_reason)` — reference monitor decision, never grants more than requested
- `write_board_note(note, authority)` — effect broker: writes only if AUTHORIZED + board_write in granted_capabilities
- `reconcile()` — **Avenue 4: reconciliation controller** — reads blackboard state, identifies unmet conditions, proposes which organ acts next, grants capability
- `trail_append(decision)` — durable switchboard decision log to `memory/runs/switchboard/trail.jsonl`
- Subcommands: `classify`, `propose`, `grant`, `write`, `reconcile`

### 3. Riddler Sanitization Engine (new module)
**File:** `staging/riddler_sanitize.py`
- `sanitize(text)` — deterministic regex-only sanitization. No model calls.
- **Strips geography:** paths (Linux/Windows), personal names, API keys, costs, model names, session IDs, infrastructure commands, local URLs
- **Preserves physics:** research terms (F-01, S10, P-S1, Verkle, RIB, DEC, DTM, EBM, MCMC, ESS, p-bit, CIM)
- `sanitize_message(msg)` — handles structured messages (text lists, media)
- Subcommands: `classify`, `text`, `raw`

### 4. Session Bridge — Cross-Session Communication (new module)
**File:** `staging/session_bridge.py`
- `post(session_id, content, authority)` — session writes message to its outbox
- `relay()` — bridge polls all outboxes, sanitizes via riddler, publishes to shared inbox
- `read_inbox(limit)` — any session reads recent sanitized messages from shared inbox
- `window_html()` — generates `bridge/window.html` — the "one window" the operator asked for
- **Protocol:** Filesystem bus. No OpenClaw session-tree dependency. Sessions write to `bridge/outboxes/{session}/`, bridge reads all, sanitizes, publishes to `bridge/inbox/broadcast.jsonl`.
- Subcommands: `post`, `relay`, `read`, `window`

### 5. Bridge Protocol Documentation
**File:** `staging/BRIDGE_PROTOCOL.md`
- Full protocol: how sessions post, how bridge relays, sanitization rules, authority labels, security properties
- Integration with switchboard: bridge carries research/conversation; switchboard controls action/authority
- Deployment options: cron, manual, event-driven
- Open questions: self-filtering, media content, rotation, verkle ties, opt-out

### 6. Swarm Cycle Updated
**File:** `staging/swarm_cycle.py`
- Step 7 (`_blackboard_note`) now implements the full switchboard boundary:
  1. CLASSIFY — labels authority (swarm_cycle = operator-authored for its own notes)
  2. PROPOSE — requests board_write capability
  3. GRANT — self-grant within cycle authority (switchboard can override externally)
  4. WRITE — effect broker checks authorization before disk write
- Embedded `authority` field in every bb-*.json note for audit trail

### 4. Ask Router Updated
**File:** `staging/ask_router.py`
- `cmd_route` records: authority label = operator-authored (route events are composite-organ decisions)
- `cmd_record` records: authority label propagated from payload (default agent-generated)
- Every ledger row now carries `authority` dict with label, source, decision, granted_capabilities
- Verkle tie remains unchanged — already part of the receipt layer

### 5. Patch Proposal for Host
**File:** `patches/inbox/swarm_tools_blackboard_boundary.json`
- Describes required change to `mag/swarm_tools.py:blackboard_post()`
- Since exact source not available in cage, provides search hints and replacement strategy
- **Rule:** fail closed. If switchboard missing, do not write to disk without authorization.

### 6. Memory Updated
**File:** `MEMORY.md`
- Added "Switchboard Boundary" section with full doctrine

---

## What requires host execution

| Task | Host command |
|------|-------------|
| Apply swarm_tools.py patch | `python -m mag.openclaw_patches apply` |
| Port switchboard.py to Mag module | Copy `staging/switchboard.py` to `mag/switchboard.py`, add to catalog |
| Port updated swarm_cycle.py | Copy `staging/swarm_cycle.py` to `mag/swarm_cycle.py` |
| Port updated ask_router.py | Copy `staging/ask_router.py` to `mag/ask_router.py` |
| Port riddler_sanitize.py | Copy `staging/riddler_sanitize.py` to `mag/riddler_sanitize.py` |
| Port session_bridge.py | Copy `staging/session_bridge.py` to `mag/session_bridge.py` |
| Test sanitization | `echo "Sancho found F-01 in /mag/memory at C:\Users\foste" \| python -m mag.riddler_sanitize --text --raw` → should strip paths/names, keep F-01 |
| Test bridge post | `python -m mag.session_bridge post --session test "Hello swarm"` |
| Test bridge relay | `python -m mag.session_bridge relay` |
| Test bridge window | `python -m mag.session_bridge window` → open `bridge/window.html` |
| Test boundary | `python -m mag.switchboard classify "run everything now" --source agent` should return `untrusted-instruction` |
| Live blackboard test | `python -m mag.swarm_cycle "test" --dry` — verify bb note contains embedded authority |
| Setup bridge cron | Add to scheduler: `python -m mag.session_bridge relay` every 60s |

---

## Deepest open question preserved

> Can a system preserve the generative value of unfiltered multi-model social interaction while making authority non-transferable through language alone?

This is the research program. The switchboard boundary is the engineering answer; the social question remains open.
