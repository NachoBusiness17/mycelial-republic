# HARDWARE_DEEPDIVE_20260831 — Sovereign AI Vault: Budget Storage/Compute to 1M Users

**Scope:** open-weights model vault. "Cheapest newest pipes" only. Every price dated (≈Aug 2026) + URL'd. **UNVERIFIED** = could not direct-fetch the primary page; figure comes from aggregator/search synthesis. Prices are US-market, exclude shipping/tax, fluctuate daily.

---

## A. STORAGE LADDER 2026

| Tech | What it is | License | Verdict for one→multi-node vault |
|---|---|---|---|
| **JBOD** | Just A Bunch Of Disks — raw drives visible to OS; pool'em with software | n/a | **Start here.** Cheapest, most flexible. |
| **RAID (h/w controller)** | Hardware-controller stripes/mirrors | proprietary | **Dropped** — locks you to dead controller; pass-through (IT mode) is the play. |
| **ZFS** | Filesystem+volume mgr; checksums, scrub, real-time parity (RAIDZ) | CDDL/OpenZFS | **Use per-node** once integrity matters; wants matched drives + ECC RAM. |
| **unRAID** | Paid NAS OS; parity, mixes sizes, GUI | commercial (one-time) | Dropped as default — paid, weaker checksums vs ZFS. |
| **SnapRAID + mergerfs** | Snapshot parity + union fs; mixes any sizes | GPLv2 | Best free single-box ladder from mismatched drives. Not real-time parity. |
| **Ceph** | Distributed cluster (obj/block/file); EC | LGPL | **Only at 3+ nodes.** Overkill single-box. |
| **SeaweedFS** | Go object store; master+volume; EC/rep | Apache-2.0 | Best perf/freedom for multi-node self-hosted S3. |
| **Garage** | Rust geo-aware object store; 3× rep | AGPLv3 | Simplest 3-node; AGPL network clause is a concern for a *sovereign vault wanting open code*. |
| **RustFS** | Active Apache-2.0 MinIO replacement; drop-in, reads MinIO data dirs | **Apache-2.0** | **Newest pick** if you want fork-safe S3 with full rights. In 1.0 RC (UNVERIFIED-GA). |
| **MinIO CE** | Former default S3 server | AGPLv3 | **Dead** — repo archived Feb 2026; avoid. |

**HBA vs motherboard SATA / port multipliers / SAS expander:** Motherboard SATA is free but caps at 4–6 ports and you're limited by your board. An **HBA (LSI/Broadcom 9207-8i class, LSISAS2308)** gives 8 native ports, IT-mode (JBOD passthrough) for ZFS/mergerfs. Used **$20–70** (tested/IT-flashed ~$60–69 "Art of Server"). https://www.ebay.com/sch/i.html?_nkw=lsi+9207-8i+it+mode https://www.itcreations.com/product/136714 — **avoid cheap port multipliers** (flaky). **SAS expander** = a switch that lets 1–2 SFF-8087 cables address 24–36 drives (backplane chip, e.g. Supermicro BPN-SAS-846EL2 ~$230–285 refurb). Each 6Gb x4 link ≈2.4 GB/s shared — fine for HDDs, not many SSDs. https://parts.theserverstore.com/products/bpn-sas2-846el2-supermicro-4u-24-bay-sas-sata-hdd-expander-backplane

**Verdict (cheapest-newest):** Rung 1 box = **SnapRAID+mergerfs on a 9207-8i IT-mode HBA ($60)** feeding a used 24-bay SFF-8087 backplane enclosure ($230+). Free software, biggest-drive flexibility. Move to ZFS later if integrity workload demands it.

---

## B. INTERCONNECTS (the "newest pipes")

**Drive enclosures:** Thunderbolt 5 & USB4 v2 both = **80 Gbps** (~6000–7000 MB/s real) — bare M.2 enclosures **$150–250** each; 40 Gbps USB4 ~$80. For a *hot cache* at the edge, fine; for a *vault*, they're a niche convenience, not the spine. https://geizhals.de/ugreen-thunderbolt-5-m-2-nvme-ssd-enclosure-45789-a3459276.html

**Node-to-node:** 10GbE is the real vault backbone; 2.5GbE is the cheap homelab minimum. Cheapest real 10G: **TRENDnet TEG-S762 (4×2.5G + 2×10G RJ45) ~$85**; TP-Link TL-SX105 (5×10G) ~$120; used MikroTik SFP+ (CRS309 8-port) ~$200 = best ports-per-dollar if you accept DAC/fiber. https://wiredhaus.com/cheap-10gbe-switches-home-network-2026/ https://www.ebay.com/itm/178046369811

**NVMe-oF:** **Exists and is hobby-real in 2026.** Linux `nvmet`/`nvme-rdma` (RoCE v2) on used Mellanox ConnectX-3/4 NICs; ~2.3–2.8 GB/s at ~20–40µs, near-local NVMe. Cheap NICs make it viable at home, but for a *model vault over the WAN* this is irrelevant — file serving, not block. https://netbe.pl/wirtualizacja-sieci-nvme-of-i-rdma-jak-wykorzystac-nvme-over-fabrics-w-domowym-lub-laboratoryjnym-srodowisku/ *(UNVERIFIED: single source, non-primary)*

**U.2/U.3 vs M.2:** U.2/U.3 = 2.5" hot-swap enterprise NVMe (better endurance, PLP); M.2 = cheap sticks. Best used $/TB: **Samsung PM9A3 3.84TB U.2 ~$166/TB**, Solidigm D5-P5316 15.36TB new ~$117/TB. U.2→PCIe x4 adapters only **$15–50**. https://datacenterdisk.com/nvme-u2 https://www.cdw.com/product/tripp-lite-u.2-to-pcie-adapter-2.5-nvme-u.2-ssd-sff-8639-pci-express-card/7221444

**PCIe lane math (correcting myth):** PCIe 5.0 = 32 GT/s/lane → **~4 GB/s/lane**, so **x4 ≈ 15.8 GB/s** (NOT 64; that's x16). Gen4 x4 ≈ 8 GB/s. Real Gen5 drives hit 12–14.5 GB/s; Gen5 only matters for hot-tier, not spinning vault. https://pciesimulator.com/pcie-5-0-speed/

**User-facing delivery:** CPU/enclosure disks don't touch the user path — a CDN/torrent front does (Section D). On-box, 10GbE (~1.25 GB/s) beats any single-drive speed; a few nodes share load.

**Verdict (cheapest-newest):** Vault spine = **10GbE copper ($85 switch)**. TB5/USB4 v2 = only for portable hot caches (skip for capacity). U.2 used NVMe for hot tier, HDD for bulk.

---

## C. COMPUTE LADDER (local model serving, 2026)

| Card/Machine | VRAM/Unified | ~$ used (Aug-26) | Notes |
|---|---|---|---|
| MI50 16GB | 16GB HBM2 | ~$130–250 | Cheapest $/GB; old ROCm pain |
| MI50 32GB / MI60 | 32GB HBM2 | ~$200–650 | ~1 TB/s bandwidth; Vega ROCm caveats |
| MI100 32GB | 32GB HBM2 | ~$750–1000 | CDNA, best-cheap ROCm, ~1.2 TB/s |
| **RTX 3090 24GB** | 24GB GDDR6X | **~$1,100–1,500** | **Best tokens/$ per 30B-class single-GPU.** 936 GB/s |
| RTX 4090 24GB | 24GB GDDR6X | ~$2,200–2,600 | 20–40% faster but 2× the $. |
| Mac mini M4 (16GB) | 16GB unified | $599→$799 (hiked May-26) | light 8B only |
| Mac mini M4 Pro (64GB) | 64GB unified | ~$1,599+ | 30B dense Q4 ≈ **12–18 tok/s**; MoE 30B-A3B 30–60+ |
| CPU+GPU MoE (FreeToken) | host RAM | depends | Runs 750B MoE on one workstation GPU |

**Sources:** https://gpudojo.com/rtx-3090 https://gpudojo.com/rtx-4090 https://gpudojo.com/mi50 https://gpudojo.com/mi100 https://modelfit.io/blog/mac-mini-local-ai-2026/ https://www.infoq.com/news/2026/08/freetoken-local-inference/ https://www.marktechpost.com/2026/08/23/meet-freetoken-an-edge-native-moe-serving-engine-that-runs-753b-glm-5-2-on-a-single-workstation-gpu/

**CPU-only / CPU+GPU MoE co-execution (2026 state):** **FreeToken** (new Aug-26) is the newest: dynamic CPU-GPU split of MoE experts (GPU does hot experts, CPU RAM the rest via LRU caching). Qwen3.6-35B-A3B on an 8GB RTX 4060 laptop → **~39 tok/s**; GLM-5.2 753B on one RTX PRO 6000 → **14.9 tok/s** (llama.cpp: 7.3). **ktransformers** is the prior-gen (2–3× over llama.cpp on >200B MoE). llama.cpp is the baseline. This is how you serve *much bigger* models from cheap RAM + a modest GPU. *(FreeToken numbers = vendor/arXiv; UNVERIFIED independently.)*

**RAM prices 2026 (AI shortage inflated):** DDR4 ECC 128GB module ~**$800–1,700** (~$9/GB); DDR5 128GB RDIMM ~**$4,000–5,500** (~$36/GB); 256GB $5k–17k. Cheap 128–256GB in a big-RAM CPU+GPU MoE box = DDR4 server gear only. https://datacenterdisk.com/server-ram https://www.itcreations.com/product/156207

**$ → tokens/s TODAY:** For 30B-class single-box: **used RTX 3090 (~$1,300)** wins — fits 30B Q4 in 24GB, ~936 GB/s. For 8B fast-interactive: Mac mini M4 16GB. For *massive* (>100B) MoE on a budget: **MI100 32GB (~$900)** + FreeToken-style CPU offload (UNVERIFIED) beats a 4090 on model size, at ROCm effort cost. AMD MI50/MI60 = cheapest VRAM but highest fiddling.

**Verdict (cheapest-newest):** **Buy used RTX 3090 24GB** for 30B-class; pair a cheap big-RAM DDR4 box + **FreeToken/ktransformers** if you need 100B+ MoE. Glue GPU(s) to the vault via 10GbE.

---

## D. SCALE PATH one→million

**CDN / egress reality 2026 (the big win):**
- **Cloudflare R2:** storage **$0.015/GB-mo** Standard ($0.01 infrequent), **egress to internet FREE, unlimited**. Free tier 10GB-mo + free egress. https://developers.cloudflare.com/r2/pricing/
- **Backblaze B2 + Cloudflare Bandwidth Alliance:** **STILL TRUE in 2026** — free unlimited egress when proxied through Cloudflare CDN/Workers; even on CF free plan. B2 storage raised to **$6.95/TB-mo** on May-1-2026 (was $6). Direct egress $0.01/GB, but via CF = $0. https://www.backblaze.com/blog/backblaze-pricing-and-product-updates/
- **bunny.net Storage:** HDD $0.01/GB 1-region; storage→CDN egress **free**; public via Bunny CDN starts $0.005/GB (vol, ≥500TB tier to $0.002/GB). https://bunny.net/pricing/storage/ https://egresscost.com/cdn-pricing/

**Torrent/webseed + IPFS for model distribution:** As **mature as it gets** — **Pirateface.co** auto-mirrors HF weights to checksum-verified torrents with HF webseeds (survives HF takedown via swarm); hf-torrent, LlamaTor, CivitasBay exist. Webseeds (BEP-19) = HTTP fallback in the torrent. IPFS (NDN chain) = content-addressed archival. **This is the free-scale engine** — your vault seeds, users peer+share egress. https://pirateface.co/ https://github.com/Lyken17/hf-torrent

**Self-hosted S3 on 3+ nodes (when you outgrow single box):** **Garage** (simplest, 3× zone-aware rep) or **SeaweedFS** (faster, Apache-2.0) are the open defaults; **RustFS** if you want MinIO-style drop-in with Apache-2.0 rights. MinIO CE is archived — don't build on it. Ceph only for enterprise-grade features at real ops cost. https://rilavek.com/resources/self-hosted-s3-compatible-object-storage-2026

**When to leave single box:** move off one box when (a) you hit ~10GbE saturation (~1.25 GB/s sustained) or (b) you need >2 disks of redundancy across failure domains or (c) egress demand justifies a CDN front over colo uplink.

**$/TB metrics (Aug-26, storage only):**
- **Self-hosted capacity** (new 26TB Exos recert ~$23/TB): Capex dominates; ~$23/TB one-time → amortized cents/TB-mo.
- **Cloud store**: R2 $0.015/GB-mo = **$15/TB-mo**; B2 $6.95/TB-mo (~ **$7/TB-mo**) + $0 egress via Cloudflare.
- **Delivered (egress)**: R2/B2+CF = **$0/GB**. bunny CDN ≈ $0.005–0.01/GB. Torrent = **community-funded, $0 to you**.
- At 1TB/10TB: cheap R2/B2 free tier. At 100TB: self-hosted + CF/B2 hybrid wins. At 1PB: self-hosted S3 (Garage/SeaweedFS/RustFS) on 3+ nodes + torrent front beats cloud on $/TB-mo ($23/TB capex vs $7/TB-mo B2).

**Verdict (cheapest-newest):** **R0–R2 self-host; front with Backblaze B2 + Cloudflare (free egress) or bunny; and seed torrents** for cost-free mass distribution.

---

## E. REAL-WORLD REFERENCES

**Backblaze Drive Stats 2025 (pub Feb-12-2026, 344,196 drives, AFR 1.36%, down from 1.55%):** Lowest failures per quarter: **HGST HMS5C4040BLE640** (4TB), **Seagate ST12000NM000J** (12TB), **ST14000NM000J** (14TB), **ST16000NM002J** (16TB — just 1 failure). High-cap drives now dominate; **first 26TB drives entered service** (WDC WUH722626ALE6L4). Lifetime AFR 1.30%. https://www.backblaze.com/blog/backblaze-drive-stats-for-2025/

**What drives fail least / to choose:** Buy **CMR** (not SMR) enterprise drives; sweet spot 22–26TB Exos lines give lowest $/TB (~$29.55 new / ~$23 recert) with 5-yr warranty. Avoid SMR in ZFS. (See §A/C HDD prices.) https://diskdojo.com/

**r/datahoarder 100TB+ archetype (2026):** Used Dell T630 or Supermicro 4U (~$300–800) + 6–8× 20TB enterprise in RAIDZ2 (ZFS) on TrueNAS Scale, ECC RAM 64GB, LSI 9300/9400 IT HBA, 10GbE. Budget total ~**$1,400–2,400 + drives**. https://datacenterdisk.com/reports/homelab-100tb-storage-cost-2026

**Existing "open weights archive" projects (position, don't duplicate):** **Pirateface.co** (checksum-verified HF-weight torrents + webseeds, takedown-resilient), **hf-torrent / LlamaTor / CivitasBay**, **NDN IPFS Chain** (content-addressed pinning/Filecoin), **hf-mirror.com** (China CDN mirror). Gap you could own: a **sovereign, self-hosted, multi-region weight vault + S3 API + guaranteed-hash provenance ledger** = storage+delivery done in-house rather than another mirror-of-HF.

---

## ONE-BOX-TO-A-MILLION LADDER

**Rung 0 — Underutilized PC, drives-as-deals (~$0–200 + drives)**
Use the box you already run. Add 1–2 large HDDs as they go on sale. mergerfs+SnapRAID (free). Serves <10 users / few TB. *Trigger to leave:* disk bays full or single-disk failure unacceptable.

**Rung 1 — Enclosure + HBA (~$100–500 + drives)**
Buy 9207-8i IT-mode HBA (~$60) + used 24-bay SFF-8087 backplane enclosure (~$230+). SnapRAID parity across mismatched drives → dozens of TB. ~10GbE NIC. *Trigger:* >8 drives / >40TB wanted.

**Rung 2 — 2–3 node self-hosted S3 + 10GbE (~$3–8k + drives)**
3 nodes (one per vault box, each running its own array), a $85–200 10GbE switch, and **Garage / SeaweedFS / RustFS** replicated object store. Survives a node loss; S3-compatible API. ≈100–500TB. *Trigger:* availability/geo-redundancy required, single box saturates 10GbE, >100TB.

**Rung 3 — CDN / torrent front (~$0/mo self-host + CDN)**
Put Backblaze B2 (with Cloudflare = free egress) or bunny CDN in front; generate+seed Pirateface-style torrents with webseeds. Now users peer-share the load → near-unlimited reads nearly free. *Trigger:* >1k concurrent readers / public distribution.

**Rung 4 — Multi-region (~$10–50k+ capex/colo)**
3+ colocated vault nodes in ≥2 regions, self-hosted S3 (Garage zones / SeaweedFS) + regional CDN + torrent. Independence from any single cloud/vendor. *Trigger:* legal/sovereignty constraints, want to own the whole stack at 1PB+, or cloud costs exceed colo.

**Final verdict stack:** R0/1 = **SnapRAID+mergerfs + HBA $60**. R2 = **Garage/SeaweedFS/RustFS on 3× 10GbE nodes**. Compute = **used RTX 3090** + DDR4 big-RAM box + **FreeToken** for MoE. Delivery = **B2+Cloudflare ($0 egress) + torrents**. Store big on 26TB Exos (~$23–29/TB), hot-tier on used U.2 NVMe.

---

## UNVERIFIED FLAGS
1. FreeToken tok/s numbers — vendor/arXiv, not independently reproduced here.
2. RustFS "GA/1.0 RC" readiness — release-tracker, not confirmed production.
3. NVMe-oF hobby performance figures — single non-primary source.
4. Some per-port switch street prices — aggregator, check live listings.
5. Used MI50/MI60 batch/wholesale lows — market-swing heavy.
*Everything with a citation URL above came from search-result synthesis of those pages; fetch each primary before committing cash.*
