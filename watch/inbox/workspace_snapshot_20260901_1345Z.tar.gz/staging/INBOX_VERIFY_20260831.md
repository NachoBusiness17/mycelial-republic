# Inbox Verification — 2026-08-31

GOPHER task (quotes only, no invention). Two repos, four claims.

---

## A) Ponytail skill (anti-over-engineering skill for coding agents)

### A1 — What the skill actually does
**Source:** https://github.com/DietrichGebert/ponytail (raw README fetched: https://raw.githubusercontent.com/DietrichGebert/ponytail/main/README.md → 200 OK)
**Date:** 2026-08-31 (repo pushed_at 2026-08-07; README current)
**Confidence:** HIGH (direct primary-source quotes)

Repo description (GitHub API): *"Makes your AI agent think like the laziest senior dev in the room. The best code is the code you never wrote."*

README motto: *"He says nothing. He writes one line. It works."*

**Core claim (headline):** *"~54% less code (up to 94%) · ~20% cheaper · ~27% faster · 100% safe"* — with the caveat (subnote): *"Measured on real Claude Code sessions editing a real open-source repo (FastAPI + React), against the same agent with no skill. ~54% is the mean across 12 feature tasks (Haiku 4.5, n=4); it reaches 94% where an agent over-builds (a date picker) and is near zero where the code is already minimal."* And: *"(The earlier single-shot benchmark reported 80-94% as a flat figure; against a fair agentic baseline that is the per-task ceiling, not the average.)"*

**The rule / ladder it installs (quoted verbatim):**
> Before writing code, the agent stops at the first rung that holds:
> ```
> 1. Does this need to exist?   → no: skip it (YAGNI)
> 2. Already in this codebase?  → reuse it, don't rewrite
> 3. Stdlib does it?            → use it
> 4. Native platform feature?   → use it
> 5. Installed dependency?      → use it
> 6. One line?                  → one line
> 7. Only then: the minimum that works
> ```
> "The ladder runs *after* it understands the problem, not instead of it: it reads the code the change touches and traces the real flow before picking a rung. Lazy about the solution, never about reading."
> "Lazy, not negligent: trust-boundary validation, data-loss handling, security, and accessibility are never on the chopping block."

**Hooks:** "The Claude Code and Codex plugins run two tiny Node.js lifecycle hooks." On Claude Code it injects the ruleset every turn via a `SessionStart` hook; these hooks are required for the effect to actually activate (confirmed as critical in A2). Also ships `AGENTS.md` and per-host rule files for Cursor/Windsurf/Cline/Copilot/etc. Commands: `/ponytail [lite|full|ultra|off]`, `/ponytail-review`, `/ponytail-audit`, `/ponytail-debt`, `/ponytail-gain`, `/ponytail-help`.

**License:** MIT. License section quoted: *"[MIT](LICENSE). The shortest license that works."* (GitHub API confirms `license: MIT`).

**Maintenance state (GitHub API, fetched 2026-08-31):**
- Stars: **117,821** (watchers 117,821)
- Forks: 6,423
- Created: 2026-06-12; pushed_at: **2026-08-07** (active; updated_at 2026-08-31)
- Open issues: 185
- Language: JavaScript
- Homepage: ponytail.dev

### A2 — Counter-evidence: JetBrains independent test
**Source:** https://blog.jetbrains.com/ai/2026/07/ponytail-skill-claude-tested/ by Denis Shiryaev, "Ponytail Skill for Claude Code: Does It Really Cut Agent Code by 54%?" (Part 3 of the series). Fetched 2026-08-31 → 200 OK.
**Confidence:** HIGH (verbatim from fetched page)

**Verdict quoted verbatim:**
> "**Verdict** — Ponytail works. Across 80 paired tasks, it cut the typical bill by 10.3% and reduced code written by 15%, with no quality difference we could detect. It is the first tool in this series that clearly saved money. If you install it and forget about it, you should be modestly better off.
> Do not expect the advertised 54% everywhere. Ponytail's benchmark uses tasks with obvious over-building traps. Ours did not. In our runs, code fell 31% on larger builds and barely moved on tasks that were already lean. The more over-building your agent does, the more ponytail can cut."

Headline summary in the post:
> "Real savings, although roughly a quarter to a half of what is advertised, it is the first tool in this series with a statistically solid cost-saving signal. We found no quality difference, though ~80 pairs can only rule out large ones. The catch: the code cut only shows up where there was room to over-build."

Measured numbers (80 paired tasks, Claude Code 2.1.201, claude-sonnet-5): **−15.4% code (10,205 → 8,756 lines; p=0.088), −10.3% cost (p=0.004), −10.6% time**, tokens ~−7.5% (noisy), quality no detectable difference (6 better / 9 worse / 65 identical).

**Critical caveat (Finding 1):** the skill does **not** self-activate by dropping `SKILL.md` into a skills folder — *"Across all ten sessions it self-activated zero times. Not rarely. Never."* The effect requires the plugin's `SessionStart` hook that forcibly injects the ruleset. *"Copy the SKILL.md into a skills folder and you will very likely measure nothing."*

### A1/A2 verdict: **INFLATED** (as a headline) / **VALID as a real effect**
The skill is real, MIT, actively maintained, and does reduce code — but independent measurement finds roughly **a third to a quarter of the advertised effect** (−15% code, −10% cost vs advertised −54%/−20%), and only where there is over-building headroom. The 54% headline is task-selected. Gap-map: advertised vs measured gap is methodological (hand-picked over-build tasks vs 80 unselected tasks; mean vs median). Skill only works via the SessionStart hook (self-activation fails).

---

## B) DART (SAM3 → real-time open-vocabulary detector)

### B1 — Benchmark configs for 55.8 AP and 15.8 FPS
**Source:** https://github.com/mkturkcan/DART (raw README: https://raw.githubusercontent.com/mkturkcan/DART/main/README.md → 200 OK)
**Date:** 2026-08-31 (repo pushed_at 2026-08-30)
**Confidence:** HIGH (direct primary-source quotes of tables)

**Headline (quoted verbatim):** *"Training-free framework that converts SAM3 into a real-time multi-class open-vocabulary detector. Achieves **55.8 AP** on COCO val2017 (80 classes) at **15.8 FPS** (4 classes, 1008px) on a single RTX 4080."*

→ Note: even the README's own headline states **AP at 80 classes** and **FPS at 4 classes** — i.e., DIFFERENT class counts.

**AP table (COCO Evaluation → Detection AP, quoted verbatim).** Setup line: *"Standard COCO AP (IoU 0.50–0.95) on val2017 (5,000 images, 80 classes)"*:
```
| Configuration | Res. | AP | AP50 | AP_S | AP_L | ms/img |
|---------------|------|----|------|------|------|--------|
| **Full TRT FP16** | **1008** | **55.8** | **73.4** | **40.3** | **70.7** | 225 |
| SBP-16 TRT FP16 | 1008 | 47.6 | 63.5 | 32.5 | 62.0 | 220 |
| **Full TRT FP16** | **644** | **39.1** | **63.9** | 12.4 | 65.4 | 105 |
| SBP-16 TRT FP16 | 644 | 32.8 | 54.5 | 9.9 | 56.7 | 100 |
```
→ **55.8 AP** = **80 classes, 1008px**, 225 ms/img.

**FPS table (Benchmarks → FPS vs. class count (1008px, RTX 4080, TRT FP16), quoted verbatim):**
```
| Classes | BB (ms) | E-D (ms) | Sequential FPS | Pipelined FPS |
|---------|---------|----------|----------------|---------------|
| 1 | 53 | 8 | 16.3 | 18.7 |
| 2 | 53 | 11 | 15.5 | 17.6 |
| 4 | 53 | 19 | 13.8 | 15.8 |
| 8 | 53 | 35 | 11.5 | 12.5 |
```
Plus: *"**15+ FPS** is achieved with up to 4 classes at 1008px. At 644px, all tested class counts exceed 30 FPS."*
→ **15.8 FPS** = **4 classes, 1008px**, pipelined.

**VERDICT on B1: DIFFERENT CONFIGS — AP (80 classes, 1008px) vs FPS (4 classes, 1008px).** Same 1008px resolution, different class count. The tweet reply's claim that AP and FPS come from different configs is **CONFIRMED by the repo's own text** — the README headline itself labels them separately and the tables show 80-class AP and 4-class FPS.

### B2 — Does the repo publish an 80-class FPS/throughput number?
**NO.** The FPS benchmark table only tests 1/2/4/8 classes; the 80-class path is documented only via usage commands (`build_coco_engine.py`, and the video command: `--trt-enc-dec enc_dec_coco_fp16_80.engine --text-cache text_cache_coco.pt --imgsz 1008`). There is **no 80-class FPS/AP-per-config throughput figure published** in the README. In fact the README shows 80 classes at 1008px "chunked (OOMs at max_classes=80 on 16 GB)" ("80 COCO classes, 1008px — chunked (OOMs at max_classes=80 on 16 GB)"), i.e. the 16GB RTX 4080 cannot build a max-classes=80 engine at 1008px in one pass. The only 80-class number that exists is the AP (55.8@1008 and 39.1@644); no 80-class FPS is published.
**Confidence:** HIGH. Gap-map: to fairly compare AP and "real-time" at identical config you'd need an 80-class FPS figure, which the repo does not provide.

### License & meta (B1/B2)
- **License:** GitHub API reports `license: other` (NOASSERTION). The repo ships a **Meta SAM License** (`LICENSE` file = "SAM License", by Meta / for SAM Materials) — i.e., not OSS/MIT; it's the Meta SAM model license.
- Stars: **610**; Forks: 80; Created 2026-03-11; pushed_at 2026-08-30 (active); Open issues 4; Language: Python. Single-author citation (2026), arXiv link given.

### B verdict: **VALID** (claims accurately reported) with a **gap-map caveat**
55.8 AP (80 cls, 1008px) and 15.8 FPS (4 cls, 1008px) are real repo figures from DIFFERENT configs, and the repo itself is explicit about both. The tweet reply's point is **valid**. Gap: no published 80-class throughput, so "real-time at 80 classes" is not substantiated; also 80@1008 OOMs on the 16GB RTX 4080 used for the benchmarks.

---

## Fetch log
| URL | Result |
|-----|--------|
| https://raw.githubusercontent.com/DietrichGebert/ponytail/main/README.md | 200 OK |
| https://api.github.com/repos/DietrichGebert/ponytail | 200 OK (meta/license/stars) |
| https://blog.jetbrains.com/ai/2026/07/ponytail-skill-claude-tested/ | 200 OK |
| https://raw.githubusercontent.com/mkturkcan/DART/main/README.md | 200 OK |
| https://api.github.com/repos/mkturkcan/DART | 200 OK (meta/license/stars) |
| https://raw.githubusercontent.com/mkturkcan/DART/main/LICENSE | 200 OK (Meta SAM License) |

All primary sources fetched directly; no failures. No claims invented; every figure is quoted from fetched text.
