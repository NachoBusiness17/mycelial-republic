# PHYSICS BENCH RESEARCH — 2026-08-31
Physical stochastic twin for a deterministic AI cloud. Quotes-only; UNVERIFIED = price/claim not confirmed against a fixed listing.

## 1. RESERVOIR COMPUTING PRECEDENTS
- **Fernando & Sojakka, "Pattern Recognition in a Bucket" (ECAL 2003)** — water waves as a Liquid State Machine; inputs drove motors, a camera (~5fps, 320×240) recorded ripple interference, pixel states fed a perceptron readout. Solved XOR and rudimentary spoken digits ("zero" vs "one") beyond perceptron-alone. (dataphys.org; scispace review)
- **Photonic RC (2020s)** — 2024 ultrafast silicon photonic engine >60GHz / >200TOPS; delay-line & fiber Rayleigh-backscatter reservoirs near SOTA on chaotic prediction. (Nature Comm 2024; 2026 IOP review)
- **Memristor RC (2020s)** — lateral CuCrP₂S₆ memristors ~89% MNIST, low NRMSE on Hénon/Mackey-Glass; in-memory, compact. (SciOpen 2026; Adv Science 2026)
- **Mechanical RC** — spring-mass-damper networks, single Duffing micromechanical resonators for MNIST/spoken-word; optimal at "edge of chaos" (neither linear nor strongly nonlinear). (ASME 2024; Microsyst Nanoeng 2021)
- **Minimal water reservoir experiment (transducer setup)**: transparent tank over projector/backlight + 2–4 vibration motors/transducers (input) + camera or float/pressure transducers (state readout) + linear readout (perceptron/ridge). Water gives nonlinearity + fading memory for free. **UNVERIFIED:** exact current transducer BOM price.

## 2. HARDWARE RNG FROM PHYSICAL NOISE
- **Zener/BJT avalanche TRNG**: reverse-bias ~9–12V Zener or base-emitter junction through high-value resistor; amplify, AC-couple, sample ADC LSBs or comparator; bias ≈9–25V (boost/charge-pump from 5V). **UNVERIFIED** DIY BOM ≈ $5–15 (Zener + op-amp + resistors + MCU, reused). (avr-hardware-RNG wiki; nicola-cimmino/TRNG GitHub)
- **"robse" = Rob Seward**: influential avalanche RNG w/ automatic recalibration against 0/1 drift. (avr-hardware-RNG wiki)
- **ChaCha**: CSPRNG seeds from avalanche entropy expands bits safely; hybrid TRNG+CSPRNG standard. (randomgen docs)
- **Radioactive decay RNG**: SBM-20 Geiger tube — **~$25–50 USD** (soviet-tubes $34.90; Electronic Goldmine $39.95; MightyOhm $49.95; eBay NOS ~$24–26). Requires HV ~400V supply + pulse counter. Low rate: background ~10–30 CPM (need source for speed).
- **NIST SP 800-22 (Rev 1a)** = statistical test suite (frequency, runs, approximate entropy…); passing p-values ≡ "random enough" but NOT formal certification. 2025 study of GM-tube radiation QRNG applied SP 800-22 + entropy tests, met criteria. (NIST; Springer EPJ Plus 2025)

## 3. SENSOR KIT 2026 PRICES
| Item | Price (2026, DIY/retail) | Note |
|---|---|---|
| ESP32 module | **$1–6** (dev board $5–15) | WROOM/C3; bulk cents |
| Ultrasonic level sensor | **$20–100** (IoT ~$45–70) | 0–5m |
| YF-S201 flow meter | **$7–40** (bulk $2–10) | Hall, ~450 pulses/L |
| Temp/pressure sensor | **$1–15** UNVERIFIED | BMP180/DS18B20-class |
| Peristaltic pump | **$10–50** (mini $7–15) | 12V dosing |
| Solenoid valve 12V | **$5–20** (plastic) | NC; brass $15–100 |

*Build tiers:* **$50** = ESP32 + YF-S201 + 12V valve + one sensor; **$100** = + ultrasonic level + peristaltic pump + TRNG noise circuit; **$200** = + 2nd sensor stack + SBM-20 Geiger + solenoid manifold. **UNVERIFIED** on temp/valve exacts.

## 4. TESLA COIL REALITY-CHECK
- **Slayer Exciter kit**: mini DIY **$1–15**; medium assembled w/ driver ~$200–280. **UNVERIFIED** exact.
- Can: produce arcs, light fluorescent tubes wirelessly, music modulation (spectacle + teaching). Can't: give *clean controlled* stochastic output.
- **SGTC safety** (one line): sealed/Faraday enclosure, dedicated RF ground (separate from house ground), bleeder resistors across MMC + manual discharge hook before handling.
- **Safe alternative (recommended)**: 12V ZVS plasma/arc modules **$7–20** (boost to kV, 30–50kHz) — same avalanche/breakdown stochastic physics at 12V, no lethal HV.
- **Verdict**: for *our* purposes the Tesla coil is **spectacle, not science** — a 12V Zener/BJT avalanche TRNG gives identical quantum stochastic physics without the 10kV+ hazard. Skip the coil.

## 5. EXISTING PROJECTS TO POSITION AGAINST
- **MONIAC (1949, Bill Phillips)** — hydraulic macroeconomic analog computer; tanks/pipes/pumps; museum originals. (ResearchGate)
- **EconIAC (github roguetrainer)** — open-source MONIAC-inspired *software* (JAX thermodynamics/TIR); **not** physical. (MIT)
- **Daniel de Bruin MONIAC** — physical metal-ball economic simulator (artistic, not open-source). (danieldebruin.com)
- **Physical entropy/AI**: memristor & sMTJ/p-bit probabilistic hardware, iontronic/microfluidic reservoirs, openentropy (Rust entropy-pool). **No existing open-source physical-hydraulic + entropy + AI project** — this is open territory. (github; Nature 2024)

## FINAL VERDICT — BUILD LADDER
- **$50 (Proof-of-physics)**: ESP32 + water resistor/tank + vibration transducers + camera → reproduce bucket RC XOR task; proves the reservoir concept on real hardware.
- **$100 (The stochastic twin core)**: + Zener avalanche TRNG w/ ChaCha + ESP32 telemetry → real physical entropy seeding a node; NIST SP 800-22 testable.
- **$200 (The fleet node)**: + YF-S201/peristaltic/solenoid water loop + SBM-20 Geiger → telemetered bench where deterministic cloud math is disturbed by genuine physical stochastic sources (avalanche + decay + fluid turbulence), all sensor-streamed.
- **Each rung makes REAL**: $50 = nonlinear physical reservoir ≠ sim; $100 = trustworthy hardware entropy (SP 800-22) for the fleet's seeds; $200 = the full physical stochastic twin model of the deterministic cloud, with verified noise provenance. Tesla coil excluded on safety:science grounds.
