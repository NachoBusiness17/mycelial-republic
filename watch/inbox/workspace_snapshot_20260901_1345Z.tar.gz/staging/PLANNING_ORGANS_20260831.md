# PLANNING-Shaped Organs in Mag's Catalog
GOPHER sweep (quotes only, no invention). Sources:
- `A` = `/mag/memory/runs/openclaw_catalog/fabric.json` (17 crown/fabric nodes)
- `B` = `/mag/memory/runs/openclaw_catalog/latest.json` → `scanned_extra` (608 scanned CLIs, all `family:"scanned"`, cmd = `python -m mag.<id>`)

Classification key: **goal-setting / sequencing / routing / scheduling / reconciliation / outcome-memory**

## Confirmed candidates + finds (all present in `latest.json` scanned_extra unless noted)

| organ | verbatim CLI (`cmd`) | verbatim origin/description (file cited) | planning-role |
|-------|---------------------|------------------------------------------|---------------|
| seat_dispatch | `python -m mag.seat_dispatch` | `seat_dispatch — task ANY body through ONE interface (2026-08-25, self-steal).  Operator: "there's got to be a better way to use these things." The better way:` (B) | routing / dispatch |
| ask_router | `python -m mag.ask_router` | `ask_router - the missing controller: outcome-ledger-driven ask routing.  Thin rib in the Mag flywheel. Composes existing organs by subprocess, never imports:` (B) | routing + outcome-memory |
| fuel_feed | `python -m mag.fuel_feed` | origin empty in `B`; in `A` (fabric node `fuel`): `Free-lane mill.`; imports ribs `work_contract` + `lane_cadence` (A, fabric.json edges) | scheduling (cadence) |
| lane_cadence | `python -m mag.lane_cadence` | `lane_cadence — learn the right rhythm for the free lanes (2026-08-25).  Operator: "okay so we need to figure out the right cadence for it" (the free lanes).` (B) | scheduling |
| work_contract | `python -m mag.work_contract` | `work_contract — the UNIVERSAL brief + result contract for every seat (v1, 2026-08-24).  WHERE THIS CAME FROM: we asked every seat how it wants to be interacted with (the OX lesson` (B) | contract / sequencing (brief→result) |
| swarm_cycle | `python -m mag.swarm_cycle` | origin empty (B); present as import-rib of `dnd` in fabric.json edges/mermaid | sequencing / reconciliation |
| party_subchain | `python -m mag.party_subchain` | `party_subchain — seat-to-seat talk without a shared window.  Parent is the main verkle tip (last_leaf_hash / root). Child is an append-only` (B); import-rib of `dnd` (A) | sequencing / routing (between seats) |
| governor_autorun | `python -m mag.governor_autorun` | `Intelligent governor autorun — fill queue, plan, route, execute.  The drainer (MAG_DRAINER=1) runs this loop instead of blind orchestrator drain:` (B) | goal-setting + sequencing + routing + scheduling (end-to-end loop) |
| self_drive_cadence | `python -m mag.self_drive_cadence` | `Self-drive cadence job — agent-state-aware ask planning, live in the autorun loop.  Runs on the governor cadence (MAG_SELF_DRIVE_EVERY). It picks the next pending intent from the` (B) | goal-setting + scheduling |
| afk_orchestrator | `python -m mag.afk_orchestrator` | `afk_orchestrator — run the whole AFK advance stack as ONE ghost-routed cadence.  The operator: "we have so much scaffolding — look at what remains and rightsize it,` (B) | orchestration / sequencing |
| afk_cadence | `python -m mag.afk_cadence` | `afk_cadence — ONE ghost-routed AFK loop running the whole self-advance machine.  Automates the refined loop: when the operator is AFK, run the pieces as a single` (B) | orchestration / scheduling |
| agent_state_router | `python -m mag.agent_state_router` | `Agent-state-aware ROUTING — the custom agent state that auto-selects resources.  Distinct from mag/agent_state.py (the MEMORY recall-edge pack). This is the ROUTING side of the` (B) | routing |
| backlog_reform | `python -m mag.backlog_reform` | `backlog_reform — address a queued backlog INTELLIGENTLY through the new systems.  The operator's directive (2026-08-09): the 87-task backlog must be "addressed intelligently` (B) | scheduling / sequencing |
| flock_scheduler | `python -m mag.flock_scheduler` | `flock_scheduler — map a batch of queued tasks onto the swarm via field-steering.  THE TESUJI: the swarm allocates work EMERGENTLY instead of through the serial queue.` (B) | scheduling / routing |
| job_floor | `python -m mag.job_floor` | `Job floor — DFHack-style designation manager (layered on the orchestrator).  DFHack turns vague goals into DESIGNATIONS (precise, queued work dwarves execute` (B) | sequencing (vague→queued work) |
| orchestrator | `python -m mag.orchestrator` | origin empty (B) | sequencing / orchestration |
| queue_ops | `python -m mag.queue_ops` | `Queue ops — structured logger + error handler + auto-digest for the queue/drainer.  Complements the tier-based separate queues (orchestrator). Gives the ghost/drainer:` (B) | scheduling / queue |
| queue_learn | `python -m mag.queue_learn` | `Queue learning fold — treat every terminal queue item as a labeled training datapoint.  "The surface" worth training on: every done/failed queue item is a (task_shape, provider, model,` (B) | outcome-memory / reconciliation |
| queue_rightsize | `python -m mag.queue_rightsize` | `queue_rightsize — rightsize + dedup the orchestrator queue (cheapest capable tier, no overlap).  Lesson (2026-08-09): ~21,000 DeepSeek calls burned money because the queue ran` (B) | scheduling / reconciliation |
| guard_registry | `python -m mag.guard_registry` | `guard_registry — desired-state RECONCILER for every known fix (2026-08-10).  Operator law: "permanent fixes that you forget about are not fixes, they're future` (B) | reconciliation |
| research_worker | `python -m mag.research_worker` | `Bounded, non-interactive research seat for cheap local reconciliation work.  The generic ``main.py agent`` seat carries a large tool schema, an interactive` (B) | reconciliation |
| session_overseer | `python -m mag.session_overseer` | `Session-aware overseer — reads a VS Code session, extracts the ask, and decides whether to turn the drainer on and dispatch the introduced task. ` (B) | routing / dispatch |
| north_star | `python -m mag.north_star` | `north_star — the canonical build loop (operator north star, 2026-08-11).  Every build follows: STEAL -> REASON -> PLAN -> ELEVATE -> COORDINATE -> GATHER -> DETERMINISTIC CODE` (B) | goal-setting (canonical plan loop) |
| seat_registry | `python -m mag.seat_registry` | hit only via keyword `orchestrat`; orgin-empty scan in `B`; present as import-rib of `mermaid` in `A` — registry, not an executor (holds seats) | routing support |

Additional hits (keyword-matching only, not carved out above): `blade_plan`, `campaign`, `cost_simulator`, `drainer_stats`, `gap_routed_handoff`, `gap_task` (contract), `ghost_server` (contract), `gpu_ghost`, `grok_hub`, `hour_test`, `improve_loop`, `matrix_router`, `meta_*` (n/a), `off_hours`, `peer_handoff`, `pigeonhole`, `power`, `press_digest`, `provenance_router`, `real_swarm`, `research_director`, `resource_governor`, `rightsize_all`, `rightsize_api`, `route_trace`, `seeds`, `skill_pipeline`, `steal_pack`, `steer_router`, `steer_telemetry`, `swarm_surface`, `switchboard_v2`, `topic_orphan`, `tripartite_boot`, `voice_trigger`, `whisper_route`, `work_loop`, `x_posts_mine`, `x_surface`. Empty-origin scan entries (`swarm_cycle`, `orchestrator`, `queue_gate`, `queue_analysis`, `compute_reconcile`, `route_trace`, `fuel_feed`) exist as ids but carry no descriptive quote in the catalog.

## atlas / basecamp / elder — PRESENT or ABSENT

- **In `fabric.json` (crown, 17 nodes): ABSENT.** All three return false (verified: `fabric.json has "atlas": false`, `"basecamp": false`, `"elder": false`).
- **In `latest.json` → `scanned_extra` (608 scanned CLIs): PRESENT.**
  - `atlas` | `python -m mag.atlas` | `Atlas — the generated map of verified Mag organs.  Atlas is not a second registry. It compiles the receipts-first organ map and`
  - `basecamp` | `python -m mag.basecamp` | `Basecamp — the small climb controller around the evidence map.`
  - `elder` | `python -m mag.elder` | `Elder — deterministic audit seat for the generated organ map.  The elder reports and ranks evidence gaps; it does not become a second`
- Corroborating: directory `/mag/memory/runs/openclaw_catalog/` also holds `elder_brief.md`, `elder_missing.json` (elder audit output) — evidence these organs are real and active, but they are **not part of the fabric crown spine**.

## Verdict (5 lines)

1. **Yes — Mag already has a planning spine, but it is *distributed and bottom-heavy*, not a single governing spine.** The most complete planning-ish loop is `governor_autorun` ("fill queue, plan, route, execute") wired to `self_drive_cadence` ("agent-state-aware ask planning, live in the autorun loop"); every phase (goal→sequence→route→schedule) is covered by at least one organ, and `north_star` names the intended canonical loop.
2. **The crown/fabric spine (`fabric.json`) does NOT contain the planning organs.** `seat_dispatch`, `ask_router`, `fuel_feed`, `atlas`, `basecamp`, `elder`, `swarm_cycle`, `party_subchain` are all absent from the 17-node fabric; they live only in the 608-node `scanned_extra` (auto-scanned, `family:"scanned"`), so they are known but not verified/ribbed onto the crown — the catalog treats them as un-audited.
3. **Biggest structural gap: no converged objective/goal owner that sits across the routing/scheduling layers — no single "what are we building, in what order, toward what outcome" authority.** `north_star` names the loop (PLAN→COORDINATE) but is a doctrine/description, not a governing queue-rebalancer; `compute_reconcile` and `queue_rightsize` reconcile *cost/tier*, and `guard_registry` reconciles *fixes*, but nothing reconciles the *plan itself* against outcome memory.
4. **Best single candidate to confirm as the spine is `ask_router`** — explicitly "the missing controller: outcome-ledger-driven ask routing" that composes organs by subprocess — combined with `seat_dispatch` as the single task interface; but both are still scan-only, not crown.
5. **The single biggest planning gap: outcome-memory → plan reconciliation.** Organs *read* outcome/ledger (`ask_router` outcome-ledger, `queue_learn` treats done/failed items as training data, `guard_registry` desired-state) but the catalog shows **no organ that closes the loop from measured outcomes back into re-planning the build order** — the plan is made and dispatched, but nothing re-plans the plan from results.
