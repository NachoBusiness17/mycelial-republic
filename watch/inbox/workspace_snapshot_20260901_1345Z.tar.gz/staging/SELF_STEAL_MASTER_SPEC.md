# Self Steal Master Spec — Diamond Age Synthesis Systems

**Goal:** Take the 8-avenue analysis and staging code, build the missing pieces so MAG can self-operate its own control plane.

**Current state:** Switchboard exists as a blackboard write gate. Effect broker only implements `board_write`. All other effects (verkle_link, tool_invoke, model_call, network_access, fs_write, lane_spawn) are listed but have no broker. Self-granting. No operator gate. No TTL/budget enforcement. No queue. No lease. No sandbox.

**Target:** A self-stealing MAG control surface where:
- Every side effect routes through the effect broker
- The switchboard is a real reference monitor (not just a write gate)
- The operator remains the constitutional root
- Receipts are complete with postcondition evidence
- Policy is data, not code
- One end-to-end test proves it works

---

## Workstreams

### Track A: Effect Broker (highest priority)
Build `staging/effect_broker.py` — unified effect execution with:
- `execute(effect, params, authority)` — routes to correct broker
- `verkle_link(event_id, payload)` — wraps `mag.verkle_lance link` as mediated effect
- `tool_invoke(cmd_args, timeout, cwd)` — subprocess execution with sandbox (cwd locked to /mag or /board)
- `model_call(lane, prompt, max_tokens)` — mediated model invocation via seat_dispatch
- `network_access(url, method, max_bytes)` — mediated web fetch
- `fs_write(path, content, mode="write")` — filesystem write with allowlist
- `lane_spawn(task, model, timeout)` — mediated subagent spawn via OpenClaw sessions
- Postcondition evidence collection for every effect
- Receipt generation: `ENQUEUED → RUNNING → COMPLETED/FAILED → RECEIPT_COMMITTED`

**Security model:**
- Broker runs in the same process as switchboard (reference monitor co-location)
- Each broker checks `authority.status == AUTHORIZED` and `effect in authority.granted_capabilities`
- `fs_write` allowlist: only `/board/*`, `/patches/*`, `/memory/*`, `bridge/*`
- `tool_invoke` cwd lock: only `/mag`, `/board`, `/root/.openclaw/workspace`
- `network_access` denylist: localhost internals except explicit allowlist
- `model_call` budget check: decrement from authority.budget
- All effects produce a receipt dict with pre/post state hashes where applicable

### Track B: Policy Engine + Receipt Chain
Build `staging/policy_engine.py` and extend `switchboard.py`:
- Policy as JSON data in `memory/policy.json` (editable by operator without code change)
- TTL enforcement: `grant()` checks `proposal.ts + ttl_seconds > now()`
- Budget enforcement: `grant()` and `effect_broker.execute()` decrement budget counters
- Operator confirmation gate: for effects in `policy.require_confirmation` list, `grant()` returns `DEFERRED` instead of `AUTHORIZED`, writes to `bridge/operator_inbox.jsonl`, waits for operator `confirm` or `deny`
- Receipt chain state machine: every proposal moves through states
- `RECEIPT_COMMITTED` requires postcondition evidence
- `revoke(event_id)` — explicit capability revocation
- `expire()` — background sweep of expired proposals/capabilities

### Track C: Queue + Lease + Integration Harness
Build `staging/harness.py`:
- Reconciliation output becomes actionable queue in `memory/runs/queue.jsonl`
- Lease mechanism: when an organ claims a condition, it gets exclusive lease for N minutes
- `harness run --once` — one pass: read queue, check leases, grant capabilities, execute via effect broker, record receipts
- `harness test --scenario N` — predefined test scenarios:
  1. Simple board write (should pass)
  2. Tool invoke without authority (should fail closed)
  3. Operator-confirmation gate (should defer, then confirm)
  4. Budget exhaustion (should deny after N calls)
  5. TTL expiration (should revoke old capability)
  6. Consensus simulation (3 agents propose same action → higher priority)
  7. Full cycle: board → reconcile → queue → lease → grant → effect → receipt → verkle

---

## Integration Order

1. Track A (effect broker) must land first — it's the execution layer
2. Track B (policy + receipts) lands second — depends on broker for budget enforcement
3. Track C (harness + tests) lands third — exercises A+B together
4. Master integration: update `swarm_cycle.py` to use `effect_broker.execute()` for all steps instead of direct subprocess calls
5. Master integration: update `ask_router.py` to use `effect_broker.execute()` for verkle ties and ledger writes
6. Master integration: update `session_bridge.py` to post through switchboard for bridge mutations
7. End-to-end test: `python -m mag.harness test --scenario 7`

---

## Deliverables per track

Each track produces:
- One Python module in `staging/`
- One test/validation script
- Updated MEMORY.md entry describing what was built and its limitations
- Cross-reference to the 8-avenue analysis showing which gaps are closed

---

## Authority

All build actions carry authority label `operator-authored` (operator requested self-steal).
All outputs are `agent-generated` until operator confirms.
No effect execution in the build process itself — only file writes to `staging/`.
