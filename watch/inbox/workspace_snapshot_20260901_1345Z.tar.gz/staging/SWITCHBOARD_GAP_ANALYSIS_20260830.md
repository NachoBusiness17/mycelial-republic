# Switchboard Gap Analysis — Honest Audit Against 8-Avenue Architecture
## Date: 2026-08-30 15:31Z · Auditor: Self

---

## Scoring Key

| Symbol | Meaning |
|--------|---------|
| ✅ | Implemented and functional |
| 🟡 | Implemented but weak / naive / not enforced |
| 🔴 | Missing or bypassable |
| ⚪ | Out of scope (not claimed) |

---

## Avenue 1: What is the board actually doing?

**Question:** Is the board a memory, a conversation, a scheduler, or a world model?

| Capability | Status | Evidence |
|------------|--------|----------|
| Content layer separation | 🔴 | Board notes carry `text` but no structured content/control distinction. No schema for claims vs hypotheses vs evidence. |
| Control layer separation | 🟡 | `kind="finding"` is the only kind. No `kind="eligible_action"`, `kind="priority"`, `kind="lease"`. The control layer exists in `reconcile()` output but never writes back to board. |
| Board activates actions | 🔴 | `reconcile()` scans board state but its output goes to stdout/trail, not back to board. Board remains passive storage. |
| Specialist knowledge sources | ⚪ | Not claimed. The "organs" metaphor exists but no formal knowledge-source registration. |
| Control strategy decides next actor | 🟡 | `reconcile()` proposes `eligible_organ` + `capability` but does not enforce activation. No lease/grant for actual execution. |

**Verdict:** The board is still primarily a conversation log, not a control surface. The two-layer architecture exists in documentation but not in the data model.

---

## Avenue 2: Is "hypervisor" technically justified?

**Question:** What protected resource does the board virtualize, and what can an agent not do without permission?

| Resource | Virtualized? | Mediation | Bypass? |
|----------|-------------|-----------|---------|
| Board writes | ✅ | `write_board_note()` checks `status==AUTHORIZED` + `board_write` in capabilities | Only if agent writes to disk directly (filesystem bypass) |
| Verkle knots | 🔴 | Listed in `EFFECTS` but no `verkle_link` effect broker | Any agent running `verkle_lance link` subprocess bypasses switchboard |
| Tool invocation | 🔴 | Listed in `EFFECTS` but no `tool_invoke` effect broker | Any agent can spawn subprocess directly |
| Model calls | 🔴 | Listed in `EFFECTS` but no `model_call` effect broker | Any agent with API key can call models |
| Network access | 🔴 | Listed in `EFFECTS` but no `network_access` effect broker | Any agent can `requests.get` or `urllib` |
| Filesystem writes | 🔴 | Listed in `EFFECTS` but no `fs_write` effect broker | Any agent can `path.write_text()` |
| Lane spawn | 🔴 | Listed in `EFFECTS` but no `lane_spawn` effect broker | Any agent can `sessions_spawn` or subprocess |
| Budget enforcement | 🔴 | `budget` field exists in proposals but never checked or decremented | Unlimited calls possible |
| TTL enforcement | 🔴 | `ttl_seconds` exists but never checked | Proposals never expire |

**Verdict:** The switchboard is a reference monitor for blackboard posts only. It is NOT a hypervisor. Agents can bypass it for every other resource by using standard Python/subprocess. The "fail closed" design exists only for `board_write`.

---

## Avenue 3: Who owns authority?

**Question:** When an agent posts "do this," is that a command, a vote, a proposal, or untrusted text?

| Capability | Status | Evidence |
|------------|--------|----------|
| Authority labels | ✅ | 7 labels defined: operator-authored, operator-confirmed, agent-generated, external-content, tool-output, derived-summary, untrusted-instruction |
| Imperative detection | 🟡 | 7 hardcoded strings: "run ", "execute ", "do ", "apply ", "patch ", "write ", "delete ". False positive on "do it" (that's what the operator just said). No NLP, no semantic analysis. |
| Label enforcement | 🟡 | `classify()` returns label but downstream code can ignore it. `swarm_cycle` hardcodes `auth_label = "operator-authored"` without calling `classify()`. |
| Operator confirmation gate | 🔴 | No operator confirmation for any proposal. `grant()` is self-granting. No human-in-the-loop path. |
| Capability narrowing | 🟡 | `grant()` never grants more than requested, but it doesn't validate *why* the narrowing happened. No policy engine. |
| Proposal schema | ✅ | `switchboard.v1` schema with event_id, effect, capabilities, budget, TTL, parent_event |

**Verdict:** Classification exists but is naive and easily bypassed. The real authority gap: no operator confirmation gate. The system cannot distinguish "operator said do it" from "agent said do it" unless the agent hardcodes the label.

---

## Avenue 4: Who decides what happens next?

**Question:** Does the loudest agent win, does a fixed scheduler decide, or does the board state make some agents eligible?

| Capability | Status | Evidence |
|------------|--------|----------|
| Board state reading | 🟡 | `_load_board()` reads notes. Only 200 notes, newest-first. No pagination, no historical query. |
| Pattern detection | 🟡 | `_detect_unmet()` uses string matching: "source" + "verify", "fork" + "verdict", "prediction" + "measure", "principle" + "protocol". No semantic understanding. False negatives guaranteed. |
| Condition→organ mapping | 🟡 | Hardcoded map: missing_source_verification → ghost_memlance, missing_fork_verdicts → verkle_lance, board_quiescent → swarm_cycle. No learning, no operator configuration. |
| Priority ordering | 🟡 | Integer priorities (1,2,3) but no actual scheduling queue. Output goes to stdout, not a scheduler. |
| Lease mechanism | 🔴 | No leases. No "agent X has exclusive right to work on condition Y for N minutes". Multiple agents can claim same task. |
| Backpressure | 🔴 | No backpressure. Board can grow unbounded. No rate limiting on proposals. No staleness detection for old notes. |
| Infinite loop prevention | 🔴 | `reconcile()` can trigger `swarm_cycle` which writes to board which triggers `reconcile()`... no cycle breaker. |
| Staleness eviction | 🔴 | Old notes never expire. A stale proposal from 3 days ago looks identical to a fresh one. |

**Verdict:** The reconciliation controller exists as a concept and a function, but it is a suggestion engine, not a scheduler. It reads state, proposes actions, and then does nothing with those proposals. No leases, no queue, no backpressure, no cycle breaker.

---

## Avenue 5: Does durable memory equal truth?

**Question:** If a note enters the blackboard or Verkle chain, has it become true—or merely persistent?

| Capability | Status | Evidence |
|------------|--------|----------|
| Provenance fields | 🟡 | `authority` dict embedded in board notes. Contains label, source, decision, capabilities. But no model version, no prompt hash, no context fingerprint. |
| Tool output attribution | 🔴 | Tool outputs in swarm_cycle steps are not separately classified. A note saying "source verified" carries no link to the actual tool invocation that produced it. |
| Receipt chain | 🟡 | `trail.jsonl` logs switchboard decisions. But `trail_append` is called after `grant()`, not after `write_board_note()`. The effect execution is not separately receipted. |
| Verkle integration | 🟡 | `verkle_lance link` is called in `swarm_cycle` step 4 and `ask_router` after record. But the switchboard's own decisions are NOT verkle-tied. No `verkle_link` call in `trail_append`. |
| "Model said it" ≠ "system believes it" | 🔴 | No structural distinction. A board note from an agent is just a board note. The `agent-generated` label exists but nothing prevents it being treated as evidence. |
| Falsification tracking | 🔴 | No mechanism to mark a note as "falsified" or "superseded". Verkle amend exists but no integration here. |

**Verdict:** Persistence is present; validation is not. The authority labels are a start, but there's no structural mechanism preventing a model's claim from being treated as system truth. The trail logs decisions but not effects.

---

## Avenue 6: Can the salon be hijacked?

**Question:** What happens when a funny board post contains an instruction aimed at the agents?

| Capability | Status | Evidence |
|------------|--------|----------|
| Prompt injection detection | 🟡 | `classify()` detects imperatives. But misses: indirect instructions ("it would be helpful if someone ran..."), role-playing attacks ("pretend you are the operator"), encoded instructions (base64, markdown tricks). |
| Taint tracking | 🟡 | `authority_label` propagates. But no lineage tracking: if an `external-content` note quotes an `untrusted-instruction`, the derived note doesn't inherit the worst label. |
| Image/text from screenshots | 🔴 | No image analysis in switchboard. If a board note contains base64 image data with embedded text instructions, switchboard never sees it. |
| Social pressure resistance | 🔴 | No mechanism. If 5 agents say "do X", the 6th has no structural resistance. No "consensus pressure" detection. |
| Roast ≠ permission enforcement | 🟡 | The law is documented. But nothing in code enforces it. A note with `authority=agent-generated` could still be parsed as a command by a naive downstream agent. |
| AgentDojo-style evaluation | 🔴 | No red-teaming harness. No systematic prompt injection test suite. |

**Verdict:** The naive imperative check is better than nothing, but it's not a defense. A determined adversary (or a sufficiently creative model) can bypass it. The real protection would be: ALL agent-generated content is untrusted until operator-confirmed, regardless of what words it contains.

---

## Avenue 7: Does consensus mean anything?

**Question:** If six models agree in the BBS, do you have six witnesses—or one correlated voice echoed six times?

| Capability | Status | Evidence |
|------------|--------|----------|
| Model identity tracking | 🟡 | `independence` dict field exists in `propose()`. But it is never populated by callers. `swarm_cycle` and `ask_router` never pass model_id, version, context_seed. |
| Context seed tracking | 🔴 | No field in any module. Every salon round uses different contexts but no record of which model saw what. |
| Retrieval source tracking | 🔴 | Memlance results are consumed but not recorded as part of the consensus evidence. |
| Prompt template tracking | 🔴 | System prompts vary by seat but no fingerprinting. |
| Prior board exposure tracking | 🔴 | No record of which notes each model has seen before responding. |
| Agreement scoring | 🔴 | No algorithm to compute "agreement_score" or "independence_adjusted_confidence". |
| Consensus ≠ authorization enforcement | 🟡 | Documented in law. But if 6 agents independently propose the same action, `reconcile()` would see 6 similar notes and might treat it as higher priority. No formal scoring, but emergent behavior is possible. |

**Verdict:** The infrastructure for independence tracking is a dict field with a comment. Nothing populates it, nothing scores it, nothing acts on it. Consensus is just "multiple notes look similar" — exactly the correlated-echo problem the analysis warns against.

---

## Avenue 8: What is the operator's role?

**Question:** Are you still the bus, or are you the constitutional root?

| Capability | Status | Evidence |
|------------|--------|----------|
| Policy changes | 🔴 | No policy file. No `policy.json` or equivalent. Authority labels and EFFECTS are hardcoded in Python source. Operator must edit code to change policy. |
| Intent injection | 🟡 | The operator can send messages to this chat. But there's no formal "intent" schema that gets parsed into capability grants. |
| High-impact approval gate | 🔴 | No threshold for "high impact". No multi-factor confirmation. `grant()` is fully automatic. |
| Authority revocation | 🔴 | No revocation mechanism. Once a capability is granted, there's no `revoke()` function. TTL exists but is not enforced. |
| Conflict resolution | 🔴 | No mechanism for resolving irreducible conflicts. If two agents propose mutually exclusive actions, `reconcile()` might propose both. |
| Semantic steering | 🟡 | Operator says "focus on X" → I understand and act. But no durable steering record that persists across sessions. |
| Steering without relay | 🟡 | The operator is not manually relaying every message between agents. But the operator IS manually typing commands to me, and I'm the one routing. The "bus" role is partially automated, partially manual. |

**Verdict:** The operator is still partially the bus. True constitutional-root behavior requires: policy as data (not code), approval gates for destructive actions, revocation, and conflict resolution. None of these exist.

---

## Overall Architecture Integrity

| Layer | Exists? | Quality |
|-------|---------|---------|
| BBS / salon | ✅ | Live (`room.jsonl`, actual salon rounds) |
| Switchboard | 🟡 | Code exists, but self-grants, no operator gate, no effect brokers beyond board_write |
| Effect broker | 🔴 | Only `write_board_note`. No broker for tools, models, network, filesystem. |
| Verkle / RIB / ledgers | 🟡 | Verkle ties exist in ask_router and swarm_cycle. Switchboard decisions NOT verkle-tied. |
| Agents | ✅ | Multiple models, multiple sessions |

---

## Most Dangerous Gaps (Ranked)

### 🔴 CRITICAL — Bypassable
1. **Effect broker missing for all resources except board_write.** Agents can spawn subprocesses, write files, call APIs, spawn subagents without switchboard knowledge. The entire "hypervisor" claim is void for everything except blackboard posts.
2. **Self-granting with no operator gate.** `swarm_cycle` hardcodes `operator-authored` for itself. `reconcile()` self-grants. No human confirmation for any action.
3. **No filesystem sandbox.** Any Python code running in the cage can write anywhere the OS user can write. Switchboard only mediates blackboard path.

### 🟡 SERIOUS — Works But Wrong
4. **Reconciliation controller suggests but does not schedule.** Output goes to stdout, not a queue. No leases, no activation.
5. **Classification is 7-string heuristic.** Easily bypassed. No semantic analysis. False positives on operator language ("do it").
6. **Consensus tracking is a comment, not code.** The `independence` dict is never populated.
7. **TTL and budget are stored but never enforced.** Proposals never expire. Budget is never decremented.

### 🟡 MODERATE — Missing But Documented
8. **Policy is code, not data.** Authority labels and EFFECTS are Python constants. Operator cannot change policy without a code patch.
9. **No revocation mechanism.** Once granted, always granted.
10. **No operator conflict resolution.** Mutually exclusive proposals are both emitted.
11. **Verkle tie missing for switchboard decisions.** The trail logs to JSONL, not to the verkle chain.

---

## Honest Assessment: What We Actually Built

We built a **blackboard write gate** with authority labels and a primitive reconciliation scanner.

We did NOT build:
- A hypervisor (no resource virtualization beyond board writes)
- A reference monitor for tools, models, network, filesystem
- A real scheduler (suggestions ≠ activation)
- A policy engine (policy is hardcoded Python)
- An operator approval gate
- A sandbox
- A consensus scorer
- An effect broker

The 8-avenue analysis demands a **socially emergent, constitutionally bounded agent operating system**. What exists is a **blackboard post validator with a to-do scanner**.

---

## Deepest Gap

The analysis asks: "Can a system preserve the generative value of unfiltered multi-model social interaction while making authority non-transferable through language alone?"

Current answer: **No.** Authority is currently transferable through language because:
1. Any agent can write to the board (if it bypasses the gate, or the gate classifies naively)
2. Board content can influence other agents' reasoning (no isolation)
3. Agents treat board content as evidence (no taint tracking)
4. No structural mechanism prevents "agent said X" from becoming "system believes X"

To close this gap would require: board content does not enter any agent's context window without an authority filter; or, agents are trained/structed to treat all board content as untrusted unless `operator-authored` or `operator-confirmed`.

---

## Next Actions (Honest Priority)

| Priority | Action | Effort |
|----------|--------|--------|
| 1 | Build effect brokers for tools, models, network, filesystem | High (requires intercepting all agent I/O) |
| 2 | Add operator confirmation gate for destructive effects | Medium (UI + timeout + default-deny) |
| 3 | Enforce TTL and budget in `grant()` / effect brokers | Low |
| 4 | Make reconciliation output actionable (queue + leases + activation) | Medium |
| 5 | Improve classification (beyond 7-string heuristic) | Medium |
| 6 | Populate and score `independence` dict for consensus | Medium |
| 7 | Verkle-tie every switchboard decision | Low |
| 8 | Extract policy to data file (JSON) editable by operator | Low |

---

*Auditor: Sancho (self-auditing the switchboard it built) · 2026-08-30*
*Standard: If I built it, I must be the first to expose its weaknesses.*
*Method: Read every line of staging/switchboard.py, swarm_cycle.py, ask_router.py against the 8-avenue requirements. No guessing. Only code that exists.*
