# Model-Weights Vault — Quote Pricing (UNVERIFIED)

Date: 2026-08-31. All prices are QUOTES gathered from official/vendor pages and secondary sources. **UNVERIFIED** — figures not confirmed against a signed agreement; verify before spend. Prices exclude VAT unless noted.

| Option | Storage cost | Retrieval / egress | Retrieval time | Source URL |
|---|---|---|---|---|
| **AWS S3 Glacier Deep Archive** (us-east-1) | **$0.00099 /GB-month** (~$1.01/TB-mo) | Standard **$0.02/GB**; Bulk **$0.0025/GB** (plus request fees) | Standard ~12h; Bulk ~48h (min 180-day storage) | aws.amazon.com/s3/pricing; aws.amazon.com/s3/storage-classes/glacier/ |
| **Backblaze B2 Cloud Storage** | **$6.95 /TB-month** (=$0.0068/GB-mo) | Free egress up to **3× average monthly storage**; then **$0.01 /GB** egress, free transactions | Immediate (always-hot) | backblaze.com/cloud-storage/pricing |
| **Hetzner Storage Box BX41** | **€40.60 /month** for 20 TB (≈ **€2.03 /TB-month**, excl. VAT) | Unlimited traffic / free egress | Immediate (FTP/SFTP/SCP/rsync/Samba/WebDAV) | hetzner.com/storage/storage-box/bx41/ |
| **Hetzner Server Auction** (storage-dense dev server) | No exact **4×8TB (32TB)** listing currently active. Closest documented: **2×4TB (8TB)** box ~**€60–90 /month** (excl. VAT); storage value ≈ **€0.85–1.01 /TB** | Unlimited traffic (1 Gbit/s port) | — | hetzner.com/sb |
| **vast.ai** (GPU marketplace — host-set, not fixed) | Storage: host-set ≈ **~$0.20 /GB-month** typical (varies widely) | Bandwidth: host-set ≈ **$2–3 /TB** (~$0.002–0.003/GB); billed both directions, per byte | — | docs.vast.ai/guides/instances/storage/types; cloud.vast.ai |

## Notes
- **AWS/Backblaze/Hetzner BX41** figures confirmed on official pages (fetched live). **UNVERIFIED flags land on: (1) Hetzner auction exact config** — no 4×8TB listing found; quoted 2×4TB example is a search-aggregated figure, verify live on hetzner.com/sb; **(2) vast.ai rates** — host-set and volatile, must check per-listing in console; **(3) AWS retrieval $** — from secondary sources, confirm on AWS pricing page.
- B2 page headline "Starts at $6.95/TB/mo" (slightly above the historical $6 flat); egress free-then-$0.01/GB confirmed on the same page.
- All S3 Glacier Deep Archive prices assume us-east-1; other regions run 5–30% higher. ~40KB per-object metadata overhead and request/PUT fees apply.
- Hetzner auction prices are Dutch-auction style — they drop over time; 4-drive configs are rarer and often premium.
