#!/usr/bin/env python3
"""ask_router_v2 — ledger-driven routing WITH effect_broker integration.

Thin rib.  Every side effect routes through the reference monitor:
  tool_invoke  -> ghost_memlance (route-time grounded memory)
  verkle_link  -> verkle_lance (receipt to chain tip)
  fs_write     -> ledger append + route record
  model_call   -> stub (real wiring via seat_dispatch later)

Fallback: if effect_broker is absent, degrades to direct subprocess / disk write.
$0 by construction for the control plane; model calls are broker-stubbed.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEDGER_DIR = ROOT / "memory" / "runs" / "ask_router"
LEDGER = LEDGER_DIR / "ledger.jsonl"
CORPUS = ROOT / "memory" / "runs" / "seat_corpus" / "latest.json"

# $-tier fallback when seat_corpus is silent (0=free, 3=frontier)
LANE_TIERS = {
    "groq": 0, "openrouter": 0, "nvidia": 0, "cerebras": 0, "ollama": 0,
    "deepseek": 1, "zai": 2, "openai": 3, "anthropic": 3, "xai": 3,
}

# ---------------------------------------------------------------------------
# Import new control surface (soft-fail if not deployed yet)
# ---------------------------------------------------------------------------

try:
    import effect_broker as _eb
    _BROKER_OK = True
except Exception:
    _eb = None  # type: ignore
    _BROKER_OK = False


def _authority_for(effect: str, event_id: str, **extra) -> dict:
    """Build an operator-authored authority for ask_router steps."""
    return {
        "status": "AUTHORIZED",
        "granted_capabilities": [effect],
        "event_id": event_id,
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "ttl_seconds": 900,
        "budget": {"max_calls": 10},
        "source": "ask_router",
        "label": "operator-authored",
        **extra,
    }


def _eb_run(effect: str, params: dict, event_id: str) -> dict:
    """Execute via effect_broker if available; fall back to legacy subprocess."""
    if _BROKER_OK and _eb is not None:
        auth = _authority_for(effect, event_id)
        rec = _eb.execute(effect, params, auth)
        result = rec.get("result", {})
        return {
            "cmd": params.get("cmd", ["effect_broker", effect]),
            "rc": 0 if result.get("ok") else 1,
            "ok": result.get("ok", False),
            "json": result.get("json"),
            "head": (result.get("stdout") or result.get("body") or "")[:400],
            "err": (result.get("error") or "")[:200],
            "receipt": rec,
        }
    # Fallback: legacy subprocess
    cmd = params.get("cmd", [])
    timeout = params.get("timeout", 60)
    try:
        p = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, timeout=timeout,
                           encoding="utf-8", errors="replace")
        return {
            "cmd": " ".join(cmd),
            "rc": p.returncode,
            "ok": p.returncode == 0,
            "head": (p.stdout or "")[:400],
            "err": (p.stderr or "")[:200],
            "receipt": None,
        }
    except Exception as e:
        return {"cmd": " ".join(cmd), "rc": -1, "ok": False, "head": "", "err": str(e)[:200], "receipt": None}


def _eb_fs_write(path: Path, content: str, event_id: str) -> dict:
    """Write file via effect_broker fs_write or direct fallback."""
    if _BROKER_OK and _eb is not None:
        auth = _authority_for("fs_write", event_id)
        rec = _eb.execute("fs_write", {"path": str(path), "content": content}, auth)
        return rec.get("result", {})
    # Fallback
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return {"ok": True, "path": str(path), "fallback": True}


def _eb_verkle(event_id: str) -> dict:
    """Tie to verkle chain via effect_broker or direct fallback."""
    if _BROKER_OK and _eb is not None:
        auth = _authority_for("verkle_link", event_id)
        rec = _eb.execute("verkle_link", {"event_id": event_id}, auth)
        result = rec.get("result", {})
        return {
            "ok": result.get("ok", False),
            "rc": result.get("rc", -1),
            "head": (result.get("stdout") or "")[:400],
            "receipt": rec,
        }
    # Fallback
    return _eb_run("tool_invoke", {
        "cmd": [sys.executable, "-m", "mag.verkle_lance", "link", "--event", event_id],
        "timeout": 60,
    }, event_id)


# ---------------------------------------------------------------------------
# Legacy helpers (unchanged logic)
# ---------------------------------------------------------------------------

def load_ledger():
    rows = []
    if LEDGER.exists():
        for line in LEDGER.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                rows.append(json.loads(line))
            except Exception:
                pass
    return rows


def lane_stats(rows):
    st = {}
    for r in rows:
        lane = r.get("lane")
        if not lane:
            continue
        s = st.setdefault(lane, {"n": 0, "ok": 0, "cost": 0.0, "lat": 0.0, "last": 0})
        s["n"] += 1
        s["ok"] += 1 if r.get("ok") else 0
        s["cost"] += float(r.get("cost_usd") or 0)
        s["lat"] += float(r.get("latency_s") or 0)
        s["last"] = max(s["last"], int(r.get("ts") or 0))
    return st


def harvest_costs(corpus):
    out = {}
    if not isinstance(corpus, dict):
        return out
    hints = corpus.get("costs") or corpus.get("lanes") or {}
    if isinstance(hints, dict):
        for k, v in hints.items():
            if isinstance(v, (int, float)):
                out[k] = v
            elif isinstance(v, dict) and isinstance(v.get("cost_usd"), (int, float)):
                out[k] = v["cost_usd"]
    return out


def score_lane(lane, s, corpus_cost):
    ok_rate = (s["ok"] / s["n"]) if (s and s["n"]) else 0.5
    tier = corpus_cost.get(lane, LANE_TIERS.get(lane, 2))
    last = s["last"] if s else 0
    freshness = 1.0 / (1.0 + max(0, time.time() - last) / 86400.0)
    score = 100.0 * ok_rate - 10.0 * tier + 5.0 * freshness
    why = f"ok_rate={ok_rate:.2f} tier={tier} fresh={freshness:.2f}"
    if s and s["n"]:
        why += f" n={s['n']} avg_cost=${s['cost'] / s['n']:.4f} avg_lat={s['lat'] / s['n']:.1f}s"
    return round(score, 2), why


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_route(args):
    slug = time.strftime("%Y%m%d-%H%M%S")
    prompt = " ".join(args.prompt).strip()
    ev = f"ask_router:route:{slug}"
    rec = {
        "kind": "route", "ts": int(time.time()), "slug": slug, "dry": args.dry,
        "prompt_head": prompt[:160],
        "broker_ok": _BROKER_OK,
        "authority": _authority_for("route", ev),
    }

    # 1) grounded memory via tool_invoke broker
    if args.dry:
        mem = {"ok": False, "err": "dry: skipped", "receipt": None}
    else:
        mem = _eb_run("tool_invoke", {
            "cmd": [sys.executable, "-m", "mag.ghost_memlance",
                    "select", "--goal", prompt, "--k", str(args.k)],
            "timeout": 120,
        }, ev)
    rec["memlance"] = {
        "ok": bool(mem.get("ok")),
        "head": mem.get("head", "")[:200],
        "receipt": mem.get("receipt"),
    }

    # 2) corpus + ledger scoring (local math, no broker needed)
    corpus = {}
    try:
        corpus = json.loads(CORPUS.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        pass
    corpus_cost = harvest_costs(corpus)

    rows = load_ledger()
    st = lane_stats(rows)
    lanes = [l.strip() for l in args.lanes.split(",") if l.strip()] if args.lanes else \
        sorted(set(list(st.keys()) + list(LANE_TIERS.keys())))
    rank = []
    for lane in lanes:
        sc, why = score_lane(lane, st.get(lane), corpus_cost)
        rank.append({"lane": lane, "score": sc, "why": why})
    rank.sort(key=lambda x: -x["score"])
    rec["ledger_rows"] = len(rows)
    rec["lane_rank"] = rank
    rec["decision"] = {
        "cascade": [r["lane"] for r in rank],
        "frontier_judgment_lanes": [r["lane"] for r in rank
                                    if corpus_cost.get(r["lane"], LANE_TIERS.get(r["lane"], 2)) >= 2][:2],
    }

    # 3) verkle tie via broker
    if args.dry:
        tie = {"ok": False, "rc": 0, "head": "dry: skipped", "receipt": None}
    else:
        tie = _eb_verkle(ev)
    rec["verkle"] = {
        "ok": bool(tie.get("ok")),
        "rc": tie.get("rc"),
        "head": tie.get("head", "")[:200],
        "receipt": tie.get("receipt"),
    }

    # 4) persist route record via fs_write broker
    route_path = LEDGER_DIR / f"{slug}-route.json"
    _eb_fs_write(route_path, json.dumps(rec, indent=2, ensure_ascii=False), ev)

    print(json.dumps(rec, indent=2, ensure_ascii=False))
    return 0


def cmd_record(args):
    slug = time.strftime("%Y%m%d-%H%M%S")
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except Exception as e:
        print(json.dumps({"ok": False, "err": f"bad json: {e}"}))
        return 1

    ev = f"ask_router:record:{slug}:{payload.get('lane', 'unknown')}"
    authority = payload.get("authority") or {
        "label": payload.get("authority_label", "agent-generated"),
        "source": payload.get("source", "ask_router"),
        "decision": "AUTO",
        "granted_capabilities": ["ledger_write", "verkle_link"],
    }
    row = {
        "kind": "outcome", "ts": int(time.time()), "slug": slug,
        "lane": payload.get("lane"), "ok": bool(payload.get("ok")),
        "cost_usd": float(payload.get("cost_usd") or 0),
        "latency_s": float(payload.get("latency_s") or 0),
        "task_head": (payload.get("task") or "")[:160],
        "authority": authority,
        "broker_ok": _BROKER_OK,
    }

    # persist ledger row
    LEDGER_DIR.mkdir(parents=True, exist_ok=True)
    ledger_content = json.dumps(row, ensure_ascii=False) + "\n"
    ledger_result = _eb_fs_write(LEDGER, ledger_content, ev)
    if not ledger_result.get("ok") and _BROKER_OK:
        # Fallback append if broker failed
        with LEDGER.open("a", encoding="utf-8") as f:
            f.write(ledger_content)

    # verkle tie
    tie = _eb_verkle(f"ask_router:record:{slug}:{row['lane']}")
    print(json.dumps({
        "ok": True, "row": row, "broker_ok": _BROKER_OK,
        "verkle": {"ok": bool(tie.get("ok")), "receipt": tie.get("receipt")},
        "ledger": ledger_result,
    }, indent=2, ensure_ascii=False))
    return 0


def main():
    ap = argparse.ArgumentParser(prog="mag.ask_router")
    ap.add_argument("prompt", nargs="*", help="the ask to size/route")
    ap.add_argument("--dry", action="store_true",
                    help="no subprocess calls: pure local ledger math")
    ap.add_argument("--k", type=int, default=4, help="memlance hits")
    ap.add_argument("--lanes", default="", help="CSV lane override")
    ap.add_argument("--record", action="store_true",
                    help="read outcome JSON on stdin -> ledger + verkle tie")
    args = ap.parse_args()
    if args.record:
        sys.exit(cmd_record(args))
    if not " ".join(args.prompt).strip():
        print(json.dumps({"ok": False, "err": "need a prompt"}))
        sys.exit(1)
    sys.exit(cmd_route(args))


if __name__ == "__main__":
    main()
