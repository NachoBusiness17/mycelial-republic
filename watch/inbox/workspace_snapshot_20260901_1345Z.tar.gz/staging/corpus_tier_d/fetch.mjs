import { writeFileSync } from 'fs';

const [, , url, out] = process.argv;
const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (research corpus grab)' }, redirect: 'follow' });
if (!res.ok) { console.error(`HTTP ${res.status} ${url}`); process.exit(1); }
const buf = Buffer.from(await res.arrayBuffer());
writeFileSync(out, buf);
console.log(`OK ${res.status} ${buf.length} bytes -> ${out}`);
