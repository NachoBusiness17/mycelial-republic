import { createHash } from 'crypto';
import { readFileSync } from 'fs';
const f = process.argv[2];
const b = readFileSync(f);
console.log(JSON.stringify({file:f, sha256:createHash('sha256').update(b).digest('hex'), bytes:b.length}));
