// deepseek_month_analysis.mjs — Aug 2-31 2026 billing (operator CSVs)
const rows = [
// [day, model, key, type, price, amount]  type: hit|miss|out|req
["08-02","flash","Mag","hit",2.8e-9,131846400],["08-02","flash","Mag","miss",1.4e-7,5498113],["08-02","flash","Mag","req",0,4492],["08-02","flash","Mag","out",2.8e-7,1821881],
["08-03","flash","Mag","hit",2.8e-9,174709760],["08-03","flash","Mag","miss",1.4e-7,6249596],["08-03","flash","Mag","req",0,4555],["08-03","flash","Mag","out",2.8e-7,2547308],
["08-03","flash","Overmind","hit",2.8e-9,12672],["08-03","flash","Overmind","miss",1.4e-7,145],["08-03","flash","Overmind","req",0,2],["08-03","flash","Overmind","out",2.8e-7,65],
["08-04","flash","Mag","hit",2.8e-9,82480768],["08-04","flash","Mag","miss",1.4e-7,2386860],["08-04","flash","Mag","req",0,2365],["08-04","flash","Mag","out",2.8e-7,743436],
["08-04","flash","Overmind","hit",2.8e-9,132864],["08-04","flash","Overmind","miss",1.4e-7,244],["08-04","flash","Overmind","req",0,3],["08-04","flash","Overmind","out",2.8e-7,63],
["08-05","flash","Mag","hit",2.8e-9,3868544],["08-05","flash","Mag","miss",1.4e-7,648833],["08-05","flash","Mag","req",0,586],["08-05","flash","Mag","out",2.8e-7,125766],
["08-06","flash","Mag","hit",2.8e-9,10642048],["08-06","flash","Mag","miss",1.4e-7,288124],["08-06","flash","Mag","req",0,285],["08-06","flash","Mag","out",2.8e-7,107720],
["08-07","pro","Mag","miss",4.35e-7,960],["08-07","pro","Mag","req",0,10],["08-07","pro","Mag","out",8.7e-7,5362],
["08-07","pro","Swarm","hit",3.625e-9,126543616],["08-07","pro","Swarm","miss",4.35e-7,5070202],["08-07","pro","Swarm","req",0,516],["08-07","pro","Swarm","out",8.7e-7,483493],
["08-07","flash","Mag","hit",2.8e-9,18877056],["08-07","flash","Mag","miss",1.4e-7,715857],["08-07","flash","Mag","req",0,732],["08-07","flash","Mag","out",2.8e-7,233705],
["08-07","flash","Overmind","miss",1.4e-7,718],["08-07","flash","Overmind","req",0,1],["08-07","flash","Overmind","out",2.8e-7,1177],
["08-07","flash","Swarm","hit",2.8e-9,254872832],["08-07","flash","Swarm","miss",1.4e-7,5079441],["08-07","flash","Swarm","req",0,981],["08-07","flash","Swarm","out",2.8e-7,922562],
["08-08","pro","Mag","hit",3.625e-9,7900032],["08-08","pro","Mag","miss",4.35e-7,210823],["08-08","pro","Mag","req",0,250],["08-08","pro","Mag","out",8.7e-7,103125],
["08-08","pro","Swarm","hit",3.625e-9,378318848],["08-08","pro","Swarm","miss",4.35e-7,9266002],["08-08","pro","Swarm","req",0,1811],["08-08","pro","Swarm","out",8.7e-7,1459167],
["08-08","flash","Mag","hit",2.8e-9,474857856],["08-08","flash","Mag","miss",1.4e-7,3639224],["08-08","flash","Mag","req",0,4721],["08-08","flash","Mag","out",2.8e-7,1199678],
["08-08","flash","Swarm","hit",2.8e-9,309893120],["08-08","flash","Swarm","miss",1.4e-7,5917928],["08-08","flash","Swarm","req",0,1492],["08-08","flash","Swarm","out",2.8e-7,1272039],
["08-09","pro","Mag","hit",3.625e-9,6085120],["08-09","pro","Mag","miss",4.35e-7,225998],["08-09","pro","Mag","req",0,263],["08-09","pro","Mag","out",8.7e-7,78444],
["08-09","pro","Swarm","hit",3.625e-9,2855424],["08-09","pro","Swarm","miss",4.35e-7,15932],["08-09","pro","Swarm","req",0,10],["08-09","pro","Swarm","out",8.7e-7,12301],
["08-09","flash","Mag","hit",2.8e-9,234484480],["08-09","flash","Mag","miss",1.4e-7,3028771],["08-09","flash","Mag","req",0,3748],["08-09","flash","Mag","out",2.8e-7,956062],
["08-09","flash","Overmind","hit",2.8e-9,2570368],["08-09","flash","Overmind","miss",1.4e-7,95711],["08-09","flash","Overmind","req",0,156],["08-09","flash","Overmind","out",2.8e-7,30549],
["08-09","flash","Swarm","hit",2.8e-9,882466688],["08-09","flash","Swarm","miss",1.4e-7,15854571],["08-09","flash","Swarm","req",0,3904],["08-09","flash","Swarm","out",2.8e-7,3322135],
["08-10","flash","Mag","hit",2.8e-9,19707904],["08-10","flash","Mag","miss",1.4e-7,228884],["08-10","flash","Mag","req",0,499],["08-10","flash","Mag","out",2.8e-7,67310],
["08-10","flash","Swarm","hit",2.8e-9,787095552],["08-10","flash","Swarm","miss",1.4e-7,12406381],["08-10","flash","Swarm","req",0,3696],["08-10","flash","Swarm","out",2.8e-7,2681356],
["08-11","flash","Swarm","hit",2.8e-9,627355136],["08-11","flash","Swarm","miss",1.4e-7,6520069],["08-11","flash","Swarm","req",0,2284],["08-11","flash","Swarm","out",2.8e-7,1942768],
["08-12","flash","Swarm","hit",2.8e-9,573944448],["08-12","flash","Swarm","miss",1.4e-7,7586526],["08-12","flash","Swarm","req",0,2138],["08-12","flash","Swarm","out",2.8e-7,1641063],
["08-13","flash","Swarm","hit",2.8e-9,376125696],["08-13","flash","Swarm","miss",1.4e-7,6507543],["08-13","flash","Swarm","req",0,1816],["08-13","flash","Swarm","out",2.8e-7,1180625],
["08-14","flash","Swarm","hit",2.8e-9,181005312],["08-14","flash","Swarm","miss",1.4e-7,2367604],["08-14","flash","Swarm","req",0,852],["08-14","flash","Swarm","out",2.8e-7,636908],
["08-15","flash","Swarm","hit",2.8e-9,334122240],["08-15","flash","Swarm","miss",1.4e-7,5034715],["08-15","flash","Swarm","req",0,1359],["08-15","flash","Swarm","out",2.8e-7,989821],
["08-16","pro","Swarm","hit",2.2e-8,5760],["08-16","pro","Swarm","miss",6.6e-7,14669],["08-16","pro","Swarm","req",0,10],["08-16","pro","Swarm","out",1.98e-6,8215],
["08-16","flash","Swarm","hit",2.8e-9,121600640],["08-16","flash","Swarm","hit",7e-9,176365056],["08-16","flash","Swarm","hit",1.4e-8,2368128],
["08-16","flash","Swarm","miss",1.4e-7,2824198],["08-16","flash","Swarm","miss",2.2e-7,3919443],["08-16","flash","Swarm","miss",4.4e-7,4058],
["08-16","flash","Swarm","req",0,1793],["08-16","flash","Swarm","out",2.8e-7,469344],["08-16","flash","Swarm","out",6.6e-7,436743],["08-16","flash","Swarm","out",1.32e-6,4515],
["08-17","pro","Swarm","hit",2.2e-8,59218944],["08-17","pro","Swarm","miss",6.6e-7,270313],["08-17","pro","Swarm","req",0,533],["08-17","pro","Swarm","out",1.98e-6,63227],
["08-17","flash","Swarm","hit",7e-9,156045568],["08-17","flash","Swarm","hit",1.4e-8,58704768],["08-17","flash","Swarm","miss",2.2e-7,3081480],["08-17","flash","Swarm","miss",4.4e-7,1955092],
["08-17","flash","Swarm","req",0,1140],["08-17","flash","Swarm","out",6.6e-7,269725],["08-17","flash","Swarm","out",1.32e-6,136351],
["08-18","flash","Swarm","hit",7e-9,104033536],["08-18","flash","Swarm","miss",2.2e-7,1752140],["08-18","flash","Swarm","req",0,372],["08-18","flash","Swarm","out",6.6e-7,272873],
["08-19","flash","Swarm","hit",7e-9,63254016],["08-19","flash","Swarm","miss",2.2e-7,1328088],["08-19","flash","Swarm","req",0,190],["08-19","flash","Swarm","out",6.6e-7,153313],
["08-20","flash","Swarm","hit",7e-9,31697920],["08-20","flash","Swarm","miss",2.2e-7,1198031],["08-20","flash","Swarm","req",0,164],["08-20","flash","Swarm","out",6.6e-7,151509],
["08-21","flash","Swarm","hit",7e-9,33834752],["08-21","flash","Swarm","hit",1.4e-8,13186944],["08-21","flash","Swarm","miss",2.2e-7,1004909],["08-21","flash","Swarm","miss",4.4e-7,388277],
["08-21","flash","Swarm","req",0,228],["08-21","flash","Swarm","out",6.6e-7,153040],["08-21","flash","Swarm","out",1.32e-6,36285],
["08-22","flash","Swarm","hit",7e-9,205983104],["08-22","flash","Swarm","miss",2.2e-7,2393205],["08-22","flash","Swarm","req",0,756],["08-22","flash","Swarm","out",6.6e-7,646963],
["08-23","flash","Swarm","hit",7e-9,488432896],["08-23","flash","Swarm","hit",1.4e-8,59635456],["08-23","flash","Swarm","miss",2.2e-7,6052632],["08-23","flash","Swarm","miss",4.4e-7,418517],
["08-23","flash","Swarm","req",0,2993],["08-23","flash","Swarm","out",6.6e-7,1341452],["08-23","flash","Swarm","out",1.32e-6,172862],
["08-24","pro","Swarm","miss",6.6e-7,1982],["08-24","pro","Swarm","req",0,4],["08-24","pro","Swarm","out",1.98e-6,2503],
["08-24","flash","Swarm","hit",7e-9,458527616],["08-24","flash","Swarm","hit",1.4e-8,16364544],["08-24","flash","Swarm","miss",2.2e-7,6646278],["08-24","flash","Swarm","miss",4.4e-7,219904],
["08-24","flash","Swarm","req",0,1767],["08-24","flash","Swarm","out",6.6e-7,1167182],["08-24","flash","Swarm","out",1.32e-6,96455],
["08-25","vision","Swarm","miss",2.2e-7,414],["08-25","vision","Swarm","req",0,2],["08-25","vision","Swarm","out",6.6e-7,105],
["08-25","flash","Swarm","hit",7e-9,307331968],["08-25","flash","Swarm","hit",1.4e-8,82173184],["08-25","flash","Swarm","miss",2.2e-7,10511846],["08-25","flash","Swarm","miss",4.4e-7,5453434],
["08-25","flash","Swarm","req",0,3234],["08-25","flash","Swarm","out",6.6e-7,1243402],["08-25","flash","Swarm","out",1.32e-6,443249],
["08-26","vision","Swarm","miss",2.2e-7,275],["08-26","vision","Swarm","miss",4.4e-7,113],["08-26","vision","Swarm","req",0,4],["08-26","vision","Swarm","out",6.6e-7,81],["08-26","vision","Swarm","out",1.32e-6,24],
["08-26","pro","Swarm","miss",6.6e-7,497],["08-26","pro","Swarm","req",0,1],["08-26","pro","Swarm","out",1.98e-6,1500],
["08-26","flash","Swarm","hit",7e-9,114589824],["08-26","flash","Swarm","hit",1.4e-8,23947648],["08-26","flash","Swarm","miss",2.2e-7,12814530],["08-26","flash","Swarm","miss",4.4e-7,1111997],
["08-26","flash","Swarm","req",0,2689],["08-26","flash","Swarm","out",6.6e-7,732446],["08-26","flash","Swarm","out",1.32e-6,253242],
["08-27","vision","Swarm","miss",4.4e-7,825],["08-27","vision","Swarm","req",0,3],["08-27","vision","Swarm","out",1.32e-6,350],
["08-27","flash","Swarm","hit",7e-9,17567104],["08-27","flash","Swarm","hit",1.4e-8,2367488],["08-27","flash","Swarm","miss",2.2e-7,1198170],["08-27","flash","Swarm","miss",4.4e-7,208492],
["08-27","flash","Swarm","req",0,1708],["08-27","flash","Swarm","out",6.6e-7,414740],["08-27","flash","Swarm","out",1.32e-6,47290],
["08-28","pro","Swarm","hit",2.2e-8,256],["08-28","pro","Swarm","miss",6.6e-7,3398],["08-28","pro","Swarm","req",0,9],["08-28","pro","Swarm","out",1.98e-6,2482],
["08-28","flash","Swarm","hit",7e-9,9063424],["08-28","flash","Swarm","hit",1.4e-8,1065600],["08-28","flash","Swarm","miss",2.2e-7,679084],["08-28","flash","Swarm","miss",4.4e-7,94082],
["08-28","flash","Swarm","req",0,882],["08-28","flash","Swarm","out",6.6e-7,168984],["08-28","flash","Swarm","out",1.32e-6,26216],
["08-29","pro","Swarm","miss",6.6e-7,1476],["08-29","pro","Swarm","req",0,4],["08-29","pro","Swarm","out",1.98e-6,512],
["08-29","flash","Swarm","hit",7e-9,22199936],["08-29","flash","Swarm","miss",2.2e-7,1686624],["08-29","flash","Swarm","req",0,1964],["08-29","flash","Swarm","out",6.6e-7,465556],
["08-30","pro","Swarm","hit",2.2e-8,4833152],["08-30","pro","Swarm","hit",4.4e-8,1250432],["08-30","pro","Swarm","miss",6.6e-7,582207],["08-30","pro","Swarm","miss",1.32e-6,121006],
["08-30","pro","Swarm","req",0,133],["08-30","pro","Swarm","out",1.98e-6,108776],["08-30","pro","Swarm","out",3.96e-6,60420],
["08-30","flash","Swarm","hit",7e-9,115459200],["08-30","flash","Swarm","hit",1.4e-8,9965056],["08-30","flash","Swarm","miss",2.2e-7,2767431],["08-30","flash","Swarm","miss",4.4e-7,915435],
["08-30","flash","Swarm","req",0,4177],["08-30","flash","Swarm","out",6.6e-7,559445],["08-30","flash","Swarm","out",1.32e-6,171716],
["08-31","flash","Swarm","hit",7e-9,13042816],["08-31","flash","Swarm","hit",1.4e-8,4569088],["08-31","flash","Swarm","miss",2.2e-7,1164352],["08-31","flash","Swarm","miss",4.4e-7,347675],
["08-31","flash","Swarm","req",0,1048],["08-31","flash","Swarm","out",6.6e-7,248082],["08-31","flash","Swarm","out",1.32e-6,63198],
];
const costs = [
["08-02","flash",1.64903242],["08-03","flash",2.0774509896],["08-04","flash",0.7736924496],["08-05","flash",0.1368830232],["08-06","flash",0.1002966944],
["08-07","pro",3.089979928],["08-07","flash",1.9020262464],["08-08","pro",6.881656355],["08-08","flash",4.2273847728],["08-09","pro",0.216597172],["08-09","flash",6.9981766008],
["08-10","flash",4.7976132568],["08-11","flash",3.2133790808],["08-12","flash",3.1286557344],["08-13","flash",2.2947829688],["08-14","flash",1.0166136736],["08-15","flash",1.917552252],
["08-16","pro",0.02607396],["08-16","flash",3.293268176],["08-17","pro",1.606412808],["08-17","flash",3.810353628],["08-18","flash",1.293801732],["08-19","flash",0.836144052],
["08-20","flash",0.5854482],["08-21","flash",0.96228494],["08-22","flash",2.395382408],["08-23","flash",6.883189336],["08-24","pro",0.00626406],["08-24","flash",5.895396568],
["08-25","vision",0.00016038],["08-25","flash",9.419599432],["08-26","vision",0.00019536],["08-26","pro",0.00329802],["08-26","flash",5.26356492],["08-27","vision",0.000825],
["08-27","flash",0.84759964],["08-28","pro",0.007162672],["08-28","flash",0.415291488],["08-29","pro",0.00198792],["08-29","flash",0.833723792],
["08-30","pro",1.159972572],["08-30","flash",2.555250224],["08-31","flash",0.811556864],
];
const f=(x,n=2)=>x.toFixed(n);
let T={cost:0,req:0,out:0,hit:0,miss:0};
costs.forEach(c=>T.cost+=c[2]);
rows.forEach(r=>{if(r[3]==="req")T.req+=r[5];else if(r[3]==="out")T.out+=r[5];else if(r[3]==="hit")T.hit+=r[5];else T.miss+=r[5];});
console.log("1) TOTALS: cost=$"+f(T.cost)+"  req="+T.req+"  out="+f(T.out,0)+"  hit="+f(T.hit,0)+"  miss="+f(T.miss,0)+"  hitrate="+(100*T.hit/(T.hit+T.miss)).toFixed(2)+"%");
// by key (reconstructed cost)
const byKey={};
rows.forEach(r=>{const[d,m,k,t,p,a]=r;if(t==="req")return;const c=a*p;byKey[k]=byKey[k]||{cost:0};byKey[k].cost+=c;});
console.log("2a) BY KEY (recon cost): "+Object.entries(byKey).map(([k,v])=>k+"=$"+f(v.cost)).join("  "));
const byModel={};
costs.forEach(c=>{byModel[c[1]]=byModel[c[1]]||{cost:0};byModel[c[1]].cost+=c[2];});
console.log("2b) BY MODEL (billed cost): "+Object.entries(byModel).map(([m,v])=>m+"=$"+f(v.cost)).join("  "));
// daily totals
const daily={};
costs.forEach(c=>{daily[c[0]]=(daily[c[0]]||0)+c[2];});
const dArr=Object.entries(daily).sort((a,b)=>a[0]<b[0]?-1:1);
const top3=[...dArr].sort((a,b)=>b[1]-a[1]).slice(0,3);
console.log("3) TOP-3 DAYS: "+top3.map(d=>d[0]+"=$"+f(d[1])).join("  "));
// repricing: distinct prices per (model,type)
const pp={};
rows.forEach(r=>{if(r[3]==="req")return;const k=r[1]+"."+r[3];pp[k]=pp[k]||{};pp[k][r[4]]=pp[k][r[4]]||{first:r[0],last:r[0],n:0};pp[k][r[4]].last=r[0];pp[k][r[4]].n++;});
console.log("4) PRICE POINTS:");
Object.entries(pp).forEach(([k,v])=>{console.log("   "+k+": "+Object.entries(v).map(([p,s])=>p+" ["+s.first+".."+s.last+" n="+s.n+"]").join(" | "));});
// fidelity checks
function recon(day){let s=0;rows.forEach(r=>{if(r[0]===day&&r[3]!=="req")s+=r[5]*r[4];});return s;}
[["08-05",0.1368830232],["08-22",2.395382408],["08-30",1.159972572+2.555250224]].forEach(([day,billed])=>{const r=recon(day);console.log("5) "+day+" recon=$"+f(r,6)+" billed=$"+f(billed,6)+" dev="+(100*Math.abs(r-billed)/billed).toFixed(4)+"%");});
// pre vs post
function win(a,b){let c=0,q=0,o=0;costs.forEach(x=>{if(x[0]>=a&&x[0]<=b)c+=x[2];});rows.forEach(r=>{if(r[0]>=a&&r[0]<=b){if(r[3]==="req")q+=r[5];if(r[3]==="out")o+=r[5];}});return{c,q,o};}
const pre=win("08-02","08-15"),post=win("08-17","08-24");
console.log("6) PRE 08-02..15: cost=$"+f(pre.c)+" req="+pre.q+" c/req=$"+f(pre.c/pre.q,5)+" c/1Mout=$"+f(1e6*pre.c/pre.out));
console.log("   POST 08-17..24: cost=$"+f(post.c)+" req="+post.q+" c/req=$"+f(post.c/post.q,5)+" c/1Mout=$"+f(1e6*post.c/post.out));
// late trend
const late=["08-27","08-28","08-29","08-30","08-31"].reduce((s,d)=>s+daily[d],0)/5;
const peak=dArr.reduce((m,d)=>d[1]>m[1]?d:m,dArr[0]);
console.log("7) LATE AVG (08-27..31)=$"+f(late)+"  vs PEAK "+peak[0]+"=$"+f(peak[1])+"  drop="+(100*(1-late/peak[1])).toFixed(1)+"%");
console.log("8) RUN-RATE last-5: $"+f(late*30)+"/30d  (08-31 partial-day caveat)");
// counterfactual: post-08-16 traffic at OLD sheet
const old={flash:{hit:2.8e-9,miss:1.4e-7,out:2.8e-7},pro:{hit:3.625e-9,miss:4.35e-7,out:8.7e-7},vision:{hit:0,miss:2.2e-7,out:6.6e-7}};
let actual=0,cf=0;
rows.forEach(r=>{if(r[0]<"08-16")return;const[d,m,k,t,p,a]=r;if(t==="req")return;actual+=a*p;cf+=a*old[m][t];});
console.log("9) HIKE IMPACT 08-16..31: actual=$"+f(actual)+"  if old sheet=$"+f(cf)+"  delta=$"+f(actual-cf)+"  x"+f(actual/cf,2));
