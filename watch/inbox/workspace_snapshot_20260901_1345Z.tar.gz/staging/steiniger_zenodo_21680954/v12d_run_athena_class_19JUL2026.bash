#!/bin/bash

./build/bin/llama-server -m models/v12d_athena_class_Q8_0_19JUL2026.gguf --mmproj models/mmproj-BF16.gguf --host 0.0.0.0 --port 8080 -ngl 999 -c 262144 --flash-attn on --cache-type-k q8_0 --cache-type-v q8_0 -sm layer -ts 3,3,1,1,1 -np 1 --batch-size 256 --ubatch-size 256 --threads 10 --context-shift --metrics