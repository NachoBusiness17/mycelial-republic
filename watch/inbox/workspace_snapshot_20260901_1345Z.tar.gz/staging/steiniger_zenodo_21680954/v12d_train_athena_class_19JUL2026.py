#!/usr/bin/env python3
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "4,3,2,1,0"
#os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import torch
from unsloth import FastModel
from trl import SFTTrainer, SFTConfig
from datasets import load_dataset
from unsloth.chat_templates import get_chat_template

# ================== YOUR PARAMETERS ==================
MODEL_NAME = "unsloth/gemma-4-31B-it"
DATASET_PATH = "./v11_dataset_athena_class_12JUL2026.jsonl"
OUTPUT_DIR = "./v12d_athena_class_adapter_19JUL2026"
MAX_SEQ_LENGTH = 8192
RANK = 288
ALPHA = 576
# ====================================================

print("🚀 Loading Gemma 4 31B on 2×3090 + 3×3060...")

max_memory = {4: "12GiB", 3: "12GiB", 2: "12GiB", 1: "24GiB", 0: "24GiB"}

model, tokenizer = FastModel.from_pretrained(
    model_name = MODEL_NAME,
    max_seq_length = MAX_SEQ_LENGTH,
    dtype = None,
    load_in_4bit = True,
    device_map = "balanced",
    max_memory = max_memory,
#   comment out "force_download" in the future
#    force_download = True,
#    unsloth_tiled_mlp = True,
)

tokenizer = get_chat_template(tokenizer, chat_template = "gemma-4-thinking")

def formatting_func(examples):
    texts = []
    for convo in examples["messages"]:
        text = tokenizer.apply_chat_template(
            convo,
            tokenize=False,
            add_generation_prompt=True   # ← This adds the "model is about to speak" token
        )
        texts.append(text)
    return {"text": texts}

print("📚 Loading and formatting dataset...")
dataset = load_dataset("json", data_files=DATASET_PATH, split="train")
dataset = dataset.map(formatting_func, batched=True, num_proc=8)

# ========== DEBUG: Show exactly what the model sees ==========
print("\n" + "="*80)
print("SAMPLE FORMATTED TEXT (first example — first 1200 characters)")
print("="*80)
print(dataset[0]["text"][:1200])
print("...")
print("="*80 + "\n")

model = FastModel.get_peft_model(
    model,
    finetune_vision_layers     = False,
    finetune_language_layers   = True,
    finetune_attention_modules = True,
    finetune_mlp_modules       = True,
    r = RANK,
    lora_alpha = ALPHA,
#    lora_dropout = 0.04,
    bias = "none",
    use_gradient_checkpointing = "unsloth",
    random_state = 3407,
)

trainer = SFTTrainer(
    model = model,
    tokenizer = tokenizer,
    train_dataset = dataset,
    args = SFTConfig(
        dataset_text_field = "text",
        per_device_train_batch_size = 1,
        gradient_accumulation_steps = 6,
        warmup_steps = 25,
        num_train_epochs = 2,
        learning_rate = 1.2e-5,
        bf16 = torch.cuda.is_bf16_supported(),
        logging_steps = 1,
        optim = "adamw_8bit",
        weight_decay = 0.05,
        lr_scheduler_type = "cosine",
        seed = 3407,
        output_dir = OUTPUT_DIR,
        report_to = "none",
        save_strategy = "steps",
        save_steps = 40,
    ),
)

print("🔥 Starting training...")
trainer.train()

model.save_pretrained(OUTPUT_DIR)
tokenizer.save_pretrained(OUTPUT_DIR)
print(f"✅ Done! Adapter saved to {OUTPUT_DIR}")