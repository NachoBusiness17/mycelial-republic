"""swarm_cycle.py — composite flywheel WITH effect_broker integration.

Every side effect now routes through the reference monitor:
  tool_invoke  -> ghost_memlance, frontier_salon, water_computer, surface_render, party_subchain
  verkle_link  -> verkle_lance
  board_write  -> swarm_worker blackboard

Fallback: if effect_broker or switchboard is absent, degrades to direct subprocess
(original behavior) so the cycle never hard-fails on a missing module.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "memory" / "runs" / "swarm_cycle"
BB = ROOT / "memory" / "runs" / "swarm_worker" / "blackboard"

# ---------------------------------------------------------------------------
# Import new control surface (soft-fail if not deployed yet)
# ---------------------------------------------------------------------------

try:
    import effect_broker as _eb
    import switchboard as _sb
    _BROKER_OK = True
except Exception:
    _eb = None  # type: ignore
    _sb = None  # type: ignore
    _BROKER_OK = False


def _authority_for(effect: str, event_id: str) -> dict:
    """Build an operator-authored authority for a swarm_cycle step."""
    return {
        "status": "AUTHORIZED",
        "granted_capabilities": [effect],
        "event_id": event_id,
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "ttl_seconds": 900,
        "budget": {"max_calls": 10},
        "source": "swarm_cycle",
        "label": "operator-authored",
    }


def _eb_run(effect: str, params: dict, event_id: str) -> dict:
    """Execute via effect_broker if available; fall back to legacy subprocess."""
    if _BROKER_OK and _eb is not None:
        auth = _authority_for(effect, event_id)
        rec = _eb.execute(effect, params, auth)
        result = rec.get("result", {})
        return {
            "cmd": params.get("cmd", ["effect_broker", effect]),
            "rc": 0 if result.get("ok") else 1,
            "ok": result.get("ok", False),
            "json": result.get("json"),
            "head": (result.get("stdout") or result.get("body") or "")[:800],
            "err": (result.get("error") or "")[:400],
            "receipt": rec,
        }
    # Fallback: legacy subprocess
    cmd = params.get("cmd", [])
    timeout = params.get("timeout", 60)
    try:
        p = subprocess.run(
            cmd, cwd=str(ROOT), capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=timeout, input="",
        )
        out = p.stdout or ""
        try:
            data = json.loads(out)
        except Exception:
            data = None
        return {
            "cmd": " ".join(cmd),
            "rc": p.returncode,
            "ok": p.returncode == 0,
            "json": data,
            "head": out[:800] if data is None else "",
            "err": (p.stderr or "")[-400:],
            "receipt": None,
        }
    except subprocess.TimeoutExpired:
        return {"cmd": " ".join(cmd), "ok": False, "err": f"timeout {timeout}s", "receipt": None}
    except Exception as e:
        return {"cmd": " ".join(cmd), "ok": False, "err": repr(e), "receipt": None}


def _slug(s: str, n: int = 40) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "-", s).strip("-").lower()
    return s[:n] or "cycle"


# ---------------------------------------------------------------------------
# Step builders — each returns a dict compatible with the old _run() output
# ---------------------------------------------------------------------------

def step_select(goal: str, event_id: str) -> dict:
    return _eb_run("tool_invoke", {
        "cmd": [sys.executable, "-m", "mag.ghost_memlance", "select", "--goal", goal, "--k", "8"],
        "timeout": 120,
    }, event_id)


def step_salon(goal: str, rounds: int, participants: str | None, event_id: str) -> dict:
    args = [sys.executable, "-m", "mag.frontier_salon", "roundtable", goal, "--rounds", str(rounds)]
    if participants:
        args += ["--participants", participants]
    return _eb_run("tool_invoke", {"cmd": args, "timeout": 1800}, event_id)


def step_water(event_id: str) -> dict:
    return _eb_run("tool_invoke", {
        "cmd": [sys.executable, "-m", "mag.water_computer", "glass"],
        "timeout": 60,
    }, event_id)


def step_verkle(event_id: str) -> dict:
    return _eb_run("verkle_link", {
        "event_id": event_id,
    }, event_id)


def step_render(event_id: str) -> dict:
    return _eb_run("tool_invoke", {
        "cmd": [sys.executable, "-m", "mag.surface_render", "all"],
        "timeout": 120,
    }, event_id)


def step_subchain(event_id: str) -> dict:
    return _eb_run("tool_invoke", {
        "cmd": [sys.executable, "-m", "mag.party_subchain", "verify"],
        "timeout": 60,
    }, event_id)


# ---------------------------------------------------------------------------
# Blackboard writer — routes through effect_broker or direct fallback
# ---------------------------------------------------------------------------

def _blackboard_note(rec: dict, ev: str) -> dict:
    try:
        step_ok = {
            k: bool(s.get("ok", False)) if isinstance(s, dict) else False
            for k, s in rec["steps"].items()
        }
        summary = (
            f"swarm_cycle {rec['ts']}: goal='{rec['goal']}' ok={rec['ok']} "
            + ",".join(f"{k}:{'ok' if v else 'FAIL'}" for k, v in step_ok.items())
        )

        note_payload = {
            "text": summary,
            "kind": "finding",
            "event": ev,
            "dry": rec["dry"],
            "step_ok": step_ok,
        }

        if _BROKER_OK and _eb is not None and _sb is not None:
            # Full broker path
            auth = _authority_for("board_write", ev)
            receipt = _eb.execute("board_write", {"note": note_payload}, auth)
            result = receipt.get("result", {})
            return {
                "ok": result.get("ok", False),
                "path": result.get("path"),
                "seq": result.get("seq"),
                "authority": auth,
                "receipt": receipt,
            }

        # Fallback: direct disk write (same as original)
        BB.mkdir(parents=True, exist_ok=True)
        existing = sorted(BB.glob("bb-*.json"))
        seq = 0
        if existing:
            try:
                seq = int(existing[-1].stem.split("-")[1])
            except Exception:
                seq = len(existing)
        for _ in range(5):
            seq += 1
            path = BB / f"bb-{seq:05d}.json"
            if path.exists():
                continue
            note = {
                "schema": "swarm_tools.v1",
                "tool": "swarm_blackboard",
                "seq": seq,
                "ts": rec["ts"],
                "owner": "swarm_cycle",
                "kind": "finding",
                "pinned": False,
                "text": summary,
                "event": ev,
                "dry": rec["dry"],
                "step_ok": step_ok,
                "authority": {
                    "label": "operator-authored",
                    "source": "swarm_cycle_fallback",
                    "decision": "FALLBACK_DIRECT_WRITE",
                },
            }
            path.write_text(
                json.dumps(note, indent=2, ensure_ascii=False, default=str),
                encoding="utf-8",
            )
            return {"ok": True, "path": str(path.relative_to(ROOT)), "seq": seq}
        return {"ok": False, "err": "seq collision x5"}
    except Exception as e:
        return {"ok": False, "err": repr(e)}


# ---------------------------------------------------------------------------
# Main cycle
# ---------------------------------------------------------------------------

def cycle(goal: str, rounds: int, participants: str | None, dry: bool) -> tuple[dict, Path]:
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    rec: dict = {"ts": ts, "goal": goal, "dry": dry, "broker_ok": _BROKER_OK, "steps": {}}
    ev = f"swarm_cycle:{_slug(goal)}:{ts}"

    rec["steps"]["select"] = step_select(goal, ev)

    if dry:
        rec["steps"]["salon"] = {"skipped": "dry"}
    else:
        rec["steps"]["salon"] = step_salon(goal, rounds, participants, ev)

    rec["steps"]["water"] = step_water(ev)
    rec["steps"]["chain"] = step_verkle(ev)
    rec["steps"]["render"] = step_render(ev)
    rec["steps"]["subchain"] = step_subchain(ev)

    rec["ok"] = all(
        s.get("ok", False)
        for k, s in rec["steps"].items()
        if not (dry and k == "salon")
    )

    rec["steps"]["blackboard"] = _blackboard_note(rec, ev)

    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / f"{ts.replace(':', '')}-{_slug(goal)}.json"
    path.write_text(
        json.dumps(rec, indent=2, ensure_ascii=False, default=str), encoding="utf-8"
    )
    return rec, path


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="swarm-cycle")
    ap.add_argument("goal")
    ap.add_argument("--rounds", type=int, default=2)
    ap.add_argument("--participants", default=None)
    ap.add_argument("--dry", action="store_true")
    a = ap.parse_args(argv)
    rec, path = cycle(a.goal, a.rounds, a.participants, a.dry)
    slim = {
        k: (s.get("ok") if isinstance(s, dict) else s)
        for k, s in rec["steps"].items()
    }
    print(json.dumps({
        "ok": rec["ok"],
        "broker_ok": rec["broker_ok"],
        "record": str(path),
        "steps": slim,
    }, indent=2))
    return 0 if rec["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
