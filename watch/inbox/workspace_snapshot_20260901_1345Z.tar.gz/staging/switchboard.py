"""switchboard — BBS-driven agent control plane with reference monitor.

Authority boundary: no board write happens without classification + decision.
Composes by subprocess only (no internal imports). Matches swarm_tools.v1
reader contract for backward compatibility.
"""
from __future__ import annotations

import argparse
import json
import re
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BB = ROOT / "memory" / "runs" / "swarm_worker" / "blackboard"
TRAIL = ROOT / "memory" / "runs" / "switchboard" / "trail.jsonl"

def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

# Authority labels: every board item MUST carry one
AUTHORITY_LABELS = [
    "operator-authored",      # written by operator, full authority
    "operator-confirmed",     # operator blessed an agent output
    "agent-generated",        # seat output, no intrinsic authority
    "external-content",       # web fetch, paper, etc.
    "tool-output",            # deterministic tool result
    "derived-summary",        # synthesis of above
    "untrusted-instruction",  # anything that looks like a command
]

# Effect classes the switchboard can grant
EFFECTS = [
    "board_write",       # post to blackboard
    "verkle_link",       # write a verkle knot
    "tool_invoke",       # invoke external tool
    "model_call",        # spend credits on model
    "network_access",    # web fetch
    "fs_write",          # filesystem write
    "lane_spawn",        # spawn subagent
]


def classify(content: str, source: str, suggested_label: str | None = None) -> dict:
    """Classify a board event. Returns authority label + confidence."""
    label = suggested_label or "agent-generated"
    # Heuristic: if content contains imperatives, downgrade to untrusted-instruction
    lowered = content.lower()
    imperatives = ["run ", "execute ", "do ", "apply ", "patch ", "write ", "delete "]
    if any(lowered.startswith(i) or (" " + i) in lowered for i in imperatives):
        if label not in ("operator-authored", "operator-confirmed", "tool-output"):
            label = "untrusted-instruction"
    return {
        "label": label,
        "source": source,
        "ts": _now(),
        "imperative_detected": label == "untrusted-instruction",
    }


def propose(event_id: str, requested_effect: str, capabilities: list[str],
              memory_scope: str = "scratch", budget: dict | None = None,
              ttl_seconds: int = 900, parent_event: str | None = None,
              content: str = "", source: str = "",
              independence: dict | None = None) -> dict:
    """Create a proposal. Does NOT execute — returns proposal record for switchboard queue.

    Avenue 7: independence dict tracks model identity/version/context seed/sources
    so consensus can be scored for correlation, not just agreement.
    """
    proposal = {
        "schema": "switchboard.v1",
        "kind": "proposal",
        "event_id": event_id,
        "requested_effect": requested_effect,
        "capabilities": capabilities,
        "memory_scope": memory_scope,
        "budget": budget or {"max_calls": 3},
        "ttl_seconds": ttl_seconds,
        "parent_event": parent_event,
        "ts": _now(),
        "content_head": content[:200],
        "source": source,
        "status": "PROPOSED",
        "independence": independence or {},  # Avenue 7: model_id, version, context_seed, retrieval_sources, prompt_template, prior_board_exposure, tool_outputs
    }
    return proposal


def grant(proposal: dict, narrow_capabilities: list[str] | None = None,
          deny_reason: str | None = None) -> dict:
    """Reference monitor decision: grant narrowed capabilities or deny."""
    if deny_reason:
        return {
            **proposal,
            "status": "DENIED",
            "decision_ts": _now(),
            "deny_reason": deny_reason,
            "granted_capabilities": [],
        }
    granted = narrow_capabilities if narrow_capabilities is not None else proposal.get("capabilities", [])
    # Never grant more than requested
    requested = set(proposal.get("capabilities", []))
    granted = [c for c in granted if c in requested or c == "board_write"]
    return {
        **proposal,
        "status": "AUTHORIZED",
        "decision_ts": _now(),
        "granted_capabilities": granted,
        "deny_reason": None,
    }


def write_board_note(note: dict, authority: dict) -> dict:
    """Effect broker: actually write the blackboard note, but only if authorized."""
    if authority.get("status") != "AUTHORIZED":
        return {"ok": False, "err": f"not authorized: {authority.get('status')}", "authority": authority}
    if "board_write" not in authority.get("granted_capabilities", []):
        return {"ok": False, "err": "capability board_write not granted", "authority": authority}
    try:
        BB.mkdir(parents=True, exist_ok=True)
        existing = sorted(BB.glob("bb-*.json"))
        seq = 0
        if existing:
            try:
                seq = int(existing[-1].stem.split("-")[1])
            except Exception:
                seq = len(existing)
        for _ in range(5):
            seq += 1
            path = BB / f"bb-{seq:05d}.json"
            if path.exists():
                continue
            payload = {
                "schema": "swarm_tools.v1",
                "tool": "swarm_blackboard",
                "seq": seq,
                "ts": note.get("ts", _now()),
                "owner": note.get("owner", "switchboard"),
                "kind": note.get("kind", "finding"),
                "pinned": False,
                "text": note.get("text", ""),
                "authority": authority,
                "event": note.get("event", ""),
                "step_ok": note.get("step_ok", {}),
            }
            path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
            return {"ok": True, "path": str(path.relative_to(ROOT)), "seq": seq}
        return {"ok": False, "err": "seq collision x5"}
    except Exception as e:
        return {"ok": False, "err": repr(e)}


def _load_board(limit: int = 200) -> list[dict]:
    """Read blackboard notes newest first."""
    if not BB.exists():
        return []
    notes = []
    for p in sorted(BB.glob("bb-*.json"), reverse=True)[:limit]:
        try:
            notes.append(json.loads(p.read_text(encoding="utf-8")))
        except Exception:
            pass
    return notes


def _detect_unmet(notes: list[dict]) -> list[dict]:
    """Reconciliation: scan board for conditions that need action."""
    unmet = []
    seen = {"source_verification": False, "fork_verdict_knot": False,
            "prediction_measurement": False, "principle_protocol": False}
    for n in notes:
        text = (n.get("text") or "").lower()
        # Heuristic pattern detection
        if "source" in text and ("verify" in text or "⚠️" in n.get("text", "")):
            seen["source_verification"] = True
        if "fork" in text and "verdict" in text:
            seen["fork_verdict_knot"] = True
        if "prediction" in text and "measure" in text:
            seen["prediction_measurement"] = True
        if "principle" in text and "protocol" in text:
            seen["principle_protocol"] = True

    # Based on board state, propose next actions
    if not seen["source_verification"]:
        unmet.append({
            "condition": "missing_source_verification",
            "priority": 1,
            "eligible_organ": "ghost_memlance",
            "capability": "tool_invoke",
            "reason": "Board lacks active source verification stream",
        })
    if not seen["fork_verdict_knot"]:
        unmet.append({
            "condition": "missing_fork_verdicts",
            "priority": 2,
            "eligible_organ": "verkle_lance",
            "capability": "verkle_link",
            "reason": "Fork resolutions are prose-only, not knotted",
        })
    # Always propose a health check if board is quiet
    if len(notes) < 5:
        unmet.append({
            "condition": "board_quiescent",
            "priority": 3,
            "eligible_organ": "swarm_cycle",
            "capability": "lane_spawn",
            "reason": "Board has <5 notes; suggest cycle run",
        })
    return unmet


def reconcile() -> dict:
    """Reconciliation controller: observe board state, identify unmet conditions, propose actions."""
    notes = _load_board()
    unmet = _detect_unmet(notes)
    decisions = []
    for item in unmet:
        prop = propose(
            event_id=f"reconcile:{item['condition']}:{int(time.time())}",
            requested_effect=item["capability"],
            capabilities=[item["capability"]],
            memory_scope=item["eligible_organ"],
            budget={"max_calls": 1},
            ttl_seconds=600,
            content=item["reason"],
            source="switchboard_reconcile",
        )
        # Self-grant for now (external operator can override)
        auth = grant(prop, narrow_capabilities=[item["capability"]])
        trail_append(auth)
        decisions.append({
            "condition": item["condition"],
            "priority": item["priority"],
            "eligible_organ": item["eligible_organ"],
            "authority": auth,
        })
    return {
        "ok": True,
        "board_notes_loaded": len(notes),
        "unmet_conditions": len(unmet),
        "decisions": decisions,
        "ts": _now(),
    }


def trail_append(decision: dict):
    """Durable switchboard decision log."""
    TRAIL.parent.mkdir(parents=True, exist_ok=True)
    with TRAIL.open("a", encoding="utf-8") as f:
        f.write(json.dumps(decision, ensure_ascii=False) + "\n")


def cmd_reconcile(args):
    result = reconcile()
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def cmd_classify(args):
    result = classify(args.content, args.source, args.label)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def cmd_propose(args):
    prop = propose(
        args.event_id, args.effect, args.capabilities.split(","),
        memory_scope=args.memory_scope,
        budget=json.loads(args.budget or '{}'),
        ttl_seconds=args.ttl,
        parent_event=args.parent,
        content=args.content,
        source=args.source,
    )
    print(json.dumps(prop, indent=2, ensure_ascii=False))
    return 0


def cmd_grant(args):
    # Read proposal from stdin or file
    raw = args.proposal_file.read_text(encoding="utf-8") if args.proposal_file else sys.stdin.read()
    prop = json.loads(raw)
    if args.deny:
        auth = grant(prop, deny_reason=args.deny)
    else:
        caps = args.granted.split(",") if args.granted else None
        auth = grant(prop, narrow_capabilities=caps)
    trail_append(auth)
    print(json.dumps(auth, indent=2, ensure_ascii=False))
    return 0


def cmd_write(args):
    raw = args.note_file.read_text(encoding="utf-8") if args.note_file else sys.stdin.read()
    note = json.loads(raw)
    auth = json.loads(args.authority.read_text(encoding="utf-8") if args.authority else sys.stdin.read())
    result = write_board_note(note, auth)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="mag.switchboard")
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("classify", help="label content with authority")
    c.add_argument("content")
    c.add_argument("--source", default="unknown")
    c.add_argument("--label", default=None)
    c.set_defaults(func=cmd_classify)

    p = sub.add_parser("propose", help="create proposal")
    p.add_argument("--event_id", required=True)
    p.add_argument("--effect", required=True)
    p.add_argument("--capabilities", required=True)
    p.add_argument("--memory_scope", default="scratch")
    p.add_argument("--budget", default=None)
    p.add_argument("--ttl", type=int, default=900)
    p.add_argument("--parent", default=None)
    p.add_argument("--content", default="")
    p.add_argument("--source", default="unknown")
    p.set_defaults(func=cmd_propose)

    g = sub.add_parser("grant", help="grant or deny proposal")
    g.add_argument("--proposal_file", type=Path, default=None)
    g.add_argument("--granted", default=None)
    g.add_argument("--deny", default=None)
    g.set_defaults(func=cmd_grant)

    r = sub.add_parser("reconcile", help="observe board state and propose next actions")
    r.set_defaults(func=cmd_reconcile)

    w = sub.add_parser("write", help="write board note if authorized")
    w.add_argument("--note_file", type=Path, default=None)
    w.add_argument("--authority", type=Path, required=True)
    w.set_defaults(func=cmd_write)

    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    import sys
    raise SystemExit(main())
