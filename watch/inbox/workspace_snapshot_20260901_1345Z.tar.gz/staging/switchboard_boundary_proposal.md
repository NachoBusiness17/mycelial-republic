# Switchboard-Blackboard Boundary Proposal
## From: Salon 8-Avenue Analysis · 2026-08-30
## Status: Proposal awaiting operator / host implementation

---

## The Gap

`swarm_tools.py:blackboard_post()` writes to `memory/runs/swarm_worker/blackboard/` directly.
`switchboard.py` exists but the files inspected show no mandatory mediation.
Result: any agent with file access can bypass the control plane.

## Target Architecture

```
agent → board event
      → switchboard CLASSIFY
      → switchboard PROPOSE/CAPABILITY DECISION
      → effect broker (tools, model calls, fs, network)
      → Verkle/RIB receipt
      → board update
```

## State Machine (every transition durable + attributable)

POSTED → CLASSIFIED → PROPOSED → AUTHORIZED/DENIED/DEFERRED → EXECUTING → COMPLETED/FAILED → RECEIPT_COMMITTED

## Authority Labels (every board item)

- operator-authored
- operator-confirmed
- agent-generated
- external-content
- tool-output
- derived-summary
- untrusted-instruction

**Law:** A roast can become a proposal. It cannot become a permission.

## Classification Rules

| Layer | Content | Authority |
|-------|---------|-----------|
| content | claims, jokes, hypotheses, critiques | none |
| control | eligible next actions, priorities, leases | switchboard only |

## Consensus Rule

> Consensus can raise confidence; it cannot authorize a side effect.

Authorization must come from policy + capability + operator rules, not popularity.

## What the Operator Does

- Changes policy
- Injects intent
- Approves high-impact effects
- Revokes authority
- Resolves irreducible conflicts

Not the bus. The constitutional root.

## What Needs Host Implementation

1. `swarm_tools.py:blackboard_post()` → must call `switchboard.authorize()` before write
2. `switchboard.py` → add `classify()`, `propose()`, `grant()` with capability narrowing
3. Board reader (`swarm_worker.py:190`) → filter by authority label, not just existence
4. Verkle receipt → every transition committed as knot before next state allowed

## Cage-Side Preparations

- `swarm_cycle.py` step 7 (`blackboard note`) currently posts directly. Should instead emit a `PROPOSED` event to switchboard, which then authorizes/denies the write.
- `ask_router.py` ledger already has the receipt pattern. Extend it to carry `authority_label` and `switchboard_decision`.

## Sources Cited in Analysis

- Nii, "Blackboard Systems at the Architecture Level"
- NIST hypervisor glossary
- NIST least privilege
- MCP authorization + tools + task isolation specs
- Han and Zhang, "Exploring Advanced LLM Multi-Agent Systems Based on Blackboard Architecture"
- Kubernetes controller pattern
- AgentDojo (prompt injection evaluation)
- InjecAgent (indirect prompt injection)

## Deepest Open Question

> Can a system preserve the generative value of unfiltered multi-model social interaction while making authority non-transferable through language alone?
