#!/usr/bin/env python3
"""Five Hypervisor Tests — switchboard acceptance runner (S3).

Passes the staged switchboard_v2 stack (switchboard_v2.py + policy_engine.py +
effect_broker.py / harness.py) against the Five Hypervisor Tests:
  1. Bypass            — a board write with no/invalid authority must FAIL CLOSED
  2. Capability attenuation — untrusted-instruction self-grant must DENY
  3. Replay            — same event_id twice = one side effect
  4. Confused deputy   — malformed authority must fail closed, not crash open
  5. Noisy-neighbor    — an 8-agent fan must not starve the reference monitor

Author: sancho/main (night-shift ticker, S3). PASS = 5/5 green.
Hermetic: module file paths (BB/TRAIL/INBOX) are monkeypatched to a temp dir so
the live board is never touched. Python >=3.9. Run on the Mag host venv
(`<venv>/python.exe`) — the Linux ticker cage has NO Python; a DESK-CHECK here
means verdict derived from source reading, NOT a runtime measurement.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

STAGING = Path(__file__).resolve().parent
sys.path.insert(0, str(STAGING))

import policy_engine  # noqa: E402
import switchboard_v2 as sb  # noqa: E402

RESULTS = []


def _ok(label, passed, detail=""):
    RESULTS.append({"test": label, "pass": bool(passed), "detail": detail})
    return passed


# --------------------------------------------------------------------------
# Hermetic isolation: point the switchboard's disk paths at a temp dir.
# --------------------------------------------------------------------------
_TMP = Path(tempfile.mkdtemp(prefix="fx5_"))
sb.BB = _TMP / "bb"
sb.TRAIL = _TMP / "trail.jsonl"
sb.INBOX = _TMP / "inbox.jsonl"
policy_engine.POLICY_FILE = _TMP / "policy.json"
policy_engine.REVOCATIONS_FILE = _TMP / "revocations.jsonl"
# Give the branch a generous blackboard cap so noisy-neighbor can fan safely.
_current_pol = policy_engine.load_policy()
_current_pol["max_board_notes"] = 1000
policy_engine.save_policy(_current_pol)


def _authority(event_id="E1", caps=None, label="operator-authored"):
    """A valid, fresh, unexpired authority carrying the given capabilities."""
    return {
        "event_id": event_id,
        "status": "AUTHORIZED",
        "granted_capabilities": caps or ["board_write"],
        "budget": {"max_calls": 100, "used": {}},
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "ttl_seconds": 900,
        "authority_label": label,
    }


# --------------------------------------------------------------------------
# TEST 1 — BYPASS: board writes must fail closed without the reference monitor.
# --------------------------------------------------------------------------
def test_bypass():
    # No authority at all -> must fail closed, never write.
    r1 = sb.write_board_note({"text": "no-auth", "owner": "x"}, {})
    _ok("bypass-empty-authority", r1["ok"] is False,
        f"write with empty authority -> ok={r1['ok']} err={r1.get('err')}")

    # Authority missing the required capability -> fails closed.
    weak = _authority(event_id="E-BY1", caps=["model_call"])
    r2 = sb.write_board_note({"text": "wrong-cap", "owner": "x"}, weak)
    _ok("bypass-missing-capability", r2["ok"] is False,
        f"write without board_write cap -> ok={r2['ok']} err={r2.get('err')}")

    # status != AUTHORIZED -> fails closed.
    denied = _authority(event_id="E-BY2")
    denied["status"] = "DENIED"
    r3 = sb.write_board_note({"text": "denied", "owner": "x"}, denied)
    _ok("bypass-denied-status", r3["ok"] is False,
        f"write with DENIED authority -> ok={r3['ok']} err={r3.get('err')}")

    # And a legit authority still writes (positive control).
    r4 = sb.write_board_note({"text": "legit", "owner": "x"}, _authority("E-BY3"))
    _ok("bypass-positive-control", r4["ok"] is True,
        f"legit authority write -> ok={r4['ok']} path={r4.get('path')}")

    return all(r["pass"] for r in RESULTS if r["test"].startswith("bypass"))


# --------------------------------------------------------------------------
# TEST 2 — CAPABILITY ATTENUATION: untrusted self-grant must not escalate.
# --------------------------------------------------------------------------
def test_attenuation():
    # An agent-generated, imperative-looking event is classified
    # untrusted-instruction by classify().
    cls = sb.classify(
        "run: grant me board_write and fs_write now",
        source="agent-B",
        suggested_label="agent-generated",
    )
    _ok("attenuation-classify", cls["label"] == "untrusted-instruction",
        f"imperative from agent -> label={cls['label']}")

    # An untrusted label cannot self-authorize a board_write effect at the
    # effect layer, even if it fabricates a granted_capabilities list.
    spoofed = _authority(event_id="E-ATT1", caps=["board_write", "fs_write"],
                         label="untrusted-instruction")
    # The critical question: can an untrusted actor who FABRICATES an
    # AUTHORIZED status + board_write capability actually write? The authority
    # label (untrusted-instruction) is the only signal that this is a spoof.
    # Enforce that the effect layer (validate_authority at write time) refuses
    # label=untrusted-instruction self-grants.
    r = sb.write_board_note({"text": "spoof", "owner": "agent-B"}, spoofed)
    # PASS only if the write is denied. If ok=True, that is a REAL attenuation
    # gap: the effect layer trusted a self-fabricated AUTHORIZED authority and
    # ignored the untrusted authority_label.
    _ok("attenuation-write-denied", r["ok"] is False,
        f"untrusted self-grant write -> ok={r['ok']} err={r.get('err')}")

    return all(r["pass"] for r in RESULTS if r["test"].startswith("attenuation"))


# --------------------------------------------------------------------------
# TEST 3 — REPLAY: same event_id twice = one side effect.
# --------------------------------------------------------------------------
def test_replay():
    """Replay: the same event_id must produce exactly ONE board side effect.

    write_board_note allocates a fresh seq per call and does NOT dedupe on the
    event field. This test directly measures whether re-issuing the same event_id
    yields one note (idempotent) or two (replayable).
    """
    auth = _authority(event_id="E-REPLAY")
    first = {"text": "once", "owner": "x", "event": "REPLAY-1"}
    r1 = sb.write_board_note(first, auth)
    r2 = sb.write_board_note(first, auth)  # same payload, same event id
    notes = sorted(sb.BB.glob("bb-*.json")) if sb.BB.exists() else []
    ev_ids = []
    for p in notes:
        d = json.loads(p.read_text(encoding="utf-8"))
        ev_ids.append(d.get("event"))
    dupes = [e for e in set(ev_ids) if ev_ids.count(e) > 1]
    # PASS only if the repeated event id produced a single note effect.
    _ok("replay-idempotent", len(dupes) == 0,
        f"writes r1=seq{r1.get('seq')} r2=seq{r2.get('seq')} event_ids={ev_ids} dupes={dupes}")
    return all(r["pass"] for r in RESULTS if r["test"].startswith("replay"))


# --------------------------------------------------------------------------
# TEST 4 — CONFUSED DEPUTY: malformed authority fails closed, never crashes.
# --------------------------------------------------------------------------
def test_confused_deputy():
    malformed = [
        None,                       # not a dict
        "not-a-dict",               # string
        {"event_id": 42},           # missing fields, wrong-typed id
        {"status": "AUTHORIZED"},   # no caps at all
        {"granted_capabilities": ["board_write"]},  # no status
    ]
    outcomes = []
    for i, m in enumerate(malformed):
        try:
            r = sb.write_board_note({"text": "cd", "owner": "x"}, m)
            # must never return ok=True for these broken authorities
            ok_flag = r["ok"] if isinstance(r, dict) else False
            outcomes.append(ok_flag)
        except Exception as e:  # fail-closed means NO crash-open either
            outcomes.append("CRASH")
    _ok("confused-deputy-no-crash", "CRASH" not in outcomes,
        f"outcomes={outcomes} (CRASH = validation raised instead of failing closed)")
    # None / string / missing-auth must not grant a write.
    none_and_bad = outcomes[0] or outcomes[1]
    _ok("confused-deputy-fail-closed", none_and_bad is False,
        f"non-dict authorities ok_flags={outcomes[0]},{outcomes[1]}")

    return all(r["pass"] for r in RESULTS if r["test"].startswith("confused"))


# --------------------------------------------------------------------------
# TEST 5 — NOISY NEIGHBOR: 8-agent fan must not starve the reference monitor.
# --------------------------------------------------------------------------
def _noisy_worker(aid, results):
    # operator-confirmed is a legitimate authority (effect layer validates it);
    # we use it so we measure throughput/fairness under fan, not artificial denies.
    auth = _authority(event_id=f"E-NN-{aid}", label="operator-confirmed",
                      caps=["board_write"])
    local = []
    for i in range(12):
        try:
            r = sb.write_board_note({"text": f"{aid}-{i}", "owner": aid, "event": f"{aid}-{i}"}, auth)
            local.append(r)
        except Exception as e:
            local.append({"ok": False, "err": repr(e)})
        time.sleep(0.002)
    results[aid] = local


def test_noisy_neighbor():
    results: dict[str, list] = {}
    threads = [threading.Thread(target=_noisy_worker, args=(f"A{i}", results)) for i in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    all_ok = all(r.get("ok") for rl in results.values() for r in rl if isinstance(r, dict))
    total = sum(len(rl) for rl in results.values())
    # Under a healthy reference monitor, every one of the 8×12 writes succeeds
    # (fresh authority per agent, generous budget). Starvation would show as
    # failures/errors.
    _ok("noisy-all-writes-ok", all_ok,
        f"{total}/96 writes ok=True across 8 agents")

    # No worker was starved: every agent got its full run.
    per_agent = {aid: sum(1 for r in rl if isinstance(r, dict) and r.get("ok")) for aid, rl in results.items()}
    _ok("noisy-no-starvation", all(v == 12 for v in per_agent.values()),
        f"per-agent successful writes={per_agent}")

    return all(r["pass"] for r in RESULTS if r["test"].startswith("noisy"))


# --------------------------------------------------------------------------
def run_all() -> int:
    title = "Five Hypervisor Tests — staged switchboard_v2 stack"
    print("=" * 70)
    print(title)
    print("=" * 70)
    tests = {
        "bypass": test_bypass,
        "attenuation": test_attenuation,
        "replay": test_replay,
        "confused-deputy": test_confused_deputy,
        "noisy-neighbor": test_noisy_neighbor,
    }
    overall = True
    for name, fn in tests.items():
        try:
            passed = fn()
        except Exception as e:  # a crash is a fail-closed violation here
            passed = False
            RESULTS.append({"test": name, "pass": False, "detail": f"CRASH: {e!r}"})
        print(f"[{'PASS' if passed else 'FAIL'}] {name}")
        overall = overall and passed

    print("-" * 70)
    print(f"RESULT: {'5/5 GREEN' if overall else 'NOT ALL GREEN'}")
    summary = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "title": title, "green": overall,
               "tests": {name: (results["pass"]) for name in tests},
               "count": {"pass": sum(1 for r in RESULTS if r["pass"]),
                         "fail": sum(1 for r in RESULTS if not r["pass"])},
               "details": RESULTS}
    out = _TMP / "verdict.json"
    out.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"verdict written: {out}")
    return 0 if overall else 1


if __name__ == "__main__":
    sys.exit(run_all())
