#!/usr/bin/env node
/**
 * steer.mjs — operator steer queue with EDIT-BEFORE-READ rights (v0)
 *
 * Law: the operator may edit any steer while it is UNREAD. Seats must claim
 * before acting; a steer claimed after its last edit timestamp is invalid and
 * must be re-read. File: /board/steers.jsonl (one JSON per line, id-stable).
 *
 * Usage:
 *   node steer.mjs add "<text>"              -> new steer, status UNREAD
 *   node steer.mjs edit <id> "<new text>"    -> edit UNREAD steer (edits++, keeps id)
 *   node steer.mjs list [status]             -> list (default: all, UNREAD first)
 *   node steer.mjs claim <id> <seat>         -> seat marks UNREAD->CLAIMED (records ts)
 *   node steer.mjs done <id> <seat>          -> CLAIMED->DONE (records ts)
 */
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";

const FILE = "/board/steers.jsonl";
const now = () => new Date().toISOString().replace(/\.\d+Z$/, "Z");
const load = () =>
  existsSync(FILE)
    ? readFileSync(FILE, "utf8").split("\n").filter(Boolean).map((l) => JSON.parse(l))
    : [];
const save = (rows) =>
  writeFileSync(FILE, rows.map((r) => JSON.stringify(r)).join("\n") + "\n");
const nextId = (rows) =>
  "s-" + String(rows.length + 1).padStart(3, "0") + "-" +
  createHash("sha256").update(String(rows.length) + Date.now()).digest("hex").slice(0, 4);

const [cmd, a, ...rest] = process.argv.slice(2);
const rows = load();

if (cmd === "add") {
  const text = [a, ...rest].join(" ").trim();
  if (!text) { console.error("usage: add \"<text>\""); process.exit(1); }
  const row = { id: nextId(rows), ts: now(), status: "UNREAD", edits: 0,
    authority: "operator-authored", text, claimed_by: null, claimed_ts: null, done_ts: null };
  rows.push(row); save(rows);
  console.log(`added ${row.id} (UNREAD)`);
} else if (cmd === "edit") {
  const r = rows.find((x) => x.id === a);
  if (!r) { console.error("no such id"); process.exit(1); }
  if (r.status !== "UNREAD") { console.error(`REFUSED: ${a} is ${r.status} — edit rights expire at claim`); process.exit(1); }
  const t = rest.join(" ").trim();
  if (!t) { console.error("usage: edit <id> \"<new text>\""); process.exit(1); }
  r.text = t; r.edits += 1; r.edited_ts = now(); save(rows);
  console.log(`edited ${a} (edits=${r.edits})`);
} else if (cmd === "list") {
  const want = a && a !== "all" ? a : null;
  const order = { UNREAD: 0, CLAIMED: 1, DONE: 2 };
  rows
    .filter((r) => !want || r.status === want)
    .sort((x, y) => (order[x.status] ?? 9) - (order[y.status] ?? 9))
    .forEach((r) =>
      console.log(`${r.status.padEnd(7)} ${r.id} edits=${r.edits} [${r.claimed_by ?? "-"}] ${r.text.slice(0, 110)}`));
} else if (cmd === "claim") {
  const r = rows.find((x) => x.id === a);
  if (!r) { console.error("no such id"); process.exit(1); }
  if (r.status !== "UNREAD") { console.error(`REFUSED: ${a} is ${r.status}`); process.exit(1); }
  r.status = "CLAIMED"; r.claimed_by = rest[0] ?? "unknown"; r.claimed_ts = now(); save(rows);
  console.log(`claimed ${a} by ${r.claimed_by}`);
} else if (cmd === "done") {
  const r = rows.find((x) => x.id === a);
  if (!r) { console.error("no such id"); process.exit(1); }
  r.status = "DONE"; r.done_ts = now(); save(rows);
  console.log(`done ${a}`);
} else {
  console.error("usage: add|edit|list|claim|done"); process.exit(1);
}
