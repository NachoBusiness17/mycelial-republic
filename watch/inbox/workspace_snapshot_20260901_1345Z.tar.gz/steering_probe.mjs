// steering_probe.mjs — S4 steering pass: does a steering instruction SURVIVE a cached prefix?
// Derived from night_cache.mjs (bonded-prefix cache probe). Never prints keys.
//
// Mechanism: the user message = FROZEN_PREFIX() (byte-identical across all calls so the
// DS context cache stays warm) + a STEERING INSTRUCTION appended AFTER the frozen prefix.
// The steering delta rides as new/uncached tokens; the prefix must remain cached (>=4800).
//
// Usage: node steering_probe.mjs <KEY_ENV_NAME> [baseURL] [model]
// Reads DEEPSEEK_API_KEY safe from /mag/.env (node-parse, never shell-source).
// Appends per-call receipts to /board/s4_steering_receipts.jsonl. Prints compact row.
import { performance } from 'node:perf_hooks';
import { appendFileSync, readFileSync, existsSync, writeFileSync } from 'node:fs';

const keyName = process.argv[2] || 'DEEPSEEK_API_KEY';
const BASE = process.argv[3] || 'https://api.deepseek.com/v1/chat/completions';
const model = process.argv[4] || 'deepseek-chat';

function loadKey(name) {
  if (process.env[name]) return process.env[name];
  if (!existsSync('/mag/.env')) return null;
  const line = readFileSync('/mag/.env', 'utf8').split(/\r?\n/).find(l => l.trimStart().startsWith(name + '='));
  return line ? line.slice(line.indexOf('=') + 1).replace(/^"|"$/g, '').trim() : null;
}
const key = loadKey(keyName);
if (!key) { console.error('NO_KEY', keyName); process.exit(1); }

// Byte-identical frozen prefix (matches night_cache 380-rep depth => ~4864 cached tok).
function FROZEN_PREFIX() {
  return 'NIGHT_SHIFT_CACHE_PROBE_20260901_V1. ' +
    ('cache-me-now-2026 repetition builds the context cache. '.repeat(380)) +
    'END_OF_FROZEN_PREFIX.';
}

// Steering experiments. Each has: id, a user steering instruction appended AFTER the
// prefix, an obedience predicate fn(output)->bool, and max_tokens headroom.
const STEERS = [
  {
    id: 'S1_wordcount',
    inst: ' Now answer the trivia question: how many letters are in the word CONSTELLATION? Reply with ONLY a single number, nothing else.',
    headroom: 16,
    obey: (o) => /^\s*-?\d+\s*$/.test(o.trim()),
    expect: 'single number token'
  },
  {
    id: 'S2_fixedkeyword',
    inst: ' Now reply with exactly one sentence that MUST contain the literal token GLYPHWARP.',
    headroom: 48,
    obey: (o) => /GLYPHWARP/.test(o),
    expect: 'sentence containing GLYPHWARP'
  },
  {
    id: 'S3_jsonshape',
    inst: ' Now reply with EXACTLY this JSON and nothing else: {"ok":true}',
    headroom: 32,
    obey: (o) => {
      try { const j = JSON.parse(o); return j && j.ok === true; } catch { return false; }
    },
    expect: 'JSON {"ok":true}'
  },
  // Control: no steering, plain READY (proves prefix still cached and model warm).
  { id: 'CTRL_readytest', inst: ' Reply with exactly the word READY.', headroom: 16, obey: (o) => /^READY$/.test(o.trim()), expect: 'READY' }
];

async function one(exp) {
  const body = {
    model,
    messages: [
      { role: 'system', content: 'You are a terse cache probe. Obey the user instruction exactly.' },
      { role: 'user', content: FROZEN_PREFIX() + exp.inst }
    ],
    max_tokens: exp.headroom,
    temperature: 0
  };
  const t0 = performance.now();
  try {
    const res = await fetch(BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
      body: JSON.stringify(body)
    });
    const ms = Math.round(performance.now() - t0);
    let j = null, outText = '';
    try { j = await res.json(); } catch {}
    if (res.status === 200 && j && Array.isArray(j.choices)) {
      outText = (j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '';
    }
    const u = j && j.usage ? j.usage : {};
    const cached = (u.prompt_tokens_details && u.prompt_tokens_details.cached_tokens) ?? null;
    const row = {
      ts: new Date().toISOString(), model, exp: exp.id, expect: exp.expect,
      http: res.status, ms,
      promptTok: u.prompt_tokens ?? null, outTok: u.completion_tokens ?? null,
      cachedTok: cached,
      // never store raw key; store only trimmed output excerpt + verdict
      out: outText.trim().slice(0, 80),
      obey: res.status === 200 ? exp.obey(outText) : false,
      errCode: j && j.error && j.error.code ? String(j.error.code).slice(0, 40) : null
    };
    return row;
  } catch (e) {
    return { ts: new Date().toISOString(), model, exp: exp.id, expect: exp.expect, http: 0, ms: Math.round(performance.now() - t0), obey: false, err: String(e && e.message || e).slice(0, 100) };
  }
}

const receipts = [];
// Run a warm-up CTRL first so the prefix is cached before the steer measurements begin.
for (const exp of STEERS) {
  const r = await one(exp);
  receipts.push(r);
  appendFileSync('/board/s4_steering_receipts.jsonl', JSON.stringify(r) + '\n');
  console.log(JSON.stringify(r));
  await new Promise(res => setTimeout(res, 1500));
}
// Summary line
const ok = receipts.filter(r => r.http === 200);
const obeyCount = ok.filter(r => r.obey).length;
const cachedOk = ok.filter(r => r.cachedTok != null && r.cachedTok >= 4800).length;
const lat = ok.map(r => r.ms).sort((a, b) => a - b);
const summary = {
  ts: new Date().toISOString(), model, n: ok.length, okCount: ok.length,
  obeyCount, cachedOk, cachedAtLeast4800: ok.every(r => r.cachedTok == null || r.cachedTok >= 4800),
  latMed: lat.length ? lat[Math.floor(lat.length / 2)] : null
};
writeFileSync('/board/s4_steering_summary.json', JSON.stringify(summary, null, 1) + '\n');
console.log('SUMMARY ' + JSON.stringify(summary));
