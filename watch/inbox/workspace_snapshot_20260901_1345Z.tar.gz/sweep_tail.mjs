#!/usr/bin/env node
/**
 * sweep_tail.mjs — Tail seat sweep harness for STEER-001.
 * Usage: node sweep_tail.mjs <targetD>
 * - reads cursor state (verified count) from state file
 * - lerps current D toward targetD (max step 1 per call — continuous motion)
 * - verifies D items (recompute sha256 vs INDEX.json recorded)
 * - appends one receipt line to /board/steer_exp_001_receipts.jsonl
 * State: /root/.openclaw/workspace/sweep_tail_state.json
 */
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";
import { resolve } from "node:path";

const INBOX = "/board/inbox";
const INDEX = resolve(INBOX, "INDEX.json");
const RECEIPTS = "/board/steer_exp_001_receipts.jsonl";
const STATE = "/root/.openclaw/workspace/sweep_tail_state.json";

const now = () => new Date().toISOString();
const loadState = () => existsSync(STATE) ? JSON.parse(readFileSync(STATE,"utf8")) : { verified: 0, curD: null, mismatches: 0, lastTarget: null };
const saveState = (s) => writeFileSync(STATE, JSON.stringify(s));

const targetD = parseInt(process.argv[2] || "2", 10);

const idx = JSON.parse(readFileSync(INDEX,"utf8"));
const items = idx.items;
const relToInbox = (p) => p.replace(/^\/board\/inbox\//, "");
const sha = (file) => createHash("sha256").update(readFileSync(file)).digest("hex").toUpperCase();

let s = loadState();
let curD = s.curD ?? Math.min(2, items.length - s.verified);
// lerp: move toward target by at most 1 each call
const desired = Math.min(targetD, items.length - s.verified);
const newD = desired > curD ? curD + 1 : desired < curD ? curD - 1 : curD;
// Never exceed remaining items
const D = Math.max(1, Math.min(newD, items.length - s.verified));

// verify next D items
let mismatches = 0;
let mismatchList = [];
for (let i = s.verified; i < Math.min(s.verified + D, items.length); i++) {
  const it = items[i];
  const fn = relToInbox(it.path);
  const actual = sha(resolve(INBOX, fn));
  if (actual !== it.sha256) { mismatches++; mismatchList.push(fn); }
}
s.verified = Math.min(s.verified + D, items.length);
s.mismatches += mismatches;
s.curD = D;
s.lastTarget = targetD;
saveState(s);

const receipt = { ts: now(), D, items_verified: D, mismatches, note: mismatchList.length ? "MISMATCH:"+mismatchList.join(",") : (D>0?"ok":"done") };
const fn = (o)=>JSON.stringify(o);
if (existsSync(RECEIPTS)) { const pre=readFileSync(RECEIPTS,"utf8").trim(); writeFileSync(RECEIPTS, pre+(pre?"\n":"")+fn(receipt)+"\n"); }
else writeFileSync(RECEIPTS, fn(receipt)+"\n");

console.log(JSON.stringify({ target: targetD, curD_before: curD, D_used: D, verified_total: s.verified, items_remaining: items.length - s.verified, mismatches, note: receipt.note }));
