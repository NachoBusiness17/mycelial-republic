INTEL 2026-08-31

HOT: ZCode Weekend Build token-drop window is LIVE (today). Users report 300M free GLM-5.3-Flash tokens handed out this weekend on ZCode login (@Zai_org/@zcode_ai). Login NOW if not already claimed — older accounts qualify on first login. https://x.com/batra99/status/2094065752559309250

• OPENAI (TODAY Aug 31): "Codex for (almost) everything" platform update. GPT-5.4 / GPT-5.4-mini RETIRED from Codex for ChatGPT-signed-in sessions → replace with gpt-5.6-terra / gpt-5.6-luna. API-key-authenticated Codex (fleet path) unaffected. https://openai.com/gu-IN/index/codex-for-almost-everything/ https://learn.chatgpt.com/docs/changelog
• DEEPSEEK (TODAY): deepseek-v4-flash-vision-exp weights open-sourced (MIT, ~305B, HF deepseek-ai/DeepSeek-V4-Flash-Vision-Exp). Vision agent model; also live on OpenRouter + DeepSeek API. https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-Vision-Exp
• MOONSHOT (TODAY): legacy moonshot-v1 family (8k/32k/128k tiered) fully sunset → migrate to Kimi K2.5/K3. https://usagepricing.com/blueprint/moonshot-ai
• OPENCLAW: v2026.8.1 released today (baseline updated from v2026.7.1-2). https://github.com/openclaw/openclaw/releases/tag/v2026.8.1
• LANE-HEALTH NVIDIA NIM: free tier is now rate-limited (~40 RPM), NOT credit-capped — Aug 29 quota-exhausted lane will throttle, no daily reset. https://docs.nvidia.com/nim/large-language-models/latest/about-nim-llm/release-notes.html
• LANE-HEALTH CEREBRAS: perpetual free tier gone — now one-time $5 credit trial (verified payment required). Aug 29 quota-exhausted lane has no no-card reset path. https://inference-docs.cerebras.ai/support/pricing
• Z.AI docs: NO diff (devpack overview + pricing unchanged; GLM-5.3-Flash 50% PAYG promo still ends 2026-09-09).
• CALENDAR: fleet conservation law ends + zcode quota reset = Sep 2 (reminder for Sep 1–2).

quiet lanes: Groq (ops normal), Anthropic (all OOS), xAI (no new), Gemini (latest change Aug 27), Together, Mistral, DashScope, Ollama (v0.33.2, Aug 27 >48h).

Note: groundingwave X OAuth absent in cage — used x_search fallback (host-side OAuth not provisioned).
