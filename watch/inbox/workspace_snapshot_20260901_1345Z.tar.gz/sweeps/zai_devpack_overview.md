# Baseline snapshot: https://docs.z.ai/devpack/overview
# Captured 2026-08-30 ~11:30 UTC by Sancho. intel-sweep diffs fresh fetches against this.
# Normalized: security-notice wrapper stripped; core markdown only.

# Overview

The GLM Coding Plan is a subscription package designed specifically for AI-powered coding.

## Usage

The plan can be applied to coding tools such as Claude Code, Cline, and OpenCode.

## Advantages

- Access to high-intelligence Coding Model (GLM series SOTA among open-source)
- Works with Multiple Tools (Claude Code, Cline, OpenCode, specific tools)
- Generous Usage at a Fair Price: starting at just 18 USD per month
- Expanded Capabilities: Vision Understanding, Web Search MCP, Web Reader MCP, Zread MCP

## Benefits

### Supported Models

- All plans support GLM-5.3, GLM-5.3-Flash.
- GLM-5.2/GLM-5.1 requests auto-routed to GLM-5.3; GLM-4.7 auto-routed to GLM-5.3-Flash.

### Usage Instruction

Each plan is subject to both a 5-hour usage limit and a weekly usage limit.

| Plan Type | 5-Hour Credits | Weekly Credits |
| :-------: | :------------: | :------------: |
| Lite      |      2,000     |     10,000     |
| Pro       |     12,000     |     60,000     |
| Max       |     28,000     |     140,000    |

Credit Reset Rules:
- 5-hour credits: dynamically refreshed; resets 5 hours after consumption.
- Weekly credits: activated upon subscription; resets every 7 days.

Credit Calculation:
- Model credit usage = (Input tokens x Input multiplier + Cached Input tokens x Cached Input multiplier + Output tokens x Output multiplier) / 10,000
- MCP tool credit usage = Number of calls x Output multiplier

| Product Type | Product | Input Mult | Cached Input Mult | Output Mult |
|---|---|---|---|---|
| Model | GLM-5.3 | 6.9 | 1.7 | 24 |
| Model | GLM-5.3-Flash (incl. vision MCP) | 2.3 | 0.56 | 8 |
| MCP Server | Web Search | — | — | 1.2 |
| MCP Server | Web Reader | — | — | 1.2 |
| MCP Server | Zread | — | — | 1.2 |

During off-peak hours, model usage is charged at 50% of the standard credit rate.
Peak hours: Monday to Friday, 14:00–18:00 Singapore Standard Time (UTC+8).

Estimated Token Allowance (per cache hit rate, 95/96/98%):
| Cache Hit Rate | Model | Lite | Pro | Max |
|---|---|---|---|---|
| 95% | GLM-5.3 | 48–97 | 290–580 | 676–1,352 |
| 95% | GLM-5.3-Flash | 146–292 | 877–1,755 | 2,047–4,095 |
| 96% | GLM-5.3 | 50–99 | 297–595 | 694–1,387 |
| 96% | GLM-5.3-Flash | 150–300 | 900–1,801 | 2,101–4,202 |
| 98% | GLM-5.3 | 52–104 | 313–627 | 731–1,463 |
| 98% | GLM-5.3-Flash | 158–317 | 950–1,900 | 2,217–4,433 |
(all figures M tokens/week)

Max token allowance = all off-peak (0.5x credit rate); Min = all peak (1x).
By fully utilizing off-peak discounts, save up to 92% vs pay-as-you-go GLM-5.3 standard API.

Exclusive MCP: Vision Understanding, Web Search, Web Reader, Zread.
