# Baseline snapshot: https://docs.z.ai/guides/overview/pricing
# Captured 2026-08-30 ~11:41 UTC by Sancho. intel-sweep diffs fresh fetches against this.

# Pricing (USD, per 1M tokens unless noted)

## Latest Models

| Model | Input | Cached Input | Cached Input Storage | Output |
|---|---|---|---|---|
| GLM-5.3-Flash | $0.075 (50% promo, list $0.15) | $0.015 (list $0.03) | Limited-time Free | $0.25 (list $0.50) |
| GLM-5.3 | $1.4 | $0.26 | Limited-time Free | $4.4 |
| GLM-5.2 | $1.4 | $0.26 | Limited-time Free | $4.4 |

Note: GLM-5.3-Flash 50% discount promotion ends 24:00 September 9, 2026 (UTC+8).

## Text Models

| Model | Input | Cached Input | Output |
|---|---|---|---|
| GLM-5.1 | $1.4 | $0.26 | $4.4 |
| GLM-5 | $1 | $0.2 | $3.2 |
| GLM-4.7 | $0.6 | $0.11 | $2.2 |
| GLM-4.7-FlashX | $0.07 | $0.01 | $0.4 |
| GLM-4.6 | $0.6 | $0.11 | $2.2 |
| GLM-4.5 | $0.6 | $0.11 | $2.2 |
| GLM-4.5-X | $2.2 | $0.45 | $8.9 |
| GLM-4.5-Air | $0.2 | $0.03 | $1.1 |
| GLM-4.5-AirX | $1.1 | $0.22 | $4.5 |
| GLM-4-32B-0414-128K | $0.1 | - | $0.1 |
| GLM-4.7-Flash | Free | Free | Free |
| GLM-4.5-Flash | Free | Free | Free |

## Vision Models
GLM-4.6V: $0.3 / $0.05 / $0.9 — GLM-OCR: $0.03/$0.03 — GLM-4.6V-FlashX: $0.04/$0.004/$0.4 — GLM-4.5V: $0.6/$0.11/$1.8 — GLM-4.6V-Flash: Free

## Built-in Tools
Web Search: $0.01 / use

## Image Generation
GLM-Image $0.015/image — CogView-4 $0.01/image

## Video Generation
CogVideoX-3 $0.2/video

## Audio
GLM-ASR-2512: $0.03/MTok (~$0.0024/min)

## Agents
GLM Slide/Poster Agent (beta) $0.7/MTok — General-Purpose Translation $3/MTok — Popular Special Effects Video Templates $0.2/video
