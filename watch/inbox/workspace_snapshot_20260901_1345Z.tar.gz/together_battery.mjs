// together_battery.mjs — raw-API gen C battery, model under test called DIRECTLY (no spawn identity drift).
// Usage: node together_battery.mjs [model] [base]
// Safe key parse from /mag/.env (never prints values). Gate: abort if cumulative est cost > $0.05.
import { readFileSync, appendFileSync, existsSync } from 'node:fs';

const MODEL = process.argv[2] || 'deepseek-ai/DeepSeek-V4-Flash-0731';
const BASE = process.argv[3] || 'https://api.together.xyz/v1';
const KEYNAME = 'TOGETHER_API_KEY';
const KEYLINE = readFileSync('/mag/.env', 'utf8').split(/\r?\n/).find(l => l.startsWith(KEYNAME + '='));
const KEY = KEYLINE ? KEYLINE.slice(KEYNAME.length + 1).trim() : null;
if (!KEY || !existsSync('/board/lineage_battery_v1.json')) { console.error('missing key or battery'); process.exit(1); }

const battery = JSON.parse(readFileSync('/board/lineage_battery_v1.json', 'utf8'));
const probes = Array.isArray(battery) ? battery : (battery.probes || battery.items || battery.probes_list);
if (!probes || !probes.length) { console.error('no probes parsed — inspect schema'); console.error(Object.keys(battery)); process.exit(1); }

const OUT = '/board/lineage_genC_together_v3_20260901.md';
const CAP = 0.05;
// rate anchors (economist receipt, $/1M): in 0.14 / out 0.28
const R_IN = 0.14 / 1e6, R_OUT = 0.28 / 1e6;
let spent = 0, ok = 0;
let md = `# lineage_genC_together v3 — ${new Date().toISOString()}\n\nmodel: ${MODEL}\nbase: ${BASE}\nmode: raw-API (identity-bound, no spawn drift)\n\n`;

for (const p of probes) {
  const id = p.id ?? p.probe_id ?? p.i ?? '?';
  const q = p.q ?? p.question ?? p.prompt ?? p.text ?? JSON.stringify(p).slice(0, 400);
  const t0 = Date.now();
  try {
    const res = await fetch(BASE + '/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + KEY },
      body: JSON.stringify({ model: MODEL, messages: [{ role: 'user', content: String(q) }], max_tokens: 1500, temperature: 0 })
    });
    const j = await res.json().catch(() => null);
    const msg = j && j.choices ? j.choices[0].message : null;
    const ans = msg ? (msg.content || msg.reasoning_content || null) : null;
    const u = j && j.usage ? j.usage : {};
    const fin = j && j.choices ? j.choices[0].finish_reason : null;
    const cost = (u.prompt_tokens || 0) * R_IN + (u.completion_tokens || 0) * R_OUT;
    spent += cost;
    if (ans) { ok++; md += `## ${id}\n${ans.trim()}\n\n`; }
    else md += `## ${id}\n[ERROR ${res.status}] ${j && j.error ? String(j.error.message).slice(0, 120) : 'no content'}\n\n`;
    appendFileSync('/board/together_v3_ledger.jsonl', JSON.stringify({ id, http: res.status, in: u.prompt_tokens, out: u.completion_tokens, fin, hasReason: !!(msg && msg.reasoning_content), cost: +cost.toFixed(6), ms: Date.now() - t0 }) + '\n');
    if (spent > CAP) { md += `\n[BURN GATE HIT at $${spent.toFixed(4)} — halting per cap]\n`; break; }
  } catch (e) {
    md += `## ${id}\n[FETCH ERR] ${String(e && e.message || e).slice(0, 100)}\n\n`;
  }
}
md += `\n---\nok: ${ok}/${probes.length} · est spend: $${spent.toFixed(4)} of $${CAP} cap · model: ${MODEL}\n`;
appendFileSync(OUT, md);
console.log(JSON.stringify({ ok, total: probes.length, spent: +spent.toFixed(4), out: OUT }));
